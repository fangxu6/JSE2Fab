﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Xj_Mes_Report
{
    public class Class1
    {
    }
}

﻿using Excel;

namespace DataToExcel.ExpDataToExcelFactory
{
    public class Device_SPG8929_08_00 : ExpToExcelSoftBin
    {
        public override void expToExcel(Worksheet worksheet)
        {

        }

    }
}

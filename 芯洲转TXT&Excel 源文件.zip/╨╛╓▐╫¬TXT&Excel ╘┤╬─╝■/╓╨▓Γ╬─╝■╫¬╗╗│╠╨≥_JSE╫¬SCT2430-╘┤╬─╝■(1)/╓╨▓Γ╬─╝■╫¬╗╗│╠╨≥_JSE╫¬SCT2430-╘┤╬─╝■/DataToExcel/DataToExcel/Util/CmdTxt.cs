

/*
 * ���ߣ�sky
 * ʱ�䣺2008-06-25
 * ���ã��������� CMD �� txt ��ʽ�� mapping �ļ�
 */

namespace DataToExcel
{
    using System;
    using System.Drawing;
    using System.Collections;
    using DataToExcel;
    using System.IO;

    public class CmdTxt : MappingBase
    {
        // Fields
        public static string _Device = "";
        public static string _LotNo = "";
        public static int _singleTotalDie = 0;
        public static int _TotalDie = 0;
        public static int _TotalFailDie = 0;
        public static int _TotalPassDie = 0;
        public static string _TotalYield = "";

        // Methods
        public CmdTxt(string file)
            : base("cmdtxt", file)
        {
        }

        protected override void InitialProperties()
        {
           
            base._keys.Add("PassDie");
            base._keys.Add("FailDie");
            base._keys.Add("RowCount");
            base._keys.Add("ColCount");
            base._properties.Add("PassDie", 0);
            base._properties.Add("FailDie", 0);
            base._properties.Add("RowCount", 0);
            base._properties.Add("ColCount", 0);
        }

        public static bool InitTotal()
        {
            _TotalDie = 0;
            _TotalPassDie = 0;
            _TotalFailDie = 0;
            _singleTotalDie = 0;
            _TotalYield = "";
            return true;
        }

        public override bool IsEmptyDie(DieData die)
        {
            return (((die.Attribute == DieCategory.NoneDie) || (die.Attribute == DieCategory.MarkDie)) || (die.Attribute == DieCategory.SkipDie));
        }

        public override IMappingFile Merge(IMappingFile map, string newfile)
        {
            return null;
        }

        public override void Read()
        {
            throw new Exception("�����Ͳ�֧���ļ���ȡ��");
        }

        public override void Save()
        {
            try
            {
                try
                {

                    if (File.Exists(base.FullName))
                    {
                        File.Delete(base.FullName);
                    }
                    base.OpenWriter();

                    this.WriteString("Device:" + this.Device + this.Enter);
                    this.WriteString("Lot NO:" + this.LotNo + this.Enter);
                  //  this.WriteString("Slot No:" + this.SlotNo.ToString("00") + this.Enter);
                    this.WriteString("Wafer ID:" + this.SlotNo.ToString("00") + this.Enter);
                    string WaferSize1="";

                    if (this.WaferSize == 60)
                    {
                        WaferSize1 = "6 Inch";
                    }
                    else if (this.WaferSize == 80)
                    {
                        WaferSize1 = "8 ";

                    }

                    else if (this.WaferSize == 120)
                    {
                        WaferSize1 = "12 Inch";

                    }
                    this.WriteString("Wafer Size:" + WaferSize1 + this.Enter);

                    string FlatDir1 = "";

                    if (this.FlatDir == 90)
                    {
                        FlatDir1 = "Right";
                    }

                    else if (this.FlatDir == 180)
                    {
                        FlatDir1 = "Down";
                    }
                    else if (this.FlatDir == 270)
                    {
                        FlatDir1 = "Left";
                    }
                    else if (this.FlatDir == 0)
                    {
                        FlatDir1 = "Up";
                    }

                    this.WriteString("Flat Dir:" + FlatDir1 + this.Enter);
                    int flagbin = 0;

                    int ymin = 1000, xmin = 1000, ymax = 0, xmax = 0 ,bin58=0;
                    {
                        for (int y = 0; y < base.DieMatrix.YMax; y++)
                        {

                            for (int x = 0; x < base.DieMatrix.XMax; x++)
                            {
                                switch (base.DieMatrix[x, y].Attribute)
                                {
                                    case DieCategory.PassDie:
                                    case DieCategory.FailDie:
                                    case DieCategory.SkipDie2:
                                        if (xmin > x) { xmin = x; }
                                        if (ymin > y) { ymin = y; }
                                        if (ymax < y) { ymax = y; }
                                        if (xmax < x) { xmax = x; }
                                       
                                           int xxx = this.DieMatrix[x, y].Bin;
                                            if (xxx == 2)
                                            {
                                                flagbin = 1;
                                            }
                                            if (xxx == 58)
                                            {
                                                bin58++;
                                            }
                                        break;
                                }

                            }
                        }


                    }

                    this.WriteString("ROWCT:" + (ymax - ymin +1) + this.Enter);
                    this.WriteString("COLCT:" + (xmax - xmin + 1) + this.Enter);
                    if (flagbin == 0)
                    {
                        this.WriteString("PASS BIN:1" + this.Enter);
                    }
                    else
                    {
                        this.WriteString("PASS BIN:1" + this.Enter);
                    }
                    this.WriteString("Test Start Time:" + this.LoadTime.ToString("yy/MM/dd HH:mm:ss") + this.Enter);
                    this.WriteString("Test End Time:" + this.EndTime.ToString("yy/MM/dd HH:mm:ss") + this.Enter);
                   /* this.WriteString("Test Program:;" + this.Enter);
                    this.WriteString("Tester ID:" + this.Enter);
                    this.WriteString("Operator ID:" + this.Enter);
                    this.WriteString("Sort ID:" + this.Enter);
                    this.WriteString("Test site: " + this.Enter);
                    this.WriteString("Probe Card ID:" + this.Enter);
                    this.WriteString("Load Board ID:" + this.Enter);*/

                   
                    this.WriteString("Gross die:" + (this.PassDie + this.FailDie-bin58) + this.Enter);
                    this.WriteString("Pass Die:" + this.PassDie + this.Enter);
                    this.WriteString("Fail Die:" + this.FailDie + this.Enter);
                    this.WriteString("Yield:" + Math.Round(Convert.ToDouble((double)(this.PassDie / ((double)(this.PassDie + this.FailDie-bin58)))), 6).ToString("0.0000%") + this.Enter);
                  //  this.WriteString("StrBin:2,2;3,3;4,4;5,5;6,6;7,7;8,8;9,9;10,A;11,B;12,C;13,D;14,E;15,F;16,G;17,H;18,I;19,J;20,K;21,L;22,M;63,X;" + this.Enter);
                    this.WriteString("StrBin:1,1;2,2;3,3;4,4;5,5;6,6;7,7;8,8;9,9;10,A;11,B;12,C;13,D;14,E;15,F;16,G;17,H;18,I;19,J;20,K;21,L;22,M;23,N;24,O;25,P;26,Q;27,R;28,S;29,T;30,U;57,X;" + this.Enter);
                   

                   for (int y = ymin; y < ymax+1; y++)
                  //  for (int y = 0; y < base.DieMatrix.YMax-1; y++)
                   {

                       for (int x = xmin; x < xmax+1; x++)
                      //  for (int x = 0; x < base.DieMatrix.XMax; x++)
                        {

                            switch (base.DieMatrix[x, y].Attribute)
                            {

                                case DieCategory.PassDie:
                                    {
                                        int xxx = this.DieMatrix[x, y].Bin;
                                        this.WriteString(string.Format("{0,1:G}", this.DieMatrix[x, y].Bin-1));
                                        break;
                                    }
                                case DieCategory.MarkDie:
                                case DieCategory.NoneDie:
                                case DieCategory.SkipDie:
                                case DieCategory.SkipDie2:
                                    {

                                        this.WriteString(string.Format("{0,1:G}", UtilFunction.DieCategoryCaption(base.DieMatrix[x, y].Attribute)));
                                        break;
                                    }

                                case DieCategory.FailDie:
                                    {
                                        this.DieMatrix[x, y].Bin = this.DieMatrix[x, y].Bin - 1;  //BIN-1
                                        // this.WriteString(string.Format("{0,1:G}", "X"));
                                        if (this.DieMatrix[x, y].Bin < 10)
                                        {
                                            this.WriteString(string.Format("{0,1:G}", this.DieMatrix[x, y].Bin));
                                        }
                                        else if (this.DieMatrix[x, y].Bin == 10)
                                        {
                                            this.WriteString(string.Format("{0,1:G}", "A"));
                                        }
                                        else if (this.DieMatrix[x, y].Bin == 11)
                                        {
                                            this.WriteString(string.Format("{0,1:G}", "B"));
                                        }
                                        else if (this.DieMatrix[x, y].Bin == 12)
                                        {
                                            this.WriteString(string.Format("{0,1:G}", "C"));
                                        }
                                        else if (this.DieMatrix[x, y].Bin == 13)
                                        {
                                            this.WriteString(string.Format("{0,1:G}", "D"));
                                        }
                                        else if (this.DieMatrix[x, y].Bin == 14)
                                        {
                                            this.WriteString(string.Format("{0,1:G}", "E"));
                                        }
                                        else if (this.DieMatrix[x, y].Bin == 15)
                                        {
                                            this.WriteString(string.Format("{0,1:G}", "F"));
                                        }
                                        else if (this.DieMatrix[x, y].Bin == 16)
                                        {
                                            this.WriteString(string.Format("{0,1:G}", "G"));
                                        }
                                        else if (this.DieMatrix[x, y].Bin == 17)
                                        {
                                            this.WriteString(string.Format("{0,1:G}", "H"));
                                        }
                                        else if (this.DieMatrix[x, y].Bin == 18)
                                        {
                                            this.WriteString(string.Format("{0,1:G}", "I"));
                                        }
                                        else if (this.DieMatrix[x, y].Bin == 19)
                                        {
                                            this.WriteString(string.Format("{0,1:G}", "J"));
                                        }
                                        else if (this.DieMatrix[x, y].Bin == 20)
                                        {
                                            this.WriteString(string.Format("{0,1:G}", "K"));
                                        }
                                        else if (this.DieMatrix[x, y].Bin == 21)
                                        {
                                            this.WriteString(string.Format("{0,1:G}", "L"));
                                        }
                                        else if (this.DieMatrix[x, y].Bin == 22)
                                        {
                                            this.WriteString(string.Format("{0,1:G}", "M"));
                                        }
                                        else if (this.DieMatrix[x, y].Bin == 23)
                                        {
                                            this.WriteString(string.Format("{0,1:G}", "N"));
                                         }
                                        else if (this.DieMatrix[x, y].Bin == 24)
                                        {
                                            this.WriteString(string.Format("{0,1:G}", "O"));
                                        }
                                        else if (this.DieMatrix[x, y].Bin == 25)
                                        {
                                            this.WriteString(string.Format("{0,1:G}", "P"));
                                        }
                                        else if (this.DieMatrix[x, y].Bin == 26)
                                        {
                                           this.WriteString(string.Format("{0,1:G}", "Q"));
                                        }
                                        else if (this.DieMatrix[x, y].Bin == 27)
                                        {
                                           this.WriteString(string.Format("{0,1:G}", "R"));
                                        }

                                        else if (this.DieMatrix[x, y].Bin == 28)
                                        {
                                           this.WriteString(string.Format("{0,1:G}", "S"));
                                        }
                                         else if (this.DieMatrix[x, y].Bin == 29)
                                        {
                                           this.WriteString(string.Format("{0,1:G}", "T"));
                                        }
                                          else if (this.DieMatrix[x, y].Bin == 30)
                                        {
                                           this.WriteString(string.Format("{0,1:G}", "U"));
                                         }
                                         else if (this.DieMatrix[x, y].Bin == 31)
                                        {
                                           this.WriteString(string.Format("{0,1:G}", "V"));
                                         }
                                         else if (this.DieMatrix[x, y].Bin == 32)
                                        {
                                           this.WriteString(string.Format("{0,1:G}", "W"));
                                         }
                                         else if (this.DieMatrix[x, y].Bin == 33)
                                        {
                                           this.WriteString(string.Format("{0,1:G}", "Y"));
                                         }

                                         else if (this.DieMatrix[x, y].Bin == 34)
                                        {
                                           this.WriteString(string.Format("{0,1:G}", "Z"));
                                         }




                                        
                                        else if (this.DieMatrix[x, y].Bin > 55)
                                        {
                                            this.WriteString(string.Format("{0,1:G}", "X"));
                                        }
                                        
                                        break;

                                    }

                            }
                        }
                        this.WriteString(this.Enter);


                    }

                    /*

                    this.WriteString("     ");
                    for (int i = 0; i < base.DieMatrix.XMax; i++)
                    {
                        int num5 = i + 1;
                        this.WriteString(num5.ToString("00") + " ");
                    }
                    this.WriteString(base.Enter + "     ");
                    for (int j = 0; j < base.DieMatrix.XMax; j++)
                    {
                        this.WriteString("++-");
                    }
                    ToCountDie die = new ToCountDie();
                    for (int k = 0; k < base.DieMatrix.YMax; k++)
                    {
                        this.WriteString(base.Enter + ((k + 1)).ToString("000") + "| ");
                        for (int m = 0; m < base.DieMatrix.XMax; m++)
                        {
                            if (base.DieMatrix[m, k].Attribute == DieCategory.FailDie)
                            {
                                die.CountDie(base.DieMatrix[m, k].Bin);
                            }
                            this.WriteString(UtilFunction.DieCategoryCaption(base.DieMatrix[m, k].Attribute) + " ");
                        }
                    }
                    _singleTotalDie = base.DieMatrix.DieAttributeStat(DieCategory.TIRefFail | DieCategory.TIRefPass | DieCategory.Unknow | DieCategory.FailDie | DieCategory.PassDie);
                    this.WriteString(base.Enter + base.Enter);
                    this.WriteString("============ Wafer Information () ===========" + base.Enter);
                    this.WriteString("  Device: " + this.Device + base.Enter);
                    this.WriteString("  Lot NO: " + this.LotNo + base.Enter);
                    this.WriteString("  Slot NO: " + this.SlotNo + base.Enter);
                    this.WriteString("  Wafer ID: " + this.WaferID + base.Enter);
                    this.WriteString("  Operater: " + base.Enter);
                    this.WriteString("  Wafer Size: " + ((this.WaferSize / 10)).ToString() + "inch" + base.Enter);
                    this.WriteString("  Flat Dir: " + this.FlatDir + base.Enter);
                    this.WriteString("  Wafer Test Start Time: " + this.StartTime + base.Enter);
                    this.WriteString("  Wafer Test Finish Time: " + this.EndTime + base.Enter);
                    this.WriteString("  Wafer Load Time: " + this.LoadTime + base.Enter);
                    this.WriteString("  Wafer Unload Time: " + this.UnloadTime + base.Enter);
                    this.WriteString("  Total Test Die: " + _singleTotalDie + base.Enter);
                    this.WriteString("  Pass Die: " + this.PassDie + base.Enter);
                    this.WriteString("  Fail Die: " + this.FailDie + base.Enter);
                    this.WriteString("  Yield: " + Math.Round(Convert.ToDouble((double)(Convert.ToDouble(this.PassDie) / ((double)_singleTotalDie))), 4).ToString("0.00%") + base.Enter);
                    this.WriteString("  Rows: " + this.RowCount + base.Enter);
                    this.WriteString("  Cols: " + this.ColCount + base.Enter);
                    string path = base.FullName.Substring(0, base.FullName.LastIndexOf(@"\")) + @"\Total.txt";
                    if (File.Exists(path))
                    {   
                        writer = File.AppendText(path);
                    }
                    else
                    {
                        writer = File.CreateText(path);
                    }
                    _Device = this.Device;
                    _LotNo = this.LotNo;
                    _TotalDie += _singleTotalDie;
                    _TotalPassDie += this.PassDie;
                    _TotalFailDie += this.FailDie;
                    _TotalYield = Math.Round(Convert.ToDouble((double)(Convert.ToDouble(_TotalPassDie) / ((double)_TotalDie))), 4).ToString("0.00%");
                    writer.WriteLine("============ Wafer Information () ===========");
                    writer.WriteLine("  Device: " + this.Device);
                    writer.WriteLine("  Lot NO: " + this.LotNo);
                    writer.WriteLine("  Slot NO: " + this.SlotNo);
                    writer.WriteLine("  Wafer ID: " + this.WaferID);
                    writer.WriteLine("  Operater: ");
                    writer.WriteLine("  Wafer Size: " + ((this.WaferSize / 10)).ToString() + "inch");
                    writer.WriteLine("  Flat Dir: " + this.FlatDir);
                    writer.WriteLine("  Wafer Test Start Time: " + this.StartTime);
                    writer.WriteLine("  Wafer Test Finish Time: " + this.EndTime);
                    writer.WriteLine("  Wafer Load Time: " + this.LoadTime);
                    writer.WriteLine("  Wafer Unload Time: " + this.UnloadTime);
                    writer.WriteLine("  Total Test Die: " + _singleTotalDie);
                    writer.WriteLine("  Pass Die: " + this.PassDie);
                    writer.WriteLine("  Fail Die: " + this.FailDie);
                    writer.WriteLine("  Yield: " + Math.Round(Convert.ToDouble((double)(Convert.ToDouble(this.PassDie) / ((double)_singleTotalDie))), 4).ToString("0.00%"));
                    writer.WriteLine("  Rows: " + this.RowCount);
                    writer.WriteLine("  Cols: " + this.ColCount);
                    writer.WriteLine("=============================================");
                    writer.WriteLine(base.Enter);
                    
                    writer.Close();
                     */
                     


                }
                catch (Exception exception)
                {
                    throw exception;
                }
            }
            finally
            {
                base.CloseWriter();
            }
        }

        // Properties
        public int CassetteNo
        {
            get
            {
                return (int)base._properties["CassetteNo"];
            }
            set
            {
                base._properties["CassetteNo"] = value;
            }
        }

        public int ColCount
        {
            get
            {
                return (int)base._properties["ColCount"];
            }
            set
            {
                base._properties["ColCount"] = value;
            }
        }

        public string Device
        {
            get
            {
                return base._properties["Device"].ToString();
            }
            set
            {
                base._properties["Device"] = value;
            }
        }

        public DateTime EndTime
        {
            get
            {
                return (DateTime)base._properties["EndTime"];
            }
            set
            {
                base._properties["EndTime"] = value;
            }
        }

        public int FailDie
        {
            get
            {
                return (int)base._properties["FailDie"];
            }
            set
            {
                base._properties["FailDie"] = value;
            }
        }

        public int FlatDir
        {
            get
            {
                return (int)base._properties["FlatDir"];
            }
            set
            {
                base._properties["FlatDir"] = value;
            }
        }

        public int IndexSizeX
        {
            get
            {
                return (int)base._properties["IndexSizeX"];
            }
            set
            {
                base._properties["IndexSizeX"] = value;
            }
        }

        public int IndexSizeY
        {
            get
            {
                return (int)base._properties["IndexSizeY"];
            }
            set
            {
                base._properties["IndexSizeY"] = value;
            }
        }

        public DateTime LoadTime
        {
            get
            {
                return (DateTime)base._properties["LoadTime"];
            }
            set
            {
                base._properties["LoadTime"] = value;
            }
        }

        public override string LotNo
        {
            get
            {
                return base._properties["LotNo"].ToString();
            }
            set
            {
                base._properties["LotNo"] = value;
            }
        }

        public int MachineNo
        {
            get
            {
                return (int)base._properties["MachineNo"];
            }
            set
            {
                base._properties["MachineNo"] = value;
            }
        }

        public byte MachineType
        {
            get
            {
                return (byte)base._properties["MachineType"];
            }
            set
            {
                base._properties["MachineType"] = value;
            }
        }

        public int MapDataForm
        {
            get
            {
                return (int)base._properties["MapDataForm"];
            }
            set
            {
                base._properties["MapDataForm"] = value;
            }
        }

        public byte MapVersion
        {
            get
            {
                return (byte)base._properties["MapVersion"];
            }
            set
            {
                base._properties["MapVersion"] = value;
            }
        }

        public string Operator
        {
            get
            {
                return base._properties["Operator"].ToString();
            }
            set
            {
                base._properties["Operator"] = value;
            }
        }

        public int PassDie
        {
            get
            {
                return (int)base._properties["PassDie"];
            }
            set
            {
                base._properties["PassDie"] = value;
            }
        }

        public byte ProbingNo
        {
            get
            {
                return (byte)base._properties["ProbingNo"];
            }
            set
            {
                base._properties["ProbingNo"] = value;
            }
        }

        public int Refpx
        {
            get
            {
                return (int)base._properties["Refpx"];
            }
            set
            {
                base._properties["Refpx"] = value;
            }
        }

        public int Refpy
        {
            get
            {
                return (int)base._properties["Refpy"];
            }
            set
            {
                base._properties["Refpy"] = value;
            }
        }

        public int RowCount
        {
            get
            {
                return (int)base._properties["RowCount"];
            }
            set
            {
                base._properties["RowCount"] = value;
            }
        }

        public int SlotNo
        {
            get
            {
                return (int)base._properties["SlotNo"];
            }
            set
            {
                base._properties["SlotNo"] = value;
            }
        }

        public DateTime StartTime
        {
            get
            {
                return (DateTime)base._properties["StartTime"];
            }
            set
            {
                base._properties["StartTime"] = value;
            }
        }

        public int TotalDie
        {
            get
            {
                return (int)base._properties["TotalDie"];
            }
            set
            {
                base._properties["TotalDie"] = value;
            }
        }

        public DateTime UnloadTime
        {
            get
            {
                return (DateTime)base._properties["UnloadTime"];
            }
            set
            {
                base._properties["UnloadTime"] = value;
            }
        }

        public override string WaferID
        {
            get
            {
                return base._properties["WaferID"].ToString();
            }
            set
            {
                base._properties["WaferID"] = value;
            }
        }

        public int WaferSize
        {
            get
            {
                return (int)base._properties["WaferSize"];
            }
            set
            {
                base._properties["WaferSize"] = value;
            }
        }
    }
}

﻿
namespace Xj_Mes_cp
{
    partial class 其他信息打印
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonX2 = new DevComponents.DotNetBar.ButtonX();
            this.buttonX1 = new DevComponents.DotNetBar.ButtonX();
            this.groupPanel1 = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.labelX2 = new DevComponents.DotNetBar.LabelX();
            this.labelX4 = new DevComponents.DotNetBar.LabelX();
            this.labelX1 = new DevComponents.DotNetBar.LabelX();
            this.textBoxX2 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX5 = new DevComponents.DotNetBar.LabelX();
            this.labelX6 = new DevComponents.DotNetBar.LabelX();
            this.labelX7 = new DevComponents.DotNetBar.LabelX();
            this.labelX11 = new DevComponents.DotNetBar.LabelX();
            this.labelX3 = new DevComponents.DotNetBar.LabelX();
            this.labelX15 = new DevComponents.DotNetBar.LabelX();
            this.labelX16 = new DevComponents.DotNetBar.LabelX();
            this.labelX17 = new DevComponents.DotNetBar.LabelX();
            this.labelX18 = new DevComponents.DotNetBar.LabelX();
            this.labelX19 = new DevComponents.DotNetBar.LabelX();
            this.labelX20 = new DevComponents.DotNetBar.LabelX();
            this.labelX21 = new DevComponents.DotNetBar.LabelX();
            this.labelX22 = new DevComponents.DotNetBar.LabelX();
            this.labelX23 = new DevComponents.DotNetBar.LabelX();
            this.labelX24 = new DevComponents.DotNetBar.LabelX();
            this.labelX25 = new DevComponents.DotNetBar.LabelX();
            this.labelX26 = new DevComponents.DotNetBar.LabelX();
            this.labelX27 = new DevComponents.DotNetBar.LabelX();
            this.labelX28 = new DevComponents.DotNetBar.LabelX();
            this.labelX29 = new DevComponents.DotNetBar.LabelX();
            this.labelX30 = new DevComponents.DotNetBar.LabelX();
            this.labelX31 = new DevComponents.DotNetBar.LabelX();
            this.labelX32 = new DevComponents.DotNetBar.LabelX();
            this.labelX33 = new DevComponents.DotNetBar.LabelX();
            this.labelX34 = new DevComponents.DotNetBar.LabelX();
            this.labelX35 = new DevComponents.DotNetBar.LabelX();
            this.labelX36 = new DevComponents.DotNetBar.LabelX();
            this.labelX37 = new DevComponents.DotNetBar.LabelX();
            this.labelX38 = new DevComponents.DotNetBar.LabelX();
            this.labelX39 = new DevComponents.DotNetBar.LabelX();
            this.labelX40 = new DevComponents.DotNetBar.LabelX();
            this.labelX41 = new DevComponents.DotNetBar.LabelX();
            this.labelX42 = new DevComponents.DotNetBar.LabelX();
            this.labelX43 = new DevComponents.DotNetBar.LabelX();
            this.labelX44 = new DevComponents.DotNetBar.LabelX();
            this.labelX45 = new DevComponents.DotNetBar.LabelX();
            this.labelX46 = new DevComponents.DotNetBar.LabelX();
            this.labelX47 = new DevComponents.DotNetBar.LabelX();
            this.labelX48 = new DevComponents.DotNetBar.LabelX();
            this.labelX49 = new DevComponents.DotNetBar.LabelX();
            this.labelX50 = new DevComponents.DotNetBar.LabelX();
            this.labelX51 = new DevComponents.DotNetBar.LabelX();
            this.labelX52 = new DevComponents.DotNetBar.LabelX();
            this.labelX53 = new DevComponents.DotNetBar.LabelX();
            this.labelX54 = new DevComponents.DotNetBar.LabelX();
            this.labelX55 = new DevComponents.DotNetBar.LabelX();
            this.textBoxX3 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX4 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX5 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX6 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX7 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX8 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX9 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX10 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX11 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX12 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX13 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX14 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX16 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX17 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX18 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX19 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX20 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX21 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX22 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX23 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX24 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX25 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX26 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX27 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX28 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX29 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX30 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX31 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX32 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX33 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX34 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX35 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX36 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX37 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX38 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX39 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX40 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX41 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX42 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX43 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX44 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX45 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX46 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX47 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX48 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX49 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX50 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX51 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX8 = new DevComponents.DotNetBar.LabelX();
            this.textBoxX1 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX13 = new DevComponents.DotNetBar.LabelX();
            this.labelX9 = new DevComponents.DotNetBar.LabelX();
            this.textBoxX15 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.comboBoxEx2 = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.comboItem1 = new DevComponents.Editors.ComboItem();
            this.comboItem2 = new DevComponents.Editors.ComboItem();
            this.comboItem3 = new DevComponents.Editors.ComboItem();
            this.groupPanel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonX2
            // 
            this.buttonX2.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX2.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX2.Location = new System.Drawing.Point(171, 7);
            this.buttonX2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.buttonX2.Name = "buttonX2";
            this.buttonX2.Size = new System.Drawing.Size(155, 65);
            this.buttonX2.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX2.TabIndex = 2;
            this.buttonX2.Text = "清空";
            this.buttonX2.Click += new System.EventHandler(this.buttonX2_Click);
            // 
            // buttonX1
            // 
            this.buttonX1.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX1.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX1.Location = new System.Drawing.Point(8, 8);
            this.buttonX1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.buttonX1.Name = "buttonX1";
            this.buttonX1.Size = new System.Drawing.Size(155, 65);
            this.buttonX1.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX1.TabIndex = 1;
            this.buttonX1.Text = "打印";
            this.buttonX1.Click += new System.EventHandler(this.buttonX1_Click);
            // 
            // groupPanel1
            // 
            this.groupPanel1.CanvasColor = System.Drawing.SystemColors.Control;
            this.groupPanel1.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.groupPanel1.Controls.Add(this.buttonX2);
            this.groupPanel1.Controls.Add(this.buttonX1);
            this.groupPanel1.Controls.Add(this.tableLayoutPanel1);
            this.groupPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupPanel1.Location = new System.Drawing.Point(0, 0);
            this.groupPanel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupPanel1.Name = "groupPanel1";
            this.groupPanel1.Size = new System.Drawing.Size(1168, 756);
            // 
            // 
            // 
            this.groupPanel1.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.groupPanel1.Style.BackColorGradientAngle = 90;
            this.groupPanel1.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.groupPanel1.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderBottomWidth = 1;
            this.groupPanel1.Style.BorderColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.groupPanel1.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderLeftWidth = 1;
            this.groupPanel1.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderRightWidth = 1;
            this.groupPanel1.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderTopWidth = 1;
            this.groupPanel1.Style.Class = "";
            this.groupPanel1.Style.CornerDiameter = 4;
            this.groupPanel1.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.groupPanel1.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.groupPanel1.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.groupPanel1.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.groupPanel1.StyleMouseDown.Class = "";
            this.groupPanel1.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.groupPanel1.StyleMouseOver.Class = "";
            this.groupPanel1.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.groupPanel1.TabIndex = 1;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel1.ColumnCount = 8;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 124F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 124F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 124F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 124F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.Controls.Add(this.labelX2, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.labelX4, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.labelX1, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX2, 1, 12);
            this.tableLayoutPanel1.Controls.Add(this.labelX5, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelX6, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.labelX7, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.labelX11, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.labelX3, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.labelX15, 6, 1);
            this.tableLayoutPanel1.Controls.Add(this.labelX16, 6, 2);
            this.tableLayoutPanel1.Controls.Add(this.labelX17, 6, 3);
            this.tableLayoutPanel1.Controls.Add(this.labelX18, 6, 4);
            this.tableLayoutPanel1.Controls.Add(this.labelX19, 6, 5);
            this.tableLayoutPanel1.Controls.Add(this.labelX20, 6, 6);
            this.tableLayoutPanel1.Controls.Add(this.labelX21, 6, 7);
            this.tableLayoutPanel1.Controls.Add(this.labelX22, 6, 8);
            this.tableLayoutPanel1.Controls.Add(this.labelX23, 6, 9);
            this.tableLayoutPanel1.Controls.Add(this.labelX24, 6, 10);
            this.tableLayoutPanel1.Controls.Add(this.labelX25, 6, 11);
            this.tableLayoutPanel1.Controls.Add(this.labelX26, 6, 12);
            this.tableLayoutPanel1.Controls.Add(this.labelX27, 4, 12);
            this.tableLayoutPanel1.Controls.Add(this.labelX28, 4, 11);
            this.tableLayoutPanel1.Controls.Add(this.labelX29, 4, 10);
            this.tableLayoutPanel1.Controls.Add(this.labelX30, 4, 9);
            this.tableLayoutPanel1.Controls.Add(this.labelX31, 4, 8);
            this.tableLayoutPanel1.Controls.Add(this.labelX32, 4, 7);
            this.tableLayoutPanel1.Controls.Add(this.labelX33, 4, 6);
            this.tableLayoutPanel1.Controls.Add(this.labelX34, 4, 5);
            this.tableLayoutPanel1.Controls.Add(this.labelX35, 4, 4);
            this.tableLayoutPanel1.Controls.Add(this.labelX36, 4, 3);
            this.tableLayoutPanel1.Controls.Add(this.labelX37, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.labelX38, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.labelX39, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.labelX40, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.labelX41, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.labelX42, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.labelX43, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.labelX44, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.labelX45, 2, 7);
            this.tableLayoutPanel1.Controls.Add(this.labelX46, 2, 8);
            this.tableLayoutPanel1.Controls.Add(this.labelX47, 2, 9);
            this.tableLayoutPanel1.Controls.Add(this.labelX48, 2, 10);
            this.tableLayoutPanel1.Controls.Add(this.labelX49, 2, 11);
            this.tableLayoutPanel1.Controls.Add(this.labelX50, 2, 12);
            this.tableLayoutPanel1.Controls.Add(this.labelX51, 0, 12);
            this.tableLayoutPanel1.Controls.Add(this.labelX52, 0, 11);
            this.tableLayoutPanel1.Controls.Add(this.labelX53, 0, 10);
            this.tableLayoutPanel1.Controls.Add(this.labelX54, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.labelX55, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX3, 1, 11);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX4, 1, 10);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX5, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX6, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX7, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX8, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX9, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX10, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX11, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX12, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX13, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX14, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX16, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX17, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX18, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX19, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX20, 3, 5);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX21, 3, 6);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX22, 3, 7);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX23, 3, 8);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX24, 3, 9);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX25, 3, 10);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX26, 3, 11);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX27, 3, 12);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX28, 5, 12);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX29, 5, 11);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX30, 5, 10);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX31, 5, 9);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX32, 5, 8);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX33, 5, 7);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX34, 5, 6);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX35, 5, 5);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX36, 5, 4);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX37, 5, 3);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX38, 5, 2);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX39, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX40, 7, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX41, 7, 2);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX42, 7, 3);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX43, 7, 4);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX44, 7, 5);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX45, 7, 6);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX46, 7, 7);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX47, 7, 8);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX48, 7, 9);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX49, 7, 10);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX50, 7, 11);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX51, 7, 12);
            this.tableLayoutPanel1.Controls.Add(this.labelX8, 0, 13);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX1, 1, 13);
            this.tableLayoutPanel1.Controls.Add(this.labelX13, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelX9, 6, 0);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX15, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.comboBoxEx2, 7, 0);
            this.tableLayoutPanel1.Font = new System.Drawing.Font("宋体", 11F);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(8, 81);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 14;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.142857F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.142857F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.142857F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.142857F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.142857F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.142857F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.142857F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.142857F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.142857F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.142857F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.142857F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.142857F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.142857F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.142857F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1148, 660);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // labelX2
            // 
            // 
            // 
            // 
            this.labelX2.BackgroundStyle.Class = "";
            this.labelX2.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX2.Location = new System.Drawing.Point(4, 192);
            this.labelX2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX2.Name = "labelX2";
            this.labelX2.Size = new System.Drawing.Size(116, 39);
            this.labelX2.TabIndex = 1;
            this.labelX2.Text = "BIN13";
            // 
            // labelX4
            // 
            // 
            // 
            // 
            this.labelX4.BackgroundStyle.Class = "";
            this.labelX4.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX4.Location = new System.Drawing.Point(4, 239);
            this.labelX4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX4.Name = "labelX4";
            this.labelX4.Size = new System.Drawing.Size(116, 39);
            this.labelX4.TabIndex = 14;
            this.labelX4.Text = "BIN17";
            this.labelX4.Visible = false;
            // 
            // labelX1
            // 
            // 
            // 
            // 
            this.labelX1.BackgroundStyle.Class = "";
            this.labelX1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX1.Location = new System.Drawing.Point(4, 145);
            this.labelX1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX1.Name = "labelX1";
            this.labelX1.Size = new System.Drawing.Size(116, 39);
            this.labelX1.TabIndex = 0;
            this.labelX1.Text = "BIN9";
            // 
            // textBoxX2
            // 
            // 
            // 
            // 
            this.textBoxX2.Border.Class = "TextBoxBorder";
            this.textBoxX2.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX2.Location = new System.Drawing.Point(128, 568);
            this.textBoxX2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX2.Name = "textBoxX2";
            this.textBoxX2.Size = new System.Drawing.Size(155, 46);
            this.textBoxX2.TabIndex = 4;
            // 
            // labelX5
            // 
            // 
            // 
            // 
            this.labelX5.BackgroundStyle.Class = "";
            this.labelX5.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX5.Location = new System.Drawing.Point(4, 4);
            this.labelX5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX5.Name = "labelX5";
            this.labelX5.Size = new System.Drawing.Size(116, 39);
            this.labelX5.TabIndex = 8;
            this.labelX5.Text = "流程卡号";
            // 
            // labelX6
            // 
            // 
            // 
            // 
            this.labelX6.BackgroundStyle.Class = "";
            this.labelX6.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX6.Location = new System.Drawing.Point(4, 51);
            this.labelX6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX6.Name = "labelX6";
            this.labelX6.Size = new System.Drawing.Size(116, 39);
            this.labelX6.TabIndex = 9;
            this.labelX6.Text = "BIN1";
            // 
            // labelX7
            // 
            // 
            // 
            // 
            this.labelX7.BackgroundStyle.Class = "";
            this.labelX7.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX7.Location = new System.Drawing.Point(4, 98);
            this.labelX7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX7.Name = "labelX7";
            this.labelX7.Size = new System.Drawing.Size(116, 39);
            this.labelX7.TabIndex = 10;
            this.labelX7.Text = "BIN5";
            // 
            // labelX11
            // 
            // 
            // 
            // 
            this.labelX11.BackgroundStyle.Class = "";
            this.labelX11.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX11.Location = new System.Drawing.Point(4, 286);
            this.labelX11.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX11.Name = "labelX11";
            this.labelX11.Size = new System.Drawing.Size(116, 39);
            this.labelX11.TabIndex = 16;
            this.labelX11.Text = "BIN21";
            // 
            // labelX3
            // 
            // 
            // 
            // 
            this.labelX3.BackgroundStyle.Class = "";
            this.labelX3.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX3.Location = new System.Drawing.Point(4, 333);
            this.labelX3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX3.Name = "labelX3";
            this.labelX3.Size = new System.Drawing.Size(116, 39);
            this.labelX3.TabIndex = 2;
            this.labelX3.Text = "BIN25";
            // 
            // labelX15
            // 
            // 
            // 
            // 
            this.labelX15.BackgroundStyle.Class = "";
            this.labelX15.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX15.Location = new System.Drawing.Point(865, 51);
            this.labelX15.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX15.Name = "labelX15";
            this.labelX15.Size = new System.Drawing.Size(116, 39);
            this.labelX15.TabIndex = 8;
            this.labelX15.Text = "BIN4";
            // 
            // labelX16
            // 
            // 
            // 
            // 
            this.labelX16.BackgroundStyle.Class = "";
            this.labelX16.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX16.Location = new System.Drawing.Point(865, 98);
            this.labelX16.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX16.Name = "labelX16";
            this.labelX16.Size = new System.Drawing.Size(116, 39);
            this.labelX16.TabIndex = 8;
            this.labelX16.Text = "BIN8";
            // 
            // labelX17
            // 
            // 
            // 
            // 
            this.labelX17.BackgroundStyle.Class = "";
            this.labelX17.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX17.Location = new System.Drawing.Point(865, 145);
            this.labelX17.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX17.Name = "labelX17";
            this.labelX17.Size = new System.Drawing.Size(116, 39);
            this.labelX17.TabIndex = 8;
            this.labelX17.Text = "BIN12";
            // 
            // labelX18
            // 
            // 
            // 
            // 
            this.labelX18.BackgroundStyle.Class = "";
            this.labelX18.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX18.Location = new System.Drawing.Point(865, 192);
            this.labelX18.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX18.Name = "labelX18";
            this.labelX18.Size = new System.Drawing.Size(116, 39);
            this.labelX18.TabIndex = 8;
            this.labelX18.Text = "16";
            // 
            // labelX19
            // 
            // 
            // 
            // 
            this.labelX19.BackgroundStyle.Class = "";
            this.labelX19.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX19.Location = new System.Drawing.Point(865, 239);
            this.labelX19.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX19.Name = "labelX19";
            this.labelX19.Size = new System.Drawing.Size(116, 39);
            this.labelX19.TabIndex = 8;
            this.labelX19.Text = "BIN20";
            // 
            // labelX20
            // 
            // 
            // 
            // 
            this.labelX20.BackgroundStyle.Class = "";
            this.labelX20.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX20.Location = new System.Drawing.Point(865, 286);
            this.labelX20.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX20.Name = "labelX20";
            this.labelX20.Size = new System.Drawing.Size(116, 39);
            this.labelX20.TabIndex = 8;
            this.labelX20.Text = "BIN24";
            // 
            // labelX21
            // 
            // 
            // 
            // 
            this.labelX21.BackgroundStyle.Class = "";
            this.labelX21.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX21.Location = new System.Drawing.Point(865, 333);
            this.labelX21.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX21.Name = "labelX21";
            this.labelX21.Size = new System.Drawing.Size(116, 39);
            this.labelX21.TabIndex = 8;
            this.labelX21.Text = "BIN28";
            // 
            // labelX22
            // 
            // 
            // 
            // 
            this.labelX22.BackgroundStyle.Class = "";
            this.labelX22.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX22.Location = new System.Drawing.Point(865, 380);
            this.labelX22.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX22.Name = "labelX22";
            this.labelX22.Size = new System.Drawing.Size(116, 39);
            this.labelX22.TabIndex = 8;
            this.labelX22.Text = "BIN32";
            // 
            // labelX23
            // 
            // 
            // 
            // 
            this.labelX23.BackgroundStyle.Class = "";
            this.labelX23.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX23.Location = new System.Drawing.Point(865, 427);
            this.labelX23.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX23.Name = "labelX23";
            this.labelX23.Size = new System.Drawing.Size(116, 39);
            this.labelX23.TabIndex = 8;
            this.labelX23.Text = "BIN36";
            // 
            // labelX24
            // 
            // 
            // 
            // 
            this.labelX24.BackgroundStyle.Class = "";
            this.labelX24.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX24.Location = new System.Drawing.Point(865, 474);
            this.labelX24.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX24.Name = "labelX24";
            this.labelX24.Size = new System.Drawing.Size(116, 39);
            this.labelX24.TabIndex = 8;
            this.labelX24.Text = "BIN40";
            // 
            // labelX25
            // 
            // 
            // 
            // 
            this.labelX25.BackgroundStyle.Class = "";
            this.labelX25.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX25.Location = new System.Drawing.Point(865, 521);
            this.labelX25.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX25.Name = "labelX25";
            this.labelX25.Size = new System.Drawing.Size(116, 39);
            this.labelX25.TabIndex = 8;
            this.labelX25.Text = "BIN44";
            // 
            // labelX26
            // 
            // 
            // 
            // 
            this.labelX26.BackgroundStyle.Class = "";
            this.labelX26.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX26.Location = new System.Drawing.Point(865, 568);
            this.labelX26.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX26.Name = "labelX26";
            this.labelX26.Size = new System.Drawing.Size(116, 39);
            this.labelX26.TabIndex = 8;
            this.labelX26.Text = "BIN48";
            // 
            // labelX27
            // 
            // 
            // 
            // 
            this.labelX27.BackgroundStyle.Class = "";
            this.labelX27.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX27.Location = new System.Drawing.Point(578, 568);
            this.labelX27.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX27.Name = "labelX27";
            this.labelX27.Size = new System.Drawing.Size(116, 39);
            this.labelX27.TabIndex = 8;
            this.labelX27.Text = "BIN47";
            // 
            // labelX28
            // 
            // 
            // 
            // 
            this.labelX28.BackgroundStyle.Class = "";
            this.labelX28.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX28.Location = new System.Drawing.Point(578, 521);
            this.labelX28.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX28.Name = "labelX28";
            this.labelX28.Size = new System.Drawing.Size(116, 39);
            this.labelX28.TabIndex = 8;
            this.labelX28.Text = "BIN43";
            // 
            // labelX29
            // 
            // 
            // 
            // 
            this.labelX29.BackgroundStyle.Class = "";
            this.labelX29.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX29.Location = new System.Drawing.Point(578, 474);
            this.labelX29.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX29.Name = "labelX29";
            this.labelX29.Size = new System.Drawing.Size(116, 39);
            this.labelX29.TabIndex = 8;
            this.labelX29.Text = "BIN39";
            // 
            // labelX30
            // 
            // 
            // 
            // 
            this.labelX30.BackgroundStyle.Class = "";
            this.labelX30.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX30.Location = new System.Drawing.Point(578, 427);
            this.labelX30.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX30.Name = "labelX30";
            this.labelX30.Size = new System.Drawing.Size(116, 39);
            this.labelX30.TabIndex = 8;
            this.labelX30.Text = "BIN35";
            // 
            // labelX31
            // 
            // 
            // 
            // 
            this.labelX31.BackgroundStyle.Class = "";
            this.labelX31.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX31.Location = new System.Drawing.Point(578, 380);
            this.labelX31.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX31.Name = "labelX31";
            this.labelX31.Size = new System.Drawing.Size(116, 39);
            this.labelX31.TabIndex = 8;
            this.labelX31.Text = "BIN31";
            // 
            // labelX32
            // 
            // 
            // 
            // 
            this.labelX32.BackgroundStyle.Class = "";
            this.labelX32.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX32.Location = new System.Drawing.Point(578, 333);
            this.labelX32.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX32.Name = "labelX32";
            this.labelX32.Size = new System.Drawing.Size(116, 39);
            this.labelX32.TabIndex = 8;
            this.labelX32.Text = "BIN27";
            // 
            // labelX33
            // 
            // 
            // 
            // 
            this.labelX33.BackgroundStyle.Class = "";
            this.labelX33.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX33.Location = new System.Drawing.Point(578, 286);
            this.labelX33.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX33.Name = "labelX33";
            this.labelX33.Size = new System.Drawing.Size(116, 39);
            this.labelX33.TabIndex = 8;
            this.labelX33.Text = "BIN23";
            // 
            // labelX34
            // 
            // 
            // 
            // 
            this.labelX34.BackgroundStyle.Class = "";
            this.labelX34.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX34.Location = new System.Drawing.Point(578, 239);
            this.labelX34.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX34.Name = "labelX34";
            this.labelX34.Size = new System.Drawing.Size(116, 39);
            this.labelX34.TabIndex = 8;
            this.labelX34.Text = "BIN19";
            // 
            // labelX35
            // 
            // 
            // 
            // 
            this.labelX35.BackgroundStyle.Class = "";
            this.labelX35.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX35.Location = new System.Drawing.Point(578, 192);
            this.labelX35.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX35.Name = "labelX35";
            this.labelX35.Size = new System.Drawing.Size(116, 39);
            this.labelX35.TabIndex = 8;
            this.labelX35.Text = "BIN15";
            // 
            // labelX36
            // 
            // 
            // 
            // 
            this.labelX36.BackgroundStyle.Class = "";
            this.labelX36.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX36.Location = new System.Drawing.Point(578, 145);
            this.labelX36.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX36.Name = "labelX36";
            this.labelX36.Size = new System.Drawing.Size(116, 39);
            this.labelX36.TabIndex = 8;
            this.labelX36.Text = "BIN11";
            // 
            // labelX37
            // 
            // 
            // 
            // 
            this.labelX37.BackgroundStyle.Class = "";
            this.labelX37.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX37.Location = new System.Drawing.Point(578, 98);
            this.labelX37.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX37.Name = "labelX37";
            this.labelX37.Size = new System.Drawing.Size(116, 39);
            this.labelX37.TabIndex = 8;
            this.labelX37.Text = "BIN7";
            // 
            // labelX38
            // 
            // 
            // 
            // 
            this.labelX38.BackgroundStyle.Class = "";
            this.labelX38.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX38.Location = new System.Drawing.Point(578, 51);
            this.labelX38.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX38.Name = "labelX38";
            this.labelX38.Size = new System.Drawing.Size(116, 39);
            this.labelX38.TabIndex = 8;
            this.labelX38.Text = "BIN3";
            // 
            // labelX39
            // 
            // 
            // 
            // 
            this.labelX39.BackgroundStyle.Class = "";
            this.labelX39.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX39.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX39.Location = new System.Drawing.Point(291, 51);
            this.labelX39.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX39.Name = "labelX39";
            this.labelX39.Size = new System.Drawing.Size(116, 39);
            this.labelX39.TabIndex = 8;
            this.labelX39.Text = "BIN2";
            // 
            // labelX40
            // 
            // 
            // 
            // 
            this.labelX40.BackgroundStyle.Class = "";
            this.labelX40.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX40.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX40.Location = new System.Drawing.Point(291, 98);
            this.labelX40.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX40.Name = "labelX40";
            this.labelX40.Size = new System.Drawing.Size(116, 39);
            this.labelX40.TabIndex = 8;
            this.labelX40.Text = "BIN6";
            // 
            // labelX41
            // 
            // 
            // 
            // 
            this.labelX41.BackgroundStyle.Class = "";
            this.labelX41.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX41.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX41.Location = new System.Drawing.Point(291, 145);
            this.labelX41.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX41.Name = "labelX41";
            this.labelX41.Size = new System.Drawing.Size(116, 39);
            this.labelX41.TabIndex = 8;
            this.labelX41.Text = "BIN10";
            // 
            // labelX42
            // 
            // 
            // 
            // 
            this.labelX42.BackgroundStyle.Class = "";
            this.labelX42.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX42.Location = new System.Drawing.Point(291, 192);
            this.labelX42.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX42.Name = "labelX42";
            this.labelX42.Size = new System.Drawing.Size(116, 39);
            this.labelX42.TabIndex = 8;
            this.labelX42.Text = "BIN14";
            // 
            // labelX43
            // 
            // 
            // 
            // 
            this.labelX43.BackgroundStyle.Class = "";
            this.labelX43.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX43.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX43.Location = new System.Drawing.Point(291, 239);
            this.labelX43.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX43.Name = "labelX43";
            this.labelX43.Size = new System.Drawing.Size(116, 39);
            this.labelX43.TabIndex = 8;
            this.labelX43.Text = "BIN18";
            // 
            // labelX44
            // 
            // 
            // 
            // 
            this.labelX44.BackgroundStyle.Class = "";
            this.labelX44.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX44.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX44.Location = new System.Drawing.Point(291, 286);
            this.labelX44.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX44.Name = "labelX44";
            this.labelX44.Size = new System.Drawing.Size(116, 39);
            this.labelX44.TabIndex = 8;
            this.labelX44.Text = "BIN22";
            // 
            // labelX45
            // 
            // 
            // 
            // 
            this.labelX45.BackgroundStyle.Class = "";
            this.labelX45.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX45.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX45.Location = new System.Drawing.Point(291, 333);
            this.labelX45.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX45.Name = "labelX45";
            this.labelX45.Size = new System.Drawing.Size(116, 39);
            this.labelX45.TabIndex = 8;
            this.labelX45.Text = "BIN26";
            // 
            // labelX46
            // 
            // 
            // 
            // 
            this.labelX46.BackgroundStyle.Class = "";
            this.labelX46.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX46.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX46.Location = new System.Drawing.Point(291, 380);
            this.labelX46.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX46.Name = "labelX46";
            this.labelX46.Size = new System.Drawing.Size(116, 39);
            this.labelX46.TabIndex = 8;
            this.labelX46.Text = "BIN30";
            // 
            // labelX47
            // 
            // 
            // 
            // 
            this.labelX47.BackgroundStyle.Class = "";
            this.labelX47.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX47.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX47.Location = new System.Drawing.Point(291, 427);
            this.labelX47.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX47.Name = "labelX47";
            this.labelX47.Size = new System.Drawing.Size(116, 39);
            this.labelX47.TabIndex = 8;
            this.labelX47.Text = "BIN34";
            // 
            // labelX48
            // 
            // 
            // 
            // 
            this.labelX48.BackgroundStyle.Class = "";
            this.labelX48.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX48.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX48.Location = new System.Drawing.Point(291, 474);
            this.labelX48.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX48.Name = "labelX48";
            this.labelX48.Size = new System.Drawing.Size(116, 39);
            this.labelX48.TabIndex = 8;
            this.labelX48.Text = "BIN38";
            // 
            // labelX49
            // 
            // 
            // 
            // 
            this.labelX49.BackgroundStyle.Class = "";
            this.labelX49.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX49.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX49.Location = new System.Drawing.Point(291, 521);
            this.labelX49.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX49.Name = "labelX49";
            this.labelX49.Size = new System.Drawing.Size(116, 39);
            this.labelX49.TabIndex = 8;
            this.labelX49.Text = "BIN42";
            // 
            // labelX50
            // 
            // 
            // 
            // 
            this.labelX50.BackgroundStyle.Class = "";
            this.labelX50.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX50.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX50.Location = new System.Drawing.Point(291, 568);
            this.labelX50.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX50.Name = "labelX50";
            this.labelX50.Size = new System.Drawing.Size(116, 39);
            this.labelX50.TabIndex = 8;
            this.labelX50.Text = "BIN46";
            // 
            // labelX51
            // 
            // 
            // 
            // 
            this.labelX51.BackgroundStyle.Class = "";
            this.labelX51.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX51.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX51.Location = new System.Drawing.Point(4, 568);
            this.labelX51.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX51.Name = "labelX51";
            this.labelX51.Size = new System.Drawing.Size(116, 39);
            this.labelX51.TabIndex = 8;
            this.labelX51.Text = "BIN45";
            // 
            // labelX52
            // 
            // 
            // 
            // 
            this.labelX52.BackgroundStyle.Class = "";
            this.labelX52.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX52.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX52.Location = new System.Drawing.Point(4, 521);
            this.labelX52.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX52.Name = "labelX52";
            this.labelX52.Size = new System.Drawing.Size(116, 39);
            this.labelX52.TabIndex = 8;
            this.labelX52.Text = "BIN41";
            // 
            // labelX53
            // 
            // 
            // 
            // 
            this.labelX53.BackgroundStyle.Class = "";
            this.labelX53.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX53.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX53.Location = new System.Drawing.Point(4, 474);
            this.labelX53.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX53.Name = "labelX53";
            this.labelX53.Size = new System.Drawing.Size(116, 39);
            this.labelX53.TabIndex = 8;
            this.labelX53.Text = "BIN37";
            // 
            // labelX54
            // 
            // 
            // 
            // 
            this.labelX54.BackgroundStyle.Class = "";
            this.labelX54.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX54.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX54.Location = new System.Drawing.Point(4, 427);
            this.labelX54.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX54.Name = "labelX54";
            this.labelX54.Size = new System.Drawing.Size(116, 39);
            this.labelX54.TabIndex = 8;
            this.labelX54.Text = "BIN33";
            // 
            // labelX55
            // 
            // 
            // 
            // 
            this.labelX55.BackgroundStyle.Class = "";
            this.labelX55.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX55.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX55.Location = new System.Drawing.Point(4, 380);
            this.labelX55.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX55.Name = "labelX55";
            this.labelX55.Size = new System.Drawing.Size(116, 39);
            this.labelX55.TabIndex = 8;
            this.labelX55.Text = "BIN29";
            // 
            // textBoxX3
            // 
            // 
            // 
            // 
            this.textBoxX3.Border.Class = "TextBoxBorder";
            this.textBoxX3.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX3.Location = new System.Drawing.Point(128, 521);
            this.textBoxX3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX3.Name = "textBoxX3";
            this.textBoxX3.Size = new System.Drawing.Size(155, 46);
            this.textBoxX3.TabIndex = 4;
            // 
            // textBoxX4
            // 
            // 
            // 
            // 
            this.textBoxX4.Border.Class = "TextBoxBorder";
            this.textBoxX4.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX4.Location = new System.Drawing.Point(128, 474);
            this.textBoxX4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX4.Name = "textBoxX4";
            this.textBoxX4.Size = new System.Drawing.Size(155, 46);
            this.textBoxX4.TabIndex = 4;
            // 
            // textBoxX5
            // 
            // 
            // 
            // 
            this.textBoxX5.Border.Class = "TextBoxBorder";
            this.textBoxX5.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX5.Location = new System.Drawing.Point(128, 427);
            this.textBoxX5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX5.Name = "textBoxX5";
            this.textBoxX5.Size = new System.Drawing.Size(155, 46);
            this.textBoxX5.TabIndex = 4;
            // 
            // textBoxX6
            // 
            // 
            // 
            // 
            this.textBoxX6.Border.Class = "TextBoxBorder";
            this.textBoxX6.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX6.Location = new System.Drawing.Point(128, 380);
            this.textBoxX6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX6.Name = "textBoxX6";
            this.textBoxX6.Size = new System.Drawing.Size(155, 46);
            this.textBoxX6.TabIndex = 4;
            // 
            // textBoxX7
            // 
            // 
            // 
            // 
            this.textBoxX7.Border.Class = "TextBoxBorder";
            this.textBoxX7.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX7.Location = new System.Drawing.Point(128, 333);
            this.textBoxX7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX7.Name = "textBoxX7";
            this.textBoxX7.Size = new System.Drawing.Size(155, 46);
            this.textBoxX7.TabIndex = 4;
            // 
            // textBoxX8
            // 
            // 
            // 
            // 
            this.textBoxX8.Border.Class = "TextBoxBorder";
            this.textBoxX8.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX8.Location = new System.Drawing.Point(128, 286);
            this.textBoxX8.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX8.Name = "textBoxX8";
            this.textBoxX8.Size = new System.Drawing.Size(155, 46);
            this.textBoxX8.TabIndex = 4;
            // 
            // textBoxX9
            // 
            // 
            // 
            // 
            this.textBoxX9.Border.Class = "TextBoxBorder";
            this.textBoxX9.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX9.Location = new System.Drawing.Point(128, 239);
            this.textBoxX9.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX9.Name = "textBoxX9";
            this.textBoxX9.Size = new System.Drawing.Size(155, 46);
            this.textBoxX9.TabIndex = 4;
            // 
            // textBoxX10
            // 
            // 
            // 
            // 
            this.textBoxX10.Border.Class = "TextBoxBorder";
            this.textBoxX10.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX10.Location = new System.Drawing.Point(128, 145);
            this.textBoxX10.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX10.Name = "textBoxX10";
            this.textBoxX10.Size = new System.Drawing.Size(155, 46);
            this.textBoxX10.TabIndex = 4;
            // 
            // textBoxX11
            // 
            // 
            // 
            // 
            this.textBoxX11.Border.Class = "TextBoxBorder";
            this.textBoxX11.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX11.Location = new System.Drawing.Point(128, 192);
            this.textBoxX11.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX11.Name = "textBoxX11";
            this.textBoxX11.Size = new System.Drawing.Size(155, 46);
            this.textBoxX11.TabIndex = 4;
            // 
            // textBoxX12
            // 
            // 
            // 
            // 
            this.textBoxX12.Border.Class = "TextBoxBorder";
            this.textBoxX12.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX12.Location = new System.Drawing.Point(128, 98);
            this.textBoxX12.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX12.Name = "textBoxX12";
            this.textBoxX12.Size = new System.Drawing.Size(155, 46);
            this.textBoxX12.TabIndex = 4;
            // 
            // textBoxX13
            // 
            // 
            // 
            // 
            this.textBoxX13.Border.Class = "TextBoxBorder";
            this.textBoxX13.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX13.Location = new System.Drawing.Point(128, 51);
            this.textBoxX13.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX13.Name = "textBoxX13";
            this.textBoxX13.Size = new System.Drawing.Size(155, 46);
            this.textBoxX13.TabIndex = 4;
            // 
            // textBoxX14
            // 
            // 
            // 
            // 
            this.textBoxX14.Border.Class = "TextBoxBorder";
            this.textBoxX14.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX14.Location = new System.Drawing.Point(128, 4);
            this.textBoxX14.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX14.Name = "textBoxX14";
            this.textBoxX14.Size = new System.Drawing.Size(155, 46);
            this.textBoxX14.TabIndex = 4;
            // 
            // textBoxX16
            // 
            // 
            // 
            // 
            this.textBoxX16.Border.Class = "TextBoxBorder";
            this.textBoxX16.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX16.Location = new System.Drawing.Point(415, 51);
            this.textBoxX16.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX16.Name = "textBoxX16";
            this.textBoxX16.Size = new System.Drawing.Size(155, 46);
            this.textBoxX16.TabIndex = 4;
            // 
            // textBoxX17
            // 
            // 
            // 
            // 
            this.textBoxX17.Border.Class = "TextBoxBorder";
            this.textBoxX17.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX17.Location = new System.Drawing.Point(415, 98);
            this.textBoxX17.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX17.Name = "textBoxX17";
            this.textBoxX17.Size = new System.Drawing.Size(155, 46);
            this.textBoxX17.TabIndex = 4;
            // 
            // textBoxX18
            // 
            // 
            // 
            // 
            this.textBoxX18.Border.Class = "TextBoxBorder";
            this.textBoxX18.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX18.Location = new System.Drawing.Point(415, 145);
            this.textBoxX18.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX18.Name = "textBoxX18";
            this.textBoxX18.Size = new System.Drawing.Size(155, 46);
            this.textBoxX18.TabIndex = 4;
            // 
            // textBoxX19
            // 
            // 
            // 
            // 
            this.textBoxX19.Border.Class = "TextBoxBorder";
            this.textBoxX19.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX19.Location = new System.Drawing.Point(415, 192);
            this.textBoxX19.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX19.Name = "textBoxX19";
            this.textBoxX19.Size = new System.Drawing.Size(155, 46);
            this.textBoxX19.TabIndex = 4;
            // 
            // textBoxX20
            // 
            // 
            // 
            // 
            this.textBoxX20.Border.Class = "TextBoxBorder";
            this.textBoxX20.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX20.Location = new System.Drawing.Point(415, 239);
            this.textBoxX20.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX20.Name = "textBoxX20";
            this.textBoxX20.Size = new System.Drawing.Size(155, 46);
            this.textBoxX20.TabIndex = 4;
            // 
            // textBoxX21
            // 
            // 
            // 
            // 
            this.textBoxX21.Border.Class = "TextBoxBorder";
            this.textBoxX21.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX21.Location = new System.Drawing.Point(415, 286);
            this.textBoxX21.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX21.Name = "textBoxX21";
            this.textBoxX21.Size = new System.Drawing.Size(155, 46);
            this.textBoxX21.TabIndex = 4;
            // 
            // textBoxX22
            // 
            // 
            // 
            // 
            this.textBoxX22.Border.Class = "TextBoxBorder";
            this.textBoxX22.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX22.Location = new System.Drawing.Point(415, 333);
            this.textBoxX22.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX22.Name = "textBoxX22";
            this.textBoxX22.Size = new System.Drawing.Size(155, 46);
            this.textBoxX22.TabIndex = 4;
            // 
            // textBoxX23
            // 
            // 
            // 
            // 
            this.textBoxX23.Border.Class = "TextBoxBorder";
            this.textBoxX23.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX23.Location = new System.Drawing.Point(415, 380);
            this.textBoxX23.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX23.Name = "textBoxX23";
            this.textBoxX23.Size = new System.Drawing.Size(155, 46);
            this.textBoxX23.TabIndex = 4;
            // 
            // textBoxX24
            // 
            // 
            // 
            // 
            this.textBoxX24.Border.Class = "TextBoxBorder";
            this.textBoxX24.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX24.Location = new System.Drawing.Point(415, 427);
            this.textBoxX24.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX24.Name = "textBoxX24";
            this.textBoxX24.Size = new System.Drawing.Size(155, 46);
            this.textBoxX24.TabIndex = 4;
            // 
            // textBoxX25
            // 
            // 
            // 
            // 
            this.textBoxX25.Border.Class = "TextBoxBorder";
            this.textBoxX25.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX25.Location = new System.Drawing.Point(415, 474);
            this.textBoxX25.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX25.Name = "textBoxX25";
            this.textBoxX25.Size = new System.Drawing.Size(155, 46);
            this.textBoxX25.TabIndex = 4;
            // 
            // textBoxX26
            // 
            // 
            // 
            // 
            this.textBoxX26.Border.Class = "TextBoxBorder";
            this.textBoxX26.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX26.Location = new System.Drawing.Point(415, 521);
            this.textBoxX26.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX26.Name = "textBoxX26";
            this.textBoxX26.Size = new System.Drawing.Size(155, 46);
            this.textBoxX26.TabIndex = 4;
            // 
            // textBoxX27
            // 
            // 
            // 
            // 
            this.textBoxX27.Border.Class = "TextBoxBorder";
            this.textBoxX27.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX27.Location = new System.Drawing.Point(415, 568);
            this.textBoxX27.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX27.Name = "textBoxX27";
            this.textBoxX27.Size = new System.Drawing.Size(155, 46);
            this.textBoxX27.TabIndex = 4;
            // 
            // textBoxX28
            // 
            // 
            // 
            // 
            this.textBoxX28.Border.Class = "TextBoxBorder";
            this.textBoxX28.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX28.Location = new System.Drawing.Point(702, 568);
            this.textBoxX28.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX28.Name = "textBoxX28";
            this.textBoxX28.Size = new System.Drawing.Size(155, 46);
            this.textBoxX28.TabIndex = 4;
            // 
            // textBoxX29
            // 
            // 
            // 
            // 
            this.textBoxX29.Border.Class = "TextBoxBorder";
            this.textBoxX29.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX29.Location = new System.Drawing.Point(702, 521);
            this.textBoxX29.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX29.Name = "textBoxX29";
            this.textBoxX29.Size = new System.Drawing.Size(155, 46);
            this.textBoxX29.TabIndex = 4;
            // 
            // textBoxX30
            // 
            // 
            // 
            // 
            this.textBoxX30.Border.Class = "TextBoxBorder";
            this.textBoxX30.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX30.Location = new System.Drawing.Point(702, 474);
            this.textBoxX30.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX30.Name = "textBoxX30";
            this.textBoxX30.Size = new System.Drawing.Size(155, 46);
            this.textBoxX30.TabIndex = 4;
            // 
            // textBoxX31
            // 
            // 
            // 
            // 
            this.textBoxX31.Border.Class = "TextBoxBorder";
            this.textBoxX31.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX31.Location = new System.Drawing.Point(702, 427);
            this.textBoxX31.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX31.Name = "textBoxX31";
            this.textBoxX31.Size = new System.Drawing.Size(155, 46);
            this.textBoxX31.TabIndex = 4;
            // 
            // textBoxX32
            // 
            // 
            // 
            // 
            this.textBoxX32.Border.Class = "TextBoxBorder";
            this.textBoxX32.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX32.Location = new System.Drawing.Point(702, 380);
            this.textBoxX32.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX32.Name = "textBoxX32";
            this.textBoxX32.Size = new System.Drawing.Size(155, 46);
            this.textBoxX32.TabIndex = 4;
            // 
            // textBoxX33
            // 
            // 
            // 
            // 
            this.textBoxX33.Border.Class = "TextBoxBorder";
            this.textBoxX33.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX33.Location = new System.Drawing.Point(702, 333);
            this.textBoxX33.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX33.Name = "textBoxX33";
            this.textBoxX33.Size = new System.Drawing.Size(155, 46);
            this.textBoxX33.TabIndex = 4;
            // 
            // textBoxX34
            // 
            // 
            // 
            // 
            this.textBoxX34.Border.Class = "TextBoxBorder";
            this.textBoxX34.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX34.Location = new System.Drawing.Point(702, 286);
            this.textBoxX34.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX34.Name = "textBoxX34";
            this.textBoxX34.Size = new System.Drawing.Size(155, 46);
            this.textBoxX34.TabIndex = 4;
            // 
            // textBoxX35
            // 
            // 
            // 
            // 
            this.textBoxX35.Border.Class = "TextBoxBorder";
            this.textBoxX35.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX35.Location = new System.Drawing.Point(702, 239);
            this.textBoxX35.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX35.Name = "textBoxX35";
            this.textBoxX35.Size = new System.Drawing.Size(155, 46);
            this.textBoxX35.TabIndex = 4;
            // 
            // textBoxX36
            // 
            // 
            // 
            // 
            this.textBoxX36.Border.Class = "TextBoxBorder";
            this.textBoxX36.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX36.Location = new System.Drawing.Point(702, 192);
            this.textBoxX36.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX36.Name = "textBoxX36";
            this.textBoxX36.Size = new System.Drawing.Size(155, 46);
            this.textBoxX36.TabIndex = 4;
            // 
            // textBoxX37
            // 
            // 
            // 
            // 
            this.textBoxX37.Border.Class = "TextBoxBorder";
            this.textBoxX37.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX37.Location = new System.Drawing.Point(702, 145);
            this.textBoxX37.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX37.Name = "textBoxX37";
            this.textBoxX37.Size = new System.Drawing.Size(155, 46);
            this.textBoxX37.TabIndex = 4;
            // 
            // textBoxX38
            // 
            // 
            // 
            // 
            this.textBoxX38.Border.Class = "TextBoxBorder";
            this.textBoxX38.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX38.Location = new System.Drawing.Point(702, 98);
            this.textBoxX38.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX38.Name = "textBoxX38";
            this.textBoxX38.Size = new System.Drawing.Size(155, 46);
            this.textBoxX38.TabIndex = 4;
            // 
            // textBoxX39
            // 
            // 
            // 
            // 
            this.textBoxX39.Border.Class = "TextBoxBorder";
            this.textBoxX39.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX39.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX39.Location = new System.Drawing.Point(702, 51);
            this.textBoxX39.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX39.Name = "textBoxX39";
            this.textBoxX39.Size = new System.Drawing.Size(155, 46);
            this.textBoxX39.TabIndex = 4;
            // 
            // textBoxX40
            // 
            // 
            // 
            // 
            this.textBoxX40.Border.Class = "TextBoxBorder";
            this.textBoxX40.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX40.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX40.Location = new System.Drawing.Point(989, 51);
            this.textBoxX40.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX40.Name = "textBoxX40";
            this.textBoxX40.Size = new System.Drawing.Size(155, 46);
            this.textBoxX40.TabIndex = 4;
            // 
            // textBoxX41
            // 
            // 
            // 
            // 
            this.textBoxX41.Border.Class = "TextBoxBorder";
            this.textBoxX41.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX41.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX41.Location = new System.Drawing.Point(989, 98);
            this.textBoxX41.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX41.Name = "textBoxX41";
            this.textBoxX41.Size = new System.Drawing.Size(155, 46);
            this.textBoxX41.TabIndex = 4;
            // 
            // textBoxX42
            // 
            // 
            // 
            // 
            this.textBoxX42.Border.Class = "TextBoxBorder";
            this.textBoxX42.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX42.Location = new System.Drawing.Point(989, 145);
            this.textBoxX42.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX42.Name = "textBoxX42";
            this.textBoxX42.Size = new System.Drawing.Size(155, 46);
            this.textBoxX42.TabIndex = 4;
            // 
            // textBoxX43
            // 
            // 
            // 
            // 
            this.textBoxX43.Border.Class = "TextBoxBorder";
            this.textBoxX43.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX43.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX43.Location = new System.Drawing.Point(989, 192);
            this.textBoxX43.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX43.Name = "textBoxX43";
            this.textBoxX43.Size = new System.Drawing.Size(155, 46);
            this.textBoxX43.TabIndex = 4;
            // 
            // textBoxX44
            // 
            // 
            // 
            // 
            this.textBoxX44.Border.Class = "TextBoxBorder";
            this.textBoxX44.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX44.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX44.Location = new System.Drawing.Point(989, 239);
            this.textBoxX44.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX44.Name = "textBoxX44";
            this.textBoxX44.Size = new System.Drawing.Size(155, 46);
            this.textBoxX44.TabIndex = 4;
            // 
            // textBoxX45
            // 
            // 
            // 
            // 
            this.textBoxX45.Border.Class = "TextBoxBorder";
            this.textBoxX45.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX45.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX45.Location = new System.Drawing.Point(989, 286);
            this.textBoxX45.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX45.Name = "textBoxX45";
            this.textBoxX45.Size = new System.Drawing.Size(155, 46);
            this.textBoxX45.TabIndex = 4;
            // 
            // textBoxX46
            // 
            // 
            // 
            // 
            this.textBoxX46.Border.Class = "TextBoxBorder";
            this.textBoxX46.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX46.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX46.Location = new System.Drawing.Point(989, 333);
            this.textBoxX46.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX46.Name = "textBoxX46";
            this.textBoxX46.Size = new System.Drawing.Size(155, 46);
            this.textBoxX46.TabIndex = 4;
            // 
            // textBoxX47
            // 
            // 
            // 
            // 
            this.textBoxX47.Border.Class = "TextBoxBorder";
            this.textBoxX47.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX47.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX47.Location = new System.Drawing.Point(989, 380);
            this.textBoxX47.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX47.Name = "textBoxX47";
            this.textBoxX47.Size = new System.Drawing.Size(155, 46);
            this.textBoxX47.TabIndex = 4;
            // 
            // textBoxX48
            // 
            // 
            // 
            // 
            this.textBoxX48.Border.Class = "TextBoxBorder";
            this.textBoxX48.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX48.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX48.Location = new System.Drawing.Point(989, 427);
            this.textBoxX48.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX48.Name = "textBoxX48";
            this.textBoxX48.Size = new System.Drawing.Size(155, 46);
            this.textBoxX48.TabIndex = 4;
            // 
            // textBoxX49
            // 
            // 
            // 
            // 
            this.textBoxX49.Border.Class = "TextBoxBorder";
            this.textBoxX49.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX49.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX49.Location = new System.Drawing.Point(989, 474);
            this.textBoxX49.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX49.Name = "textBoxX49";
            this.textBoxX49.Size = new System.Drawing.Size(155, 46);
            this.textBoxX49.TabIndex = 4;
            // 
            // textBoxX50
            // 
            // 
            // 
            // 
            this.textBoxX50.Border.Class = "TextBoxBorder";
            this.textBoxX50.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX50.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX50.Location = new System.Drawing.Point(989, 521);
            this.textBoxX50.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX50.Name = "textBoxX50";
            this.textBoxX50.Size = new System.Drawing.Size(155, 46);
            this.textBoxX50.TabIndex = 4;
            // 
            // textBoxX51
            // 
            // 
            // 
            // 
            this.textBoxX51.Border.Class = "TextBoxBorder";
            this.textBoxX51.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX51.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX51.Location = new System.Drawing.Point(989, 568);
            this.textBoxX51.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX51.Name = "textBoxX51";
            this.textBoxX51.Size = new System.Drawing.Size(155, 46);
            this.textBoxX51.TabIndex = 4;
            // 
            // labelX8
            // 
            // 
            // 
            // 
            this.labelX8.BackgroundStyle.Class = "";
            this.labelX8.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX8.Location = new System.Drawing.Point(4, 615);
            this.labelX8.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX8.Name = "labelX8";
            this.labelX8.Size = new System.Drawing.Size(116, 41);
            this.labelX8.TabIndex = 8;
            this.labelX8.Text = "备注";
            // 
            // textBoxX1
            // 
            // 
            // 
            // 
            this.textBoxX1.Border.Class = "TextBoxBorder";
            this.textBoxX1.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.tableLayoutPanel1.SetColumnSpan(this.textBoxX1, 7);
            this.textBoxX1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX1.Location = new System.Drawing.Point(128, 615);
            this.textBoxX1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX1.Name = "textBoxX1";
            this.textBoxX1.Size = new System.Drawing.Size(1016, 46);
            this.textBoxX1.TabIndex = 4;
            // 
            // labelX13
            // 
            // 
            // 
            // 
            this.labelX13.BackgroundStyle.Class = "";
            this.labelX13.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX13.Location = new System.Drawing.Point(291, 4);
            this.labelX13.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX13.Name = "labelX13";
            this.labelX13.Size = new System.Drawing.Size(116, 39);
            this.labelX13.TabIndex = 8;
            this.labelX13.Text = "型号";
            // 
            // labelX9
            // 
            // 
            // 
            // 
            this.labelX9.BackgroundStyle.Class = "";
            this.labelX9.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX9.Location = new System.Drawing.Point(865, 4);
            this.labelX9.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX9.Name = "labelX9";
            this.labelX9.Size = new System.Drawing.Size(116, 39);
            this.labelX9.TabIndex = 8;
            this.labelX9.Text = "型号";
            // 
            // textBoxX15
            // 
            // 
            // 
            // 
            this.textBoxX15.Border.Class = "TextBoxBorder";
            this.textBoxX15.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX15.Location = new System.Drawing.Point(415, 4);
            this.textBoxX15.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX15.Name = "textBoxX15";
            this.textBoxX15.Size = new System.Drawing.Size(155, 46);
            this.textBoxX15.TabIndex = 4;
            // 
            // comboBoxEx2
            // 
            this.comboBoxEx2.DisplayMember = "Text";
            this.comboBoxEx2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxEx2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.comboBoxEx2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxEx2.FormattingEnabled = true;
            this.comboBoxEx2.ItemHeight = 27;
            this.comboBoxEx2.Items.AddRange(new object[] {
            this.comboItem1,
            this.comboItem2,
            this.comboItem3});
            this.comboBoxEx2.Location = new System.Drawing.Point(989, 5);
            this.comboBoxEx2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comboBoxEx2.Name = "comboBoxEx2";
            this.comboBoxEx2.Size = new System.Drawing.Size(155, 33);
            this.comboBoxEx2.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.comboBoxEx2.TabIndex = 35;
            // 
            // comboItem1
            // 
            this.comboItem1.Text = "工程批";
            // 
            // comboItem2
            // 
            this.comboItem2.Text = "量产批";
            // 
            // comboItem3
            // 
            this.comboItem3.Text = "已停用";
            // 
            // 其他信息打印
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1168, 756);
            this.Controls.Add(this.groupPanel1);
            this.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Name = "其他信息打印";
            this.Text = "其他信息打印";
            this.groupPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private DevComponents.DotNetBar.ButtonX buttonX2;
        private DevComponents.DotNetBar.ButtonX buttonX1;
        private DevComponents.DotNetBar.Controls.GroupPanel groupPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private DevComponents.DotNetBar.LabelX labelX2;
        private DevComponents.DotNetBar.LabelX labelX4;
        private DevComponents.DotNetBar.LabelX labelX1;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX2;
        private DevComponents.DotNetBar.LabelX labelX5;
        private DevComponents.DotNetBar.LabelX labelX6;
        private DevComponents.DotNetBar.LabelX labelX7;
        private DevComponents.DotNetBar.LabelX labelX11;
        private DevComponents.DotNetBar.LabelX labelX3;
        private DevComponents.DotNetBar.LabelX labelX13;
        private DevComponents.DotNetBar.LabelX labelX15;
        private DevComponents.DotNetBar.LabelX labelX16;
        private DevComponents.DotNetBar.LabelX labelX17;
        private DevComponents.DotNetBar.LabelX labelX18;
        private DevComponents.DotNetBar.LabelX labelX19;
        private DevComponents.DotNetBar.LabelX labelX20;
        private DevComponents.DotNetBar.LabelX labelX21;
        private DevComponents.DotNetBar.LabelX labelX22;
        private DevComponents.DotNetBar.LabelX labelX23;
        private DevComponents.DotNetBar.LabelX labelX24;
        private DevComponents.DotNetBar.LabelX labelX25;
        private DevComponents.DotNetBar.LabelX labelX26;
        private DevComponents.DotNetBar.LabelX labelX27;
        private DevComponents.DotNetBar.LabelX labelX28;
        private DevComponents.DotNetBar.LabelX labelX29;
        private DevComponents.DotNetBar.LabelX labelX30;
        private DevComponents.DotNetBar.LabelX labelX31;
        private DevComponents.DotNetBar.LabelX labelX32;
        private DevComponents.DotNetBar.LabelX labelX33;
        private DevComponents.DotNetBar.LabelX labelX34;
        private DevComponents.DotNetBar.LabelX labelX35;
        private DevComponents.DotNetBar.LabelX labelX36;
        private DevComponents.DotNetBar.LabelX labelX37;
        private DevComponents.DotNetBar.LabelX labelX38;
        private DevComponents.DotNetBar.LabelX labelX39;
        private DevComponents.DotNetBar.LabelX labelX40;
        private DevComponents.DotNetBar.LabelX labelX41;
        private DevComponents.DotNetBar.LabelX labelX42;
        private DevComponents.DotNetBar.LabelX labelX43;
        private DevComponents.DotNetBar.LabelX labelX44;
        private DevComponents.DotNetBar.LabelX labelX45;
        private DevComponents.DotNetBar.LabelX labelX46;
        private DevComponents.DotNetBar.LabelX labelX47;
        private DevComponents.DotNetBar.LabelX labelX48;
        private DevComponents.DotNetBar.LabelX labelX49;
        private DevComponents.DotNetBar.LabelX labelX50;
        private DevComponents.DotNetBar.LabelX labelX51;
        private DevComponents.DotNetBar.LabelX labelX52;
        private DevComponents.DotNetBar.LabelX labelX53;
        private DevComponents.DotNetBar.LabelX labelX54;
        private DevComponents.DotNetBar.LabelX labelX55;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX3;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX4;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX5;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX6;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX7;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX8;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX9;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX10;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX11;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX12;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX13;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX14;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX15;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX16;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX17;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX18;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX19;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX20;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX21;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX22;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX23;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX24;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX25;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX26;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX27;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX28;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX29;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX30;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX31;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX32;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX33;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX34;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX35;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX36;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX37;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX38;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX39;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX40;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX41;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX42;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX43;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX44;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX45;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX46;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX47;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX48;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX49;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX50;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX51;
        private DevComponents.DotNetBar.LabelX labelX8;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX1;
        private DevComponents.DotNetBar.LabelX labelX9;
        private DevComponents.DotNetBar.Controls.ComboBoxEx comboBoxEx2;
        private DevComponents.Editors.ComboItem comboItem1;
        private DevComponents.Editors.ComboItem comboItem2;
        private DevComponents.Editors.ComboItem comboItem3;
    }
}
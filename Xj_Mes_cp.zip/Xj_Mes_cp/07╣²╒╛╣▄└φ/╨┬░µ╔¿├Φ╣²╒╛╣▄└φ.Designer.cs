﻿namespace Xj_Mes_cp
{
    partial class 新版扫描过站管理
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(新版扫描过站管理));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            this.groupPanel1 = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.buttonX6 = new DevComponents.DotNetBar.ButtonX();
            this.buttonX5 = new DevComponents.DotNetBar.ButtonX();
            this.buttonX3 = new DevComponents.DotNetBar.ButtonX();
            this.buttonX1 = new DevComponents.DotNetBar.ButtonX();
            this.superTabControl1 = new DevComponents.DotNetBar.SuperTabControl();
            this.superTabControlPanel3 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.pwtSearchBox6 = new Pawote.UI.Controls.PwtSearchBox();
            this.pwtSearchBox5 = new Pawote.UI.Controls.PwtSearchBox();
            this.superTabItem3 = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel1 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.pwtDataGridView1 = new Pawote.UI.Controls.PwtDataGridView();
            this.superTabItem1 = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel2 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.pwtDataGridView2 = new Pawote.UI.Controls.PwtDataGridView();
            this.superTabItem2 = new DevComponents.DotNetBar.SuperTabItem();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.pwtSearchBox1 = new Pawote.UI.Controls.PwtSearchBox();
            this.labelX1 = new DevComponents.DotNetBar.LabelX();
            this.labelX2 = new DevComponents.DotNetBar.LabelX();
            this.labelX3 = new DevComponents.DotNetBar.LabelX();
            this.labelX4 = new DevComponents.DotNetBar.LabelX();
            this.textBoxX1 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX2 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX3 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX7 = new DevComponents.DotNetBar.LabelX();
            this.labelX8 = new DevComponents.DotNetBar.LabelX();
            this.labelX9 = new DevComponents.DotNetBar.LabelX();
            this.labelX5 = new DevComponents.DotNetBar.LabelX();
            this.labelX10 = new DevComponents.DotNetBar.LabelX();
            this.labelX11 = new DevComponents.DotNetBar.LabelX();
            this.labelX12 = new DevComponents.DotNetBar.LabelX();
            this.labelX13 = new DevComponents.DotNetBar.LabelX();
            this.labelX14 = new DevComponents.DotNetBar.LabelX();
            this.labelX15 = new DevComponents.DotNetBar.LabelX();
            this.labelX16 = new DevComponents.DotNetBar.LabelX();
            this.textBoxX4 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX20 = new DevComponents.DotNetBar.LabelX();
            this.textBoxX5 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX6 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX7 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX8 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX9 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX22 = new DevComponents.DotNetBar.LabelX();
            this.buttonX2 = new DevComponents.DotNetBar.ButtonX();
            this.labelX17 = new DevComponents.DotNetBar.LabelX();
            this.pwtSearchBox2 = new Pawote.UI.Controls.PwtSearchBox();
            this.labelX18 = new DevComponents.DotNetBar.LabelX();
            this.pwtSearchBox3 = new Pawote.UI.Controls.PwtSearchBox();
            this.labelX19 = new DevComponents.DotNetBar.LabelX();
            this.pwtSearchBox4 = new Pawote.UI.Controls.PwtSearchBox();
            this.labelX6 = new DevComponents.DotNetBar.LabelX();
            this.labelX21 = new DevComponents.DotNetBar.LabelX();
            this.buttonX4 = new DevComponents.DotNetBar.ButtonX();
            this.labelX23 = new DevComponents.DotNetBar.LabelX();
            this.textBoxX10 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.groupPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.superTabControl1)).BeginInit();
            this.superTabControl1.SuspendLayout();
            this.superTabControlPanel3.SuspendLayout();
            this.superTabControlPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pwtDataGridView1)).BeginInit();
            this.superTabControlPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pwtDataGridView2)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupPanel1
            // 
            this.groupPanel1.CanvasColor = System.Drawing.SystemColors.Control;
            this.groupPanel1.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.groupPanel1.Controls.Add(this.buttonX6);
            this.groupPanel1.Controls.Add(this.buttonX5);
            this.groupPanel1.Controls.Add(this.buttonX3);
            this.groupPanel1.Controls.Add(this.buttonX1);
            this.groupPanel1.Controls.Add(this.superTabControl1);
            this.groupPanel1.Controls.Add(this.tableLayoutPanel1);
            this.groupPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupPanel1.Location = new System.Drawing.Point(0, 0);
            this.groupPanel1.Margin = new System.Windows.Forms.Padding(5);
            this.groupPanel1.Name = "groupPanel1";
            this.groupPanel1.Size = new System.Drawing.Size(2072, 1229);
            // 
            // 
            // 
            this.groupPanel1.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.groupPanel1.Style.BackColorGradientAngle = 90;
            this.groupPanel1.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.groupPanel1.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderBottomWidth = 1;
            this.groupPanel1.Style.BorderColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.groupPanel1.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderLeftWidth = 1;
            this.groupPanel1.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderRightWidth = 1;
            this.groupPanel1.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderTopWidth = 1;
            this.groupPanel1.Style.Class = "";
            this.groupPanel1.Style.CornerDiameter = 4;
            this.groupPanel1.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.groupPanel1.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.groupPanel1.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.groupPanel1.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.groupPanel1.StyleMouseDown.Class = "";
            this.groupPanel1.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.groupPanel1.StyleMouseOver.Class = "";
            this.groupPanel1.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.groupPanel1.TabIndex = 0;
            // 
            // buttonX6
            // 
            this.buttonX6.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX6.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX6.Location = new System.Drawing.Point(676, 5);
            this.buttonX6.Margin = new System.Windows.Forms.Padding(5);
            this.buttonX6.Name = "buttonX6";
            this.buttonX6.Size = new System.Drawing.Size(212, 69);
            this.buttonX6.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX6.TabIndex = 6;
            this.buttonX6.Text = "取消全测";
            this.buttonX6.Click += new System.EventHandler(this.buttonX6_Click);
            // 
            // buttonX5
            // 
            this.buttonX5.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX5.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX5.Location = new System.Drawing.Point(454, 5);
            this.buttonX5.Margin = new System.Windows.Forms.Padding(5);
            this.buttonX5.Name = "buttonX5";
            this.buttonX5.Size = new System.Drawing.Size(212, 69);
            this.buttonX5.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX5.TabIndex = 5;
            this.buttonX5.Text = "全测";
            this.buttonX5.Click += new System.EventHandler(this.buttonX5_Click);
            // 
            // buttonX3
            // 
            this.buttonX3.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX3.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX3.Location = new System.Drawing.Point(232, 5);
            this.buttonX3.Margin = new System.Windows.Forms.Padding(5);
            this.buttonX3.Name = "buttonX3";
            this.buttonX3.Size = new System.Drawing.Size(212, 69);
            this.buttonX3.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX3.TabIndex = 4;
            this.buttonX3.Text = "清空";
            this.buttonX3.Click += new System.EventHandler(this.buttonX3_Click);
            // 
            // buttonX1
            // 
            this.buttonX1.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX1.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX1.Location = new System.Drawing.Point(8, 5);
            this.buttonX1.Margin = new System.Windows.Forms.Padding(5);
            this.buttonX1.Name = "buttonX1";
            this.buttonX1.Size = new System.Drawing.Size(212, 69);
            this.buttonX1.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX1.TabIndex = 3;
            this.buttonX1.Text = "过站";
            this.buttonX1.Click += new System.EventHandler(this.buttonX1_Click);
            // 
            // superTabControl1
            // 
            this.superTabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            // 
            // 
            // 
            // 
            // 
            // 
            this.superTabControl1.ControlBox.CloseBox.Name = "";
            // 
            // 
            // 
            this.superTabControl1.ControlBox.MenuBox.Name = "";
            this.superTabControl1.ControlBox.Name = "";
            this.superTabControl1.ControlBox.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabControl1.ControlBox.MenuBox,
            this.superTabControl1.ControlBox.CloseBox});
            this.superTabControl1.Controls.Add(this.superTabControlPanel3);
            this.superTabControl1.Controls.Add(this.superTabControlPanel1);
            this.superTabControl1.Controls.Add(this.superTabControlPanel2);
            this.superTabControl1.Location = new System.Drawing.Point(8, 779);
            this.superTabControl1.Margin = new System.Windows.Forms.Padding(5);
            this.superTabControl1.Name = "superTabControl1";
            this.superTabControl1.ReorderTabsEnabled = true;
            this.superTabControl1.SelectedTabFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold);
            this.superTabControl1.SelectedTabIndex = 0;
            this.superTabControl1.Size = new System.Drawing.Size(2044, 432);
            this.superTabControl1.TabFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.superTabControl1.TabIndex = 2;
            this.superTabControl1.Tabs.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem1,
            this.superTabItem2,
            this.superTabItem3});
            // 
            // superTabControlPanel3
            // 
            this.superTabControlPanel3.Controls.Add(this.pwtSearchBox6);
            this.superTabControlPanel3.Controls.Add(this.pwtSearchBox5);
            this.superTabControlPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel3.Location = new System.Drawing.Point(0, 43);
            this.superTabControlPanel3.Name = "superTabControlPanel3";
            this.superTabControlPanel3.Size = new System.Drawing.Size(2044, 389);
            this.superTabControlPanel3.TabIndex = 0;
            this.superTabControlPanel3.TabItem = this.superTabItem3;
            // 
            // pwtSearchBox6
            // 
            this.pwtSearchBox6.BackColor = System.Drawing.Color.White;
            this.pwtSearchBox6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(128)))), ((int)(((byte)(160)))));
            this.pwtSearchBox6.EmptyText = null;
            this.pwtSearchBox6.ImageHover = ((System.Drawing.Image)(resources.GetObject("pwtSearchBox6.ImageHover")));
            this.pwtSearchBox6.ImageNormal = ((System.Drawing.Image)(resources.GetObject("pwtSearchBox6.ImageNormal")));
            this.pwtSearchBox6.InputChangeTriggerTime = 600;
            this.pwtSearchBox6.IsSpaceKeyCodeValid = false;
            this.pwtSearchBox6.Location = new System.Drawing.Point(537, 142);
            this.pwtSearchBox6.Margin = new System.Windows.Forms.Padding(5);
            this.pwtSearchBox6.Name = "pwtSearchBox6";
            this.pwtSearchBox6.SearchBtnHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(214)))), ((int)(((byte)(125)))));
            this.pwtSearchBox6.Size = new System.Drawing.Size(504, 59);
            this.pwtSearchBox6.TabIndex = 14;
            // 
            // pwtSearchBox5
            // 
            this.pwtSearchBox5.BackColor = System.Drawing.Color.White;
            this.pwtSearchBox5.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(128)))), ((int)(((byte)(160)))));
            this.pwtSearchBox5.EmptyText = null;
            this.pwtSearchBox5.ImageHover = ((System.Drawing.Image)(resources.GetObject("pwtSearchBox5.ImageHover")));
            this.pwtSearchBox5.ImageNormal = ((System.Drawing.Image)(resources.GetObject("pwtSearchBox5.ImageNormal")));
            this.pwtSearchBox5.InputChangeTriggerTime = 600;
            this.pwtSearchBox5.IsSpaceKeyCodeValid = false;
            this.pwtSearchBox5.Location = new System.Drawing.Point(537, 73);
            this.pwtSearchBox5.Margin = new System.Windows.Forms.Padding(5);
            this.pwtSearchBox5.Name = "pwtSearchBox5";
            this.pwtSearchBox5.SearchBtnHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(214)))), ((int)(((byte)(125)))));
            this.pwtSearchBox5.Size = new System.Drawing.Size(504, 59);
            this.pwtSearchBox5.TabIndex = 3;
            // 
            // superTabItem3
            // 
            this.superTabItem3.AttachedControl = this.superTabControlPanel3;
            this.superTabItem3.GlobalItem = false;
            this.superTabItem3.Name = "superTabItem3";
            this.superTabItem3.Text = "隐藏";
            // 
            // superTabControlPanel1
            // 
            this.superTabControlPanel1.Controls.Add(this.pwtDataGridView1);
            this.superTabControlPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel1.Location = new System.Drawing.Point(0, 43);
            this.superTabControlPanel1.Margin = new System.Windows.Forms.Padding(5);
            this.superTabControlPanel1.Name = "superTabControlPanel1";
            this.superTabControlPanel1.Size = new System.Drawing.Size(2044, 389);
            this.superTabControlPanel1.TabIndex = 1;
            this.superTabControlPanel1.TabItem = this.superTabItem1;
            // 
            // pwtDataGridView1
            // 
            this.pwtDataGridView1.AllowUserToAddRows = false;
            this.pwtDataGridView1.AllowUserToDeleteRows = false;
            this.pwtDataGridView1.AllowUserToOrderColumns = true;
            dataGridViewCellStyle25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(229)))), ((int)(((byte)(248)))));
            this.pwtDataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle25;
            this.pwtDataGridView1.BackgroundColor = System.Drawing.SystemColors.Window;
            this.pwtDataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(246)))), ((int)(((byte)(239)))));
            dataGridViewCellStyle26.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle26.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle26.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle26.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle26.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.pwtDataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle26;
            this.pwtDataGridView1.ColumnHeadersHeight = 26;
            this.pwtDataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle27.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle27.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle27.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle27.SelectionBackColor = System.Drawing.Color.Wheat;
            dataGridViewCellStyle27.SelectionForeColor = System.Drawing.Color.DarkSlateBlue;
            dataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.pwtDataGridView1.DefaultCellStyle = dataGridViewCellStyle27;
            this.pwtDataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pwtDataGridView1.EnableHeadersVisualStyles = false;
            this.pwtDataGridView1.GridColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pwtDataGridView1.Location = new System.Drawing.Point(0, 0);
            this.pwtDataGridView1.Margin = new System.Windows.Forms.Padding(5);
            this.pwtDataGridView1.MergeColumnHeaderBackColor = System.Drawing.SystemColors.Control;
            this.pwtDataGridView1.MergeColumnNames = ((System.Collections.Generic.List<string>)(resources.GetObject("pwtDataGridView1.MergeColumnNames")));
            this.pwtDataGridView1.Name = "pwtDataGridView1";
            this.pwtDataGridView1.ReadOnly = true;
            this.pwtDataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle28.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle28.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle28.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle28.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle28.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle28.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.pwtDataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle28;
            this.pwtDataGridView1.RowHeadersWidth = 62;
            this.pwtDataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.pwtDataGridView1.RowTemplate.Height = 23;
            this.pwtDataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.pwtDataGridView1.Size = new System.Drawing.Size(2044, 389);
            this.pwtDataGridView1.TabIndex = 0;
            // 
            // superTabItem1
            // 
            this.superTabItem1.AttachedControl = this.superTabControlPanel1;
            this.superTabItem1.GlobalItem = false;
            this.superTabItem1.Name = "superTabItem1";
            this.superTabItem1.Text = "过站信息";
            // 
            // superTabControlPanel2
            // 
            this.superTabControlPanel2.Controls.Add(this.pwtDataGridView2);
            this.superTabControlPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel2.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel2.Margin = new System.Windows.Forms.Padding(5);
            this.superTabControlPanel2.Name = "superTabControlPanel2";
            this.superTabControlPanel2.Size = new System.Drawing.Size(2044, 432);
            this.superTabControlPanel2.TabIndex = 0;
            this.superTabControlPanel2.TabItem = this.superTabItem2;
            // 
            // pwtDataGridView2
            // 
            this.pwtDataGridView2.AllowUserToAddRows = false;
            this.pwtDataGridView2.AllowUserToDeleteRows = false;
            this.pwtDataGridView2.AllowUserToOrderColumns = true;
            dataGridViewCellStyle29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(229)))), ((int)(((byte)(248)))));
            this.pwtDataGridView2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle29;
            this.pwtDataGridView2.BackgroundColor = System.Drawing.SystemColors.Window;
            this.pwtDataGridView2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(246)))), ((int)(((byte)(239)))));
            dataGridViewCellStyle30.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle30.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle30.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle30.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle30.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.pwtDataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle30;
            this.pwtDataGridView2.ColumnHeadersHeight = 26;
            this.pwtDataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle31.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle31.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle31.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle31.SelectionBackColor = System.Drawing.Color.Wheat;
            dataGridViewCellStyle31.SelectionForeColor = System.Drawing.Color.DarkSlateBlue;
            dataGridViewCellStyle31.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.pwtDataGridView2.DefaultCellStyle = dataGridViewCellStyle31;
            this.pwtDataGridView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pwtDataGridView2.EnableHeadersVisualStyles = false;
            this.pwtDataGridView2.GridColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pwtDataGridView2.Location = new System.Drawing.Point(0, 0);
            this.pwtDataGridView2.Margin = new System.Windows.Forms.Padding(5);
            this.pwtDataGridView2.MergeColumnHeaderBackColor = System.Drawing.SystemColors.Control;
            this.pwtDataGridView2.MergeColumnNames = ((System.Collections.Generic.List<string>)(resources.GetObject("pwtDataGridView2.MergeColumnNames")));
            this.pwtDataGridView2.Name = "pwtDataGridView2";
            this.pwtDataGridView2.ReadOnly = true;
            this.pwtDataGridView2.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle32.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle32.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle32.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle32.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle32.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle32.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.pwtDataGridView2.RowHeadersDefaultCellStyle = dataGridViewCellStyle32;
            this.pwtDataGridView2.RowHeadersWidth = 62;
            this.pwtDataGridView2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.pwtDataGridView2.RowTemplate.Height = 23;
            this.pwtDataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.pwtDataGridView2.Size = new System.Drawing.Size(2044, 432);
            this.pwtDataGridView2.TabIndex = 1;
            // 
            // superTabItem2
            // 
            this.superTabItem2.AttachedControl = this.superTabControlPanel2;
            this.superTabItem2.GlobalItem = false;
            this.superTabItem2.Name = "superTabItem2";
            this.superTabItem2.Text = "冻结信息";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel1.ColumnCount = 6;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 160F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 180F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 160F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.Controls.Add(this.pwtSearchBox1, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelX1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelX2, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.labelX3, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.labelX4, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX1, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX2, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX3, 5, 2);
            this.tableLayoutPanel1.Controls.Add(this.labelX7, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.labelX8, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.labelX9, 4, 3);
            this.tableLayoutPanel1.Controls.Add(this.labelX5, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.labelX10, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.labelX11, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.labelX12, 4, 5);
            this.tableLayoutPanel1.Controls.Add(this.labelX13, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.labelX14, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.labelX15, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.labelX16, 4, 4);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX4, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.labelX20, 5, 4);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX5, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX6, 3, 5);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX7, 5, 5);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX8, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX9, 3, 6);
            this.tableLayoutPanel1.Controls.Add(this.labelX22, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.buttonX2, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelX17, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.pwtSearchBox2, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.labelX18, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.pwtSearchBox3, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.labelX19, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.pwtSearchBox4, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this.labelX6, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.labelX21, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.buttonX4, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelX23, 2, 8);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX10, 3, 8);
            this.tableLayoutPanel1.Font = new System.Drawing.Font("宋体", 11F);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(8, 88);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(5);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 9;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.49953F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.50328F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.49953F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.49953F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.49953F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.49953F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.49953F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.49953F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(2044, 677);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // pwtSearchBox1
            // 
            this.pwtSearchBox1.BackColor = System.Drawing.Color.White;
            this.pwtSearchBox1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(128)))), ((int)(((byte)(160)))));
            this.pwtSearchBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pwtSearchBox1.EmptyText = null;
            this.pwtSearchBox1.ImageHover = ((System.Drawing.Image)(resources.GetObject("pwtSearchBox1.ImageHover")));
            this.pwtSearchBox1.ImageNormal = ((System.Drawing.Image)(resources.GetObject("pwtSearchBox1.ImageNormal")));
            this.pwtSearchBox1.InputChangeTriggerTime = 600;
            this.pwtSearchBox1.IsSpaceKeyCodeValid = false;
            this.pwtSearchBox1.Location = new System.Drawing.Point(165, 5);
            this.pwtSearchBox1.Margin = new System.Windows.Forms.Padding(5);
            this.pwtSearchBox1.Name = "pwtSearchBox1";
            this.pwtSearchBox1.SearchBtnHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(214)))), ((int)(((byte)(125)))));
            this.pwtSearchBox1.Size = new System.Drawing.Size(504, 59);
            this.pwtSearchBox1.TabIndex = 2;
            this.pwtSearchBox1.SearchBtnClick += new System.EventHandler(this.pwtSearchBox1_SearchBtnClick);
            this.pwtSearchBox1.TextChanged += new System.EventHandler(this.pwtSearchBox1_TextChanged);
            // 
            // labelX1
            // 
            // 
            // 
            // 
            this.labelX1.BackgroundStyle.Class = "";
            this.labelX1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX1.Location = new System.Drawing.Point(5, 5);
            this.labelX1.Margin = new System.Windows.Forms.Padding(5);
            this.labelX1.Name = "labelX1";
            this.labelX1.Size = new System.Drawing.Size(148, 45);
            this.labelX1.TabIndex = 0;
            this.labelX1.Text = "流程卡";
            // 
            // labelX2
            // 
            // 
            // 
            // 
            this.labelX2.BackgroundStyle.Class = "";
            this.labelX2.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX2.Location = new System.Drawing.Point(5, 143);
            this.labelX2.Margin = new System.Windows.Forms.Padding(5);
            this.labelX2.Name = "labelX2";
            this.labelX2.Size = new System.Drawing.Size(150, 59);
            this.labelX2.TabIndex = 3;
            this.labelX2.Text = "排产片号";
            // 
            // labelX3
            // 
            // 
            // 
            // 
            this.labelX3.BackgroundStyle.Class = "";
            this.labelX3.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX3.Location = new System.Drawing.Point(679, 143);
            this.labelX3.Margin = new System.Windows.Forms.Padding(5);
            this.labelX3.Name = "labelX3";
            this.labelX3.Size = new System.Drawing.Size(170, 59);
            this.labelX3.TabIndex = 4;
            this.labelX3.Text = "已过站片号";
            // 
            // labelX4
            // 
            // 
            // 
            // 
            this.labelX4.BackgroundStyle.Class = "";
            this.labelX4.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX4.Location = new System.Drawing.Point(1373, 143);
            this.labelX4.Margin = new System.Windows.Forms.Padding(5);
            this.labelX4.Name = "labelX4";
            this.labelX4.Size = new System.Drawing.Size(150, 59);
            this.labelX4.TabIndex = 5;
            this.labelX4.Text = "过站片号";
            // 
            // textBoxX1
            // 
            // 
            // 
            // 
            this.textBoxX1.Border.Class = "TextBoxBorder";
            this.textBoxX1.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX1.Enabled = false;
            this.textBoxX1.Location = new System.Drawing.Point(165, 143);
            this.textBoxX1.Margin = new System.Windows.Forms.Padding(5);
            this.textBoxX1.Multiline = true;
            this.textBoxX1.Name = "textBoxX1";
            this.tableLayoutPanel1.SetRowSpan(this.textBoxX1, 2);
            this.textBoxX1.Size = new System.Drawing.Size(504, 179);
            this.textBoxX1.TabIndex = 7;
            // 
            // textBoxX2
            // 
            // 
            // 
            // 
            this.textBoxX2.Border.Class = "TextBoxBorder";
            this.textBoxX2.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX2.Enabled = false;
            this.textBoxX2.Location = new System.Drawing.Point(859, 143);
            this.textBoxX2.Margin = new System.Windows.Forms.Padding(5);
            this.textBoxX2.Multiline = true;
            this.textBoxX2.Name = "textBoxX2";
            this.tableLayoutPanel1.SetRowSpan(this.textBoxX2, 2);
            this.textBoxX2.Size = new System.Drawing.Size(504, 179);
            this.textBoxX2.TabIndex = 7;
            // 
            // textBoxX3
            // 
            // 
            // 
            // 
            this.textBoxX3.Border.Class = "TextBoxBorder";
            this.textBoxX3.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX3.Enabled = false;
            this.textBoxX3.Location = new System.Drawing.Point(1533, 143);
            this.textBoxX3.Margin = new System.Windows.Forms.Padding(5);
            this.textBoxX3.Multiline = true;
            this.textBoxX3.Name = "textBoxX3";
            this.tableLayoutPanel1.SetRowSpan(this.textBoxX3, 2);
            this.textBoxX3.Size = new System.Drawing.Size(506, 179);
            this.textBoxX3.TabIndex = 7;
            // 
            // labelX7
            // 
            // 
            // 
            // 
            this.labelX7.BackgroundStyle.Class = "";
            this.labelX7.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX7.Font = new System.Drawing.Font("宋体", 20F, System.Drawing.FontStyle.Bold);
            this.labelX7.ForeColor = System.Drawing.Color.Red;
            this.labelX7.Location = new System.Drawing.Point(5, 212);
            this.labelX7.Margin = new System.Windows.Forms.Padding(5);
            this.labelX7.Name = "labelX7";
            this.labelX7.Size = new System.Drawing.Size(150, 110);
            this.labelX7.TabIndex = 8;
            this.labelX7.Text = "0";
            this.labelX7.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // labelX8
            // 
            // 
            // 
            // 
            this.labelX8.BackgroundStyle.Class = "";
            this.labelX8.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX8.Font = new System.Drawing.Font("宋体", 20F, System.Drawing.FontStyle.Bold);
            this.labelX8.ForeColor = System.Drawing.Color.Red;
            this.labelX8.Location = new System.Drawing.Point(679, 212);
            this.labelX8.Margin = new System.Windows.Forms.Padding(5);
            this.labelX8.Name = "labelX8";
            this.labelX8.Size = new System.Drawing.Size(170, 110);
            this.labelX8.TabIndex = 8;
            this.labelX8.Text = "0";
            this.labelX8.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // labelX9
            // 
            // 
            // 
            // 
            this.labelX9.BackgroundStyle.Class = "";
            this.labelX9.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX9.Font = new System.Drawing.Font("宋体", 20F, System.Drawing.FontStyle.Bold);
            this.labelX9.ForeColor = System.Drawing.Color.Red;
            this.labelX9.Location = new System.Drawing.Point(1373, 212);
            this.labelX9.Margin = new System.Windows.Forms.Padding(5);
            this.labelX9.Name = "labelX9";
            this.labelX9.Size = new System.Drawing.Size(150, 110);
            this.labelX9.TabIndex = 8;
            this.labelX9.Text = "0";
            this.labelX9.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // labelX5
            // 
            // 
            // 
            // 
            this.labelX5.BackgroundStyle.Class = "";
            this.labelX5.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX5.Location = new System.Drawing.Point(5, 539);
            this.labelX5.Margin = new System.Windows.Forms.Padding(5);
            this.labelX5.Name = "labelX5";
            this.labelX5.Size = new System.Drawing.Size(150, 59);
            this.labelX5.TabIndex = 6;
            this.labelX5.Text = "工序流程";
            // 
            // labelX10
            // 
            // 
            // 
            // 
            this.labelX10.BackgroundStyle.Class = "";
            this.labelX10.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX10.Location = new System.Drawing.Point(5, 401);
            this.labelX10.Margin = new System.Windows.Forms.Padding(5);
            this.labelX10.Name = "labelX10";
            this.labelX10.Size = new System.Drawing.Size(148, 45);
            this.labelX10.TabIndex = 9;
            this.labelX10.Text = "客户编码";
            // 
            // labelX11
            // 
            // 
            // 
            // 
            this.labelX11.BackgroundStyle.Class = "";
            this.labelX11.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX11.Location = new System.Drawing.Point(679, 401);
            this.labelX11.Margin = new System.Windows.Forms.Padding(5);
            this.labelX11.Name = "labelX11";
            this.labelX11.Size = new System.Drawing.Size(149, 45);
            this.labelX11.TabIndex = 10;
            this.labelX11.Text = "客户名称";
            // 
            // labelX12
            // 
            // 
            // 
            // 
            this.labelX12.BackgroundStyle.Class = "";
            this.labelX12.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX12.Location = new System.Drawing.Point(1373, 401);
            this.labelX12.Margin = new System.Windows.Forms.Padding(5);
            this.labelX12.Name = "labelX12";
            this.labelX12.Size = new System.Drawing.Size(148, 45);
            this.labelX12.TabIndex = 11;
            this.labelX12.Text = "批号";
            // 
            // labelX13
            // 
            // 
            // 
            // 
            this.labelX13.BackgroundStyle.Class = "";
            this.labelX13.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX13.Location = new System.Drawing.Point(5, 470);
            this.labelX13.Margin = new System.Windows.Forms.Padding(5);
            this.labelX13.Name = "labelX13";
            this.labelX13.Size = new System.Drawing.Size(148, 45);
            this.labelX13.TabIndex = 9;
            this.labelX13.Text = "晶圆型号";
            // 
            // labelX14
            // 
            // 
            // 
            // 
            this.labelX14.BackgroundStyle.Class = "";
            this.labelX14.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX14.Location = new System.Drawing.Point(679, 470);
            this.labelX14.Margin = new System.Windows.Forms.Padding(5);
            this.labelX14.Name = "labelX14";
            this.labelX14.Size = new System.Drawing.Size(170, 59);
            this.labelX14.TabIndex = 9;
            this.labelX14.Text = "晶圆版本";
            // 
            // labelX15
            // 
            // 
            // 
            // 
            this.labelX15.BackgroundStyle.Class = "";
            this.labelX15.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX15.Location = new System.Drawing.Point(5, 332);
            this.labelX15.Margin = new System.Windows.Forms.Padding(5);
            this.labelX15.Name = "labelX15";
            this.labelX15.Size = new System.Drawing.Size(148, 45);
            this.labelX15.TabIndex = 9;
            this.labelX15.Text = "冻结片号";
            // 
            // labelX16
            // 
            // 
            // 
            // 
            this.labelX16.BackgroundStyle.Class = "";
            this.labelX16.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX16.Location = new System.Drawing.Point(1373, 332);
            this.labelX16.Margin = new System.Windows.Forms.Padding(5);
            this.labelX16.Name = "labelX16";
            this.labelX16.Size = new System.Drawing.Size(148, 45);
            this.labelX16.TabIndex = 9;
            this.labelX16.Text = "冻结数量";
            // 
            // textBoxX4
            // 
            // 
            // 
            // 
            this.textBoxX4.Border.Class = "TextBoxBorder";
            this.textBoxX4.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.tableLayoutPanel1.SetColumnSpan(this.textBoxX4, 3);
            this.textBoxX4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX4.Enabled = false;
            this.textBoxX4.Location = new System.Drawing.Point(165, 332);
            this.textBoxX4.Margin = new System.Windows.Forms.Padding(5);
            this.textBoxX4.Name = "textBoxX4";
            this.textBoxX4.Size = new System.Drawing.Size(1198, 75);
            this.textBoxX4.TabIndex = 13;
            // 
            // labelX20
            // 
            // 
            // 
            // 
            this.labelX20.BackgroundStyle.Class = "";
            this.labelX20.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX20.Font = new System.Drawing.Font("宋体", 20F, System.Drawing.FontStyle.Bold);
            this.labelX20.ForeColor = System.Drawing.Color.Red;
            this.labelX20.Location = new System.Drawing.Point(1533, 332);
            this.labelX20.Margin = new System.Windows.Forms.Padding(5);
            this.labelX20.Name = "labelX20";
            this.labelX20.Size = new System.Drawing.Size(506, 59);
            this.labelX20.TabIndex = 8;
            this.labelX20.Text = "0";
            this.labelX20.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // textBoxX5
            // 
            // 
            // 
            // 
            this.textBoxX5.Border.Class = "TextBoxBorder";
            this.textBoxX5.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX5.Location = new System.Drawing.Point(165, 401);
            this.textBoxX5.Margin = new System.Windows.Forms.Padding(5);
            this.textBoxX5.Name = "textBoxX5";
            this.textBoxX5.ReadOnly = true;
            this.textBoxX5.Size = new System.Drawing.Size(504, 75);
            this.textBoxX5.TabIndex = 15;
            // 
            // textBoxX6
            // 
            // 
            // 
            // 
            this.textBoxX6.Border.Class = "TextBoxBorder";
            this.textBoxX6.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX6.Location = new System.Drawing.Point(859, 401);
            this.textBoxX6.Margin = new System.Windows.Forms.Padding(5);
            this.textBoxX6.Name = "textBoxX6";
            this.textBoxX6.ReadOnly = true;
            this.textBoxX6.Size = new System.Drawing.Size(504, 75);
            this.textBoxX6.TabIndex = 15;
            // 
            // textBoxX7
            // 
            // 
            // 
            // 
            this.textBoxX7.Border.Class = "TextBoxBorder";
            this.textBoxX7.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX7.Location = new System.Drawing.Point(1533, 401);
            this.textBoxX7.Margin = new System.Windows.Forms.Padding(5);
            this.textBoxX7.Name = "textBoxX7";
            this.textBoxX7.ReadOnly = true;
            this.textBoxX7.Size = new System.Drawing.Size(506, 75);
            this.textBoxX7.TabIndex = 15;
            // 
            // textBoxX8
            // 
            // 
            // 
            // 
            this.textBoxX8.Border.Class = "TextBoxBorder";
            this.textBoxX8.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX8.Location = new System.Drawing.Point(165, 470);
            this.textBoxX8.Margin = new System.Windows.Forms.Padding(5);
            this.textBoxX8.Name = "textBoxX8";
            this.textBoxX8.ReadOnly = true;
            this.textBoxX8.Size = new System.Drawing.Size(504, 75);
            this.textBoxX8.TabIndex = 15;
            // 
            // textBoxX9
            // 
            // 
            // 
            // 
            this.textBoxX9.Border.Class = "TextBoxBorder";
            this.textBoxX9.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX9.Location = new System.Drawing.Point(859, 470);
            this.textBoxX9.Margin = new System.Windows.Forms.Padding(5);
            this.textBoxX9.Name = "textBoxX9";
            this.textBoxX9.ReadOnly = true;
            this.textBoxX9.Size = new System.Drawing.Size(504, 75);
            this.textBoxX9.TabIndex = 15;
            // 
            // labelX22
            // 
            // 
            // 
            // 
            this.labelX22.BackgroundStyle.Class = "";
            this.labelX22.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.tableLayoutPanel1.SetColumnSpan(this.labelX22, 5);
            this.labelX22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX22.Location = new System.Drawing.Point(165, 539);
            this.labelX22.Margin = new System.Windows.Forms.Padding(5);
            this.labelX22.Name = "labelX22";
            this.labelX22.Size = new System.Drawing.Size(1874, 59);
            this.labelX22.TabIndex = 16;
            this.labelX22.Text = "---->";
            // 
            // buttonX2
            // 
            this.buttonX2.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonX2.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX2.Location = new System.Drawing.Point(1533, 5);
            this.buttonX2.Margin = new System.Windows.Forms.Padding(5);
            this.buttonX2.Name = "buttonX2";
            this.buttonX2.Size = new System.Drawing.Size(260, 59);
            this.buttonX2.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX2.TabIndex = 18;
            this.buttonX2.Text = "手动选择过站片号";
            this.buttonX2.Click += new System.EventHandler(this.buttonX2_Click);
            // 
            // labelX17
            // 
            // 
            // 
            // 
            this.labelX17.BackgroundStyle.Class = "";
            this.labelX17.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX17.Location = new System.Drawing.Point(5, 74);
            this.labelX17.Margin = new System.Windows.Forms.Padding(5);
            this.labelX17.Name = "labelX17";
            this.labelX17.Size = new System.Drawing.Size(150, 59);
            this.labelX17.TabIndex = 12;
            this.labelX17.Text = "设备名称";
            // 
            // pwtSearchBox2
            // 
            this.pwtSearchBox2.BackColor = System.Drawing.Color.White;
            this.pwtSearchBox2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(128)))), ((int)(((byte)(160)))));
            this.pwtSearchBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pwtSearchBox2.EmptyText = null;
            this.pwtSearchBox2.ImageHover = ((System.Drawing.Image)(resources.GetObject("pwtSearchBox2.ImageHover")));
            this.pwtSearchBox2.ImageNormal = ((System.Drawing.Image)(resources.GetObject("pwtSearchBox2.ImageNormal")));
            this.pwtSearchBox2.InputChangeTriggerTime = 600;
            this.pwtSearchBox2.IsSpaceKeyCodeValid = false;
            this.pwtSearchBox2.Location = new System.Drawing.Point(165, 74);
            this.pwtSearchBox2.Margin = new System.Windows.Forms.Padding(5);
            this.pwtSearchBox2.Name = "pwtSearchBox2";
            this.pwtSearchBox2.SearchBtnHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(214)))), ((int)(((byte)(125)))));
            this.pwtSearchBox2.Size = new System.Drawing.Size(504, 59);
            this.pwtSearchBox2.TabIndex = 17;
            this.pwtSearchBox2.SearchBtnClick += new System.EventHandler(this.pwtSearchBox2_SearchBtnClick);
            // 
            // labelX18
            // 
            // 
            // 
            // 
            this.labelX18.BackgroundStyle.Class = "";
            this.labelX18.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX18.Location = new System.Drawing.Point(679, 74);
            this.labelX18.Margin = new System.Windows.Forms.Padding(5);
            this.labelX18.Name = "labelX18";
            this.labelX18.Size = new System.Drawing.Size(170, 59);
            this.labelX18.TabIndex = 12;
            this.labelX18.Text = "工序名称";
            // 
            // pwtSearchBox3
            // 
            this.pwtSearchBox3.BackColor = System.Drawing.Color.White;
            this.pwtSearchBox3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(128)))), ((int)(((byte)(160)))));
            this.pwtSearchBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pwtSearchBox3.EmptyText = null;
            this.pwtSearchBox3.ImageHover = ((System.Drawing.Image)(resources.GetObject("pwtSearchBox3.ImageHover")));
            this.pwtSearchBox3.ImageNormal = ((System.Drawing.Image)(resources.GetObject("pwtSearchBox3.ImageNormal")));
            this.pwtSearchBox3.InputChangeTriggerTime = 600;
            this.pwtSearchBox3.IsSpaceKeyCodeValid = false;
            this.pwtSearchBox3.Location = new System.Drawing.Point(859, 74);
            this.pwtSearchBox3.Margin = new System.Windows.Forms.Padding(5);
            this.pwtSearchBox3.Name = "pwtSearchBox3";
            this.pwtSearchBox3.ReadOnly = true;
            this.pwtSearchBox3.SearchBtnHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(214)))), ((int)(((byte)(125)))));
            this.pwtSearchBox3.Size = new System.Drawing.Size(504, 59);
            this.pwtSearchBox3.TabIndex = 17;
            this.pwtSearchBox3.SearchBtnClick += new System.EventHandler(this.pwtSearchBox3_SearchBtnClick);
            // 
            // labelX19
            // 
            // 
            // 
            // 
            this.labelX19.BackgroundStyle.Class = "";
            this.labelX19.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX19.Location = new System.Drawing.Point(1373, 74);
            this.labelX19.Margin = new System.Windows.Forms.Padding(5);
            this.labelX19.Name = "labelX19";
            this.labelX19.Size = new System.Drawing.Size(150, 59);
            this.labelX19.TabIndex = 12;
            this.labelX19.Text = "上线人";
            // 
            // pwtSearchBox4
            // 
            this.pwtSearchBox4.BackColor = System.Drawing.Color.White;
            this.pwtSearchBox4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(128)))), ((int)(((byte)(160)))));
            this.pwtSearchBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pwtSearchBox4.EmptyText = null;
            this.pwtSearchBox4.ImageHover = ((System.Drawing.Image)(resources.GetObject("pwtSearchBox4.ImageHover")));
            this.pwtSearchBox4.ImageNormal = ((System.Drawing.Image)(resources.GetObject("pwtSearchBox4.ImageNormal")));
            this.pwtSearchBox4.InputChangeTriggerTime = 600;
            this.pwtSearchBox4.IsSpaceKeyCodeValid = false;
            this.pwtSearchBox4.Location = new System.Drawing.Point(1533, 74);
            this.pwtSearchBox4.Margin = new System.Windows.Forms.Padding(5);
            this.pwtSearchBox4.Name = "pwtSearchBox4";
            this.pwtSearchBox4.SearchBtnHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(214)))), ((int)(((byte)(125)))));
            this.pwtSearchBox4.Size = new System.Drawing.Size(506, 59);
            this.pwtSearchBox4.TabIndex = 17;
            // 
            // labelX6
            // 
            // 
            // 
            // 
            this.labelX6.BackgroundStyle.Class = "";
            this.labelX6.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX6.Location = new System.Drawing.Point(5, 608);
            this.labelX6.Margin = new System.Windows.Forms.Padding(5);
            this.labelX6.Name = "labelX6";
            this.labelX6.Size = new System.Drawing.Size(150, 64);
            this.labelX6.TabIndex = 6;
            this.labelX6.Text = "当前工序";
            // 
            // labelX21
            // 
            // 
            // 
            // 
            this.labelX21.BackgroundStyle.Class = "";
            this.labelX21.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX21.Location = new System.Drawing.Point(165, 608);
            this.labelX21.Margin = new System.Windows.Forms.Padding(5);
            this.labelX21.Name = "labelX21";
            this.labelX21.Size = new System.Drawing.Size(504, 64);
            this.labelX21.TabIndex = 14;
            this.labelX21.Text = "开始";
            // 
            // buttonX4
            // 
            this.buttonX4.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX4.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonX4.Location = new System.Drawing.Point(679, 5);
            this.buttonX4.Margin = new System.Windows.Forms.Padding(5);
            this.buttonX4.Name = "buttonX4";
            this.buttonX4.Size = new System.Drawing.Size(170, 59);
            this.buttonX4.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX4.TabIndex = 19;
            this.buttonX4.Text = "流程卡查询";
            this.buttonX4.Click += new System.EventHandler(this.buttonX4_Click);
            // 
            // labelX23
            // 
            // 
            // 
            // 
            this.labelX23.BackgroundStyle.Class = "";
            this.labelX23.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX23.Location = new System.Drawing.Point(679, 608);
            this.labelX23.Margin = new System.Windows.Forms.Padding(5);
            this.labelX23.Name = "labelX23";
            this.labelX23.Size = new System.Drawing.Size(170, 64);
            this.labelX23.TabIndex = 6;
            this.labelX23.Text = "全测片号";
            // 
            // textBoxX10
            // 
            // 
            // 
            // 
            this.textBoxX10.Border.Class = "TextBoxBorder";
            this.textBoxX10.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.tableLayoutPanel1.SetColumnSpan(this.textBoxX10, 3);
            this.textBoxX10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX10.Location = new System.Drawing.Point(859, 608);
            this.textBoxX10.Margin = new System.Windows.Forms.Padding(5);
            this.textBoxX10.Name = "textBoxX10";
            this.textBoxX10.ReadOnly = true;
            this.textBoxX10.Size = new System.Drawing.Size(1180, 75);
            this.textBoxX10.TabIndex = 15;
            // 
            // 新版扫描过站管理
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2072, 1229);
            this.Controls.Add(this.groupPanel1);
            this.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "新版扫描过站管理";
            this.Text = "新版扫描过站管理";
            this.Load += new System.EventHandler(this.新版扫描过站管理_Load);
            this.groupPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.superTabControl1)).EndInit();
            this.superTabControl1.ResumeLayout(false);
            this.superTabControlPanel3.ResumeLayout(false);
            this.superTabControlPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pwtDataGridView1)).EndInit();
            this.superTabControlPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pwtDataGridView2)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private DevComponents.DotNetBar.Controls.GroupPanel groupPanel1;
        private DevComponents.DotNetBar.LabelX labelX1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private Pawote.UI.Controls.PwtSearchBox pwtSearchBox1;
        private DevComponents.DotNetBar.LabelX labelX2;
        private DevComponents.DotNetBar.LabelX labelX3;
        private DevComponents.DotNetBar.LabelX labelX4;
        private DevComponents.DotNetBar.LabelX labelX5;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX1;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX2;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX3;
        private DevComponents.DotNetBar.LabelX labelX6;
        private DevComponents.DotNetBar.LabelX labelX7;
        private DevComponents.DotNetBar.LabelX labelX8;
        private DevComponents.DotNetBar.LabelX labelX9;
        private DevComponents.DotNetBar.LabelX labelX10;
        private DevComponents.DotNetBar.LabelX labelX11;
        private DevComponents.DotNetBar.LabelX labelX12;
        private DevComponents.DotNetBar.LabelX labelX13;
        private DevComponents.DotNetBar.LabelX labelX14;
        private DevComponents.DotNetBar.LabelX labelX15;
        private DevComponents.DotNetBar.LabelX labelX16;
        private DevComponents.DotNetBar.LabelX labelX17;
        private DevComponents.DotNetBar.LabelX labelX18;
        private DevComponents.DotNetBar.LabelX labelX19;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX4;
        private DevComponents.DotNetBar.LabelX labelX20;
        private DevComponents.DotNetBar.LabelX labelX21;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX5;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX6;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX7;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX8;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX9;
        private DevComponents.DotNetBar.LabelX labelX22;
        private Pawote.UI.Controls.PwtSearchBox pwtSearchBox2;
        private Pawote.UI.Controls.PwtSearchBox pwtSearchBox3;
        private Pawote.UI.Controls.PwtSearchBox pwtSearchBox4;
        private DevComponents.DotNetBar.ButtonX buttonX1;
        private DevComponents.DotNetBar.SuperTabControl superTabControl1;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel1;
        private DevComponents.DotNetBar.SuperTabItem superTabItem1;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel2;
        private DevComponents.DotNetBar.SuperTabItem superTabItem2;
        private Pawote.UI.Controls.PwtDataGridView pwtDataGridView2;
        private Pawote.UI.Controls.PwtDataGridView pwtDataGridView1;
        private DevComponents.DotNetBar.ButtonX buttonX2;
        private DevComponents.DotNetBar.ButtonX buttonX3;
        private DevComponents.DotNetBar.ButtonX buttonX4;
        private DevComponents.DotNetBar.ButtonX buttonX5;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel3;
        private Pawote.UI.Controls.PwtSearchBox pwtSearchBox5;
        private DevComponents.DotNetBar.SuperTabItem superTabItem3;
        private Pawote.UI.Controls.PwtSearchBox pwtSearchBox6;
        private DevComponents.DotNetBar.LabelX labelX23;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX10;
        private DevComponents.DotNetBar.ButtonX buttonX6;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Xj_Mes_cp
{
    public partial class 新版设备维护管理 : Form
    {
        public 新版设备维护管理()
        {
            InitializeComponent();
        }
    }
}



/*
 * ���ߣ�sky
 * ʱ�䣺2008-06-25
 * ���ã��������� CMD �� txt ��ʽ�� mapping �ļ�
 */

namespace DataToExcel
{
    using System;
    using System.Drawing;
    using System.Collections;
    using DataToExcel;
    using System.IO;
    using System.Net;

    public class CmdTxt : MappingBase
    {
        // Fields
        public static string _Device = "";
        public static string _LotNo = "";
        public static int _singleTotalDie = 0;
        public static int _TotalDie = 0;
        public static int _TotalFailDie = 0;
        public static int _TotalPassDie = 0;
        public static string _TotalYield = "";

        // Methods
        public CmdTxt(string file)
            : base("cmdtxt", file)
        {
        }

        protected override void InitialProperties()
        {
            base._keys.Add("PassDie");
            base._keys.Add("FailDie");
            base._keys.Add("RowCount");
            base._keys.Add("ColCount");
            base._properties.Add("PassDie", 0);
            base._properties.Add("FailDie", 0);
            base._properties.Add("RowCount", 0);
            base._properties.Add("ColCount", 0);
        }

        public static bool InitTotal()
        {
            _TotalDie = 0;
            _TotalPassDie = 0;
            _TotalFailDie = 0;
            _singleTotalDie = 0;
            _TotalYield = "";
            return true;
        }

        public override bool IsEmptyDie(DieData die)
        {
            return (((die.Attribute == DieCategory.NoneDie) || (die.Attribute == DieCategory.MarkDie)) || (die.Attribute == DieCategory.SkipDie));
        }

        public override IMappingFile Merge(IMappingFile map, string newfile)
        {
            return null;
        }

        public override void Read()
        {
            throw new Exception("�����Ͳ�֧���ļ���ȡ��");
        }

        public override void Save()
        {
            try
            {
                try
                {
                    StreamWriter writer;
                    if (File.Exists(base.FullName))
                    {
                        File.Delete(base.FullName);
                    }
                    base.OpenWriter();
                    this.WriteString("     ");
                    for (int i = 0; i < base.DieMatrix.XMax; i++)
                    {
                        int num5 = i + 1;
                        this.WriteString(num5.ToString("00") + " ");
                    }
                    this.WriteString(base.Enter + "     ");
                    for (int j = 0; j < base.DieMatrix.XMax; j++)
                    {
                        this.WriteString("++-");
                    }
                    ToCountDie die = new ToCountDie();
                    for (int k = 0; k < base.DieMatrix.YMax; k++)
                    {
                        this.WriteString(base.Enter + ((k + 1)).ToString("000") + "| ");
                        for (int m = 0; m < base.DieMatrix.XMax; m++)
                        {
                            if (base.DieMatrix[m, k].Attribute == DieCategory.FailDie)
                            {
                                die.CountDie(base.DieMatrix[m, k].Bin);
                            }
                            this.WriteString(UtilFunction.DieCategoryCaption(base.DieMatrix[m, k].Attribute) + " ");
                        }
                    }
                    _singleTotalDie = base.DieMatrix.DieAttributeStat(DieCategory.TIRefFail | DieCategory.TIRefPass | DieCategory.Unknow | DieCategory.FailDie | DieCategory.PassDie);
                    this.WriteString(base.Enter + base.Enter);
                    this.WriteString("Device:" + this.Device + "\r\n");
                    this.WriteString("Lot NO:" + this.LotNo + "\r\n");
                    /*string lastDigit = this.WaferID.Substring(this.WaferID.Length - 2);
                    lastDigit = lastDigit.PadLeft(2, '0');*/
                    this.WriteString("Slot No:" + this.SlotNo + "\r\n");
                    this.WriteString("Wafer ID:" + this.WaferID + "\r\n");
                    double WaferSize = 0;
                    if (this.WaferSize > 120)
                    {
                        WaferSize = this.WaferSize;
                        this.WriteString("Wafer Size:   " + WaferSize + " mm" + "\r\n");
                    }
                    else
                    {
                        WaferSize = this.WaferSize / 10;
                        this.WriteString("Wafer Size:   " + WaferSize + " Inch" + "\r\n");
                    }
                    string FlatDir1 = "";

                    if (this.FlatDir == 90)
                    {
                        FlatDir1 = "Right";
                    }

                    else if (this.FlatDir == 180)
                    {
                        FlatDir1 = "Bottom";
                    }
                    else if (this.FlatDir == 270)
                    {
                        FlatDir1 = "Left";
                    }
                    else if (this.FlatDir == 0)
                    {
                        FlatDir1 = "Top";
                    }
                    this.WriteString("Flat Dir:   " + FlatDir1 + "\r\n");

                    int xMin = Int32.MaxValue;
                    int yMin = Int32.MaxValue;
                    int xMax = Int32.MinValue;
                    int yMax = Int32.MinValue;
                    int passDie = 0;

                    int fileDie = 0;

                    for (int y = 0; y < base.DieMatrix.YMax; y++)//83
                    {
                        for (int x = 0; x < base.DieMatrix.XMax; x++)//57
                        {
                            switch (base.DieMatrix[x, y].Attribute)
                            {
                                case DieCategory.PassDie:
                                    getMinXY(ref xMin, ref yMin, ref xMax, ref yMax, y, x);
                                    passDie++; break;
                                case DieCategory.FailDie:
                                    getMinXY(ref xMin, ref yMin, ref xMax, ref yMax, y, x);
                                    fileDie++; break;
                                case DieCategory.SkipDie2:
                                    getMinXY(ref xMin, ref yMin, ref xMax, ref yMax, y, x);
                                    int xxx = this.DieMatrix[x, y].Bin;
                                    break;
                            }
                        }
                    }
                    int ymin = 1000;
                    int xmin = 1000;
                    int ymax = 0;
                    int xmax = 0;
                    for (int y = 0; y < base.DieMatrix.YMax; y++)
                    {
                        for (int x = 0; x < base.DieMatrix.XMax; x++)
                        {
                            switch (base.DieMatrix[x, y].Attribute)
                            {
                                case DieCategory.PassDie:
                                case DieCategory.FailDie:
                                    if (xmin > x)
                                    {
                                        xmin = x;
                                    }
                                    if (ymin > y)
                                    {
                                        ymin = y;
                                    }
                                    if (ymax < y)
                                    {
                                        ymax = y;
                                    }
                                    if (xmax < x)
                                    {
                                        xmax = x;
                                    }
                                    break;
                            }
                        }
                    }
                    string formattedStartTime = this.StartTime.ToString("yyyy/MM/dd HH:mm:ss");
                    this.WriteString("Wafer Test Start Time:" + formattedStartTime + "\r\n");
                    string formattedEndTime = this.EndTime.ToString("yyyy/MM/dd HH:mm:ss");
                    this.WriteString("Wafer Test End Time:" + formattedEndTime + "\r\n");
                    int totalDie = passDie + fileDie;
                    this.WriteString("Total test die:" + totalDie + "\r\n");
                    this.WriteString("Pass Die:" + passDie + "\r\n");
                    this.WriteString("Fail Die:" + fileDie + "\r\n");
                    this.WriteString("Yield:" + Math.Round(Convert.ToDouble((double)(Convert.ToDouble(passDie) / ((double)(totalDie)))), 4).ToString("0.00%") + "\r\n");
                    string address = string.Empty;
                    for (int y = ymin; y < ymax + 1; y++)
                    {
                        this.WriteString( "RowData:");
                        for (int x = xmin; x < xmax + 1; x++)
                        {
                            this.WriteString(DieCategoryCaption(base.DieMatrix[x, y].Attribute, base.DieMatrix[x, y].Bin, address));
                            this.WriteString(" ");
                        }
                        this.WriteString("\r\n");
                    }
                    string path = base.FullName.Substring(0, base.FullName.LastIndexOf(@"\")) + @"\Total.txt";
                    /*if (File.Exists(path))
                    {   
                        writer = File.AppendText(path);
                    }
                    else
                    {
                        writer = File.CreateText(path);
                    }
                    _Device = this.Device;
                    _LotNo = this.LotNo;
                    _TotalDie += _singleTotalDie;
                    _TotalPassDie += this.PassDie;
                    _TotalFailDie += this.FailDie;
                    _TotalYield = Math.Round(Convert.ToDouble((double)(Convert.ToDouble(_TotalPassDie) / ((double)_TotalDie))), 4).ToString("0.00%");
                    writer.WriteLine("============ Wafer Information () ===========");
                    writer.WriteLine("  Device: " + this.Device);
                    writer.WriteLine("  Lot NO: " + this.LotNo);
                    writer.WriteLine("  Slot NO: " + this.SlotNo);
                    writer.WriteLine("  Wafer ID: " + this.WaferID);
                    writer.WriteLine("  Operater: ");
                    writer.WriteLine("  Wafer Size: " + ((this.WaferSize / 10)).ToString() + "inch");
                    writer.WriteLine("  Flat Dir: " + this.FlatDir);
                    writer.WriteLine("  Wafer Test Start Time: " + this.StartTime);
                    writer.WriteLine("  Wafer Test Finish Time: " + this.EndTime);
                    writer.WriteLine("  Wafer Load Time: " + this.LoadTime);
                    writer.WriteLine("  Wafer Unload Time: " + this.UnloadTime);
                    writer.WriteLine("  Total Test Die: " + _singleTotalDie);
                    writer.WriteLine("  Pass Die: " + this.PassDie);
                    writer.WriteLine("  Fail Die: " + this.FailDie);
                    writer.WriteLine("  Yield: " + Math.Round(Convert.ToDouble((double)(Convert.ToDouble(this.PassDie) / ((double)_singleTotalDie))), 4).ToString("0.00%"));
                    writer.WriteLine("  Rows: " + this.RowCount);
                    writer.WriteLine("  Cols: " + this.ColCount);
                    writer.WriteLine("=============================================");
                    writer.WriteLine(base.Enter);
                    writer.Close();*/
                }
                catch (Exception exception)
                {
                    throw exception;
                }
            }
            finally
            {
                base.CloseWriter();
            }
        }
        private string DieCategoryCaption(DieCategory attr, int bin, string address)
        {
                switch (attr)
                {
                    case DieCategory.PassDie:
                        return "00";
                    case DieCategory.FailDie:
                        return bin.ToString();
                    case DieCategory.SkipDie2:
                        return "@@";
                    default:
                        return "__";
                }
        }


        public static void getMinXY(ref int xMin, ref int yMin, ref int xMax, ref int yMax, int y, int x)
        {
            if (xMin > x) { xMin = x; }
            if (yMin > y) { yMin = y; }
            if (yMax < y) { yMax = y; }
            if (xMax < x) { xMax = x; }
        }

        // Properties
        public int CassetteNo
        {
            get
            {
                return (int)base._properties["CassetteNo"];
            }
            set
            {
                base._properties["CassetteNo"] = value;
            }
        }

        public int ColCount
        {
            get
            {
                return (int)base._properties["ColCount"];
            }
            set
            {
                base._properties["ColCount"] = value;
            }
        }

        public string Device
        {
            get
            {
                return base._properties["Device"].ToString();
            }
            set
            {
                base._properties["Device"] = value;
            }
        }

        public DateTime EndTime
        {
            get
            {
                return (DateTime)base._properties["EndTime"];
            }
            set
            {
                base._properties["EndTime"] = value;
            }
        }

        public int FailDie
        {
            get
            {
                return (int)base._properties["FailDie"];
            }
            set
            {
                base._properties["FailDie"] = value;
            }
        }

        public int FlatDir
        {
            get
            {
                return (int)base._properties["FlatDir"];
            }
            set
            {
                base._properties["FlatDir"] = value;
            }
        }

        public int IndexSizeX
        {
            get
            {
                return (int)base._properties["IndexSizeX"];
            }
            set
            {
                base._properties["IndexSizeX"] = value;
            }
        }

        public int IndexSizeY
        {
            get
            {
                return (int)base._properties["IndexSizeY"];
            }
            set
            {
                base._properties["IndexSizeY"] = value;
            }
        }

        public DateTime LoadTime
        {
            get
            {
                return (DateTime)base._properties["LoadTime"];
            }
            set
            {
                base._properties["LoadTime"] = value;
            }
        }

        public override string LotNo
        {
            get
            {
                return base._properties["LotNo"].ToString();
            }
            set
            {
                base._properties["LotNo"] = value;
            }
        }

        public int MachineNo
        {
            get
            {
                return (int)base._properties["MachineNo"];
            }
            set
            {
                base._properties["MachineNo"] = value;
            }
        }

        public byte MachineType
        {
            get
            {
                return (byte)base._properties["MachineType"];
            }
            set
            {
                base._properties["MachineType"] = value;
            }
        }

        public int MapDataForm
        {
            get
            {
                return (int)base._properties["MapDataForm"];
            }
            set
            {
                base._properties["MapDataForm"] = value;
            }
        }

        public byte MapVersion
        {
            get
            {
                return (byte)base._properties["MapVersion"];
            }
            set
            {
                base._properties["MapVersion"] = value;
            }
        }

        public string Operator
        {
            get
            {
                return base._properties["Operator"].ToString();
            }
            set
            {
                base._properties["Operator"] = value;
            }
        }

        public int PassDie
        {
            get
            {
                return (int)base._properties["PassDie"];
            }
            set
            {
                base._properties["PassDie"] = value;
            }
        }

        public byte ProbingNo
        {
            get
            {
                return (byte)base._properties["ProbingNo"];
            }
            set
            {
                base._properties["ProbingNo"] = value;
            }
        }

        public int Refpx
        {
            get
            {
                return (int)base._properties["Refpx"];
            }
            set
            {
                base._properties["Refpx"] = value;
            }
        }

        public int Refpy
        {
            get
            {
                return (int)base._properties["Refpy"];
            }
            set
            {
                base._properties["Refpy"] = value;
            }
        }

        public int RowCount
        {
            get
            {
                return (int)base._properties["RowCount"];
            }
            set
            {
                base._properties["RowCount"] = value;
            }
        }

        public int SlotNo
        {
            get
            {
                return (int)base._properties["SlotNo"];
            }
            set
            {
                base._properties["SlotNo"] = value;
            }
        }

        public DateTime StartTime
        {
            get
            {
                return (DateTime)base._properties["StartTime"];
            }
            set
            {
                base._properties["StartTime"] = value;
            }
        }

        public int TotalDie
        {
            get
            {
                return (int)base._properties["TotalDie"];
            }
            set
            {
                base._properties["TotalDie"] = value;
            }
        }

        public DateTime UnloadTime
        {
            get
            {
                return (DateTime)base._properties["UnloadTime"];
            }
            set
            {
                base._properties["UnloadTime"] = value;
            }
        }

        public override string WaferID
        {
            get
            {
                return base._properties["WaferID"].ToString();
            }
            set
            {
                base._properties["WaferID"] = value;
            }
        }

        public int WaferSize
        {
            get
            {
                return (int)base._properties["WaferSize"];
            }
            set
            {
                base._properties["WaferSize"] = value;
            }
        }
    }
}

﻿namespace Xj_Mes_cp
{
    partial class 生产异常处理报告
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(生产异常处理报告));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.groupPanel1 = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.buttonX5 = new DevComponents.DotNetBar.ButtonX();
            this.buttonX4 = new DevComponents.DotNetBar.ButtonX();
            this.superTabControl1 = new DevComponents.DotNetBar.SuperTabControl();
            this.superTabControlPanel1 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.pwtDataGridView1 = new Pawote.UI.Controls.PwtDataGridView();
            this.superTabItem1 = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel2 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.textBoxX11 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX17 = new DevComponents.DotNetBar.LabelX();
            this.textBoxX10 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX16 = new DevComponents.DotNetBar.LabelX();
            this.textBoxX9 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX15 = new DevComponents.DotNetBar.LabelX();
            this.textBoxX8 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX7 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX14 = new DevComponents.DotNetBar.LabelX();
            this.labelX13 = new DevComponents.DotNetBar.LabelX();
            this.superTabItem2 = new DevComponents.DotNetBar.SuperTabItem();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.checkBoxX1 = new DevComponents.DotNetBar.Controls.CheckBoxX();
            this.labelX10 = new DevComponents.DotNetBar.LabelX();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.textBoxX13 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX19 = new DevComponents.DotNetBar.LabelX();
            this.textBoxX2 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX5 = new DevComponents.DotNetBar.LabelX();
            this.textBoxX1 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX3 = new DevComponents.DotNetBar.LabelX();
            this.pwtSearchBox2 = new Pawote.UI.Controls.PwtSearchBox();
            this.labelX2 = new DevComponents.DotNetBar.LabelX();
            this.pwtSearchBox1 = new Pawote.UI.Controls.PwtSearchBox();
            this.labelX1 = new DevComponents.DotNetBar.LabelX();
            this.labelX21 = new DevComponents.DotNetBar.LabelX();
            this.pwtSearchBox5 = new Pawote.UI.Controls.PwtSearchBox();
            this.labelX6 = new DevComponents.DotNetBar.LabelX();
            this.textBoxX3 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX18 = new DevComponents.DotNetBar.LabelX();
            this.pwtSearchBox4 = new Pawote.UI.Controls.PwtSearchBox();
            this.labelX4 = new DevComponents.DotNetBar.LabelX();
            this.pwtSearchBox3 = new Pawote.UI.Controls.PwtSearchBox();
            this.labelX8 = new DevComponents.DotNetBar.LabelX();
            this.textBoxX5 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX20 = new DevComponents.DotNetBar.LabelX();
            this.comboBoxEx1 = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.comboItem1 = new DevComponents.Editors.ComboItem();
            this.comboItem2 = new DevComponents.Editors.ComboItem();
            this.comboItem3 = new DevComponents.Editors.ComboItem();
            this.comboItem7 = new DevComponents.Editors.ComboItem();
            this.comboItem4 = new DevComponents.Editors.ComboItem();
            this.comboItem5 = new DevComponents.Editors.ComboItem();
            this.comboItem6 = new DevComponents.Editors.ComboItem();
            this.labelX9 = new DevComponents.DotNetBar.LabelX();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.labelX12 = new DevComponents.DotNetBar.LabelX();
            this.textBoxX6 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.labelX11 = new DevComponents.DotNetBar.LabelX();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.textBoxX4 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX22 = new DevComponents.DotNetBar.LabelX();
            this.textBoxX12 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX24 = new DevComponents.DotNetBar.LabelX();
            this.textBoxX15 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.buttonX6 = new DevComponents.DotNetBar.ButtonX();
            this.labelX23 = new DevComponents.DotNetBar.LabelX();
            this.buttonX3 = new DevComponents.DotNetBar.ButtonX();
            this.buttonX2 = new DevComponents.DotNetBar.ButtonX();
            this.buttonX1 = new DevComponents.DotNetBar.ButtonX();
            this.groupPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.superTabControl1)).BeginInit();
            this.superTabControl1.SuspendLayout();
            this.superTabControlPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pwtDataGridView1)).BeginInit();
            this.superTabControlPanel2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupPanel1
            // 
            this.groupPanel1.CanvasColor = System.Drawing.SystemColors.Control;
            this.groupPanel1.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.groupPanel1.Controls.Add(this.buttonX5);
            this.groupPanel1.Controls.Add(this.buttonX4);
            this.groupPanel1.Controls.Add(this.superTabControl1);
            this.groupPanel1.Controls.Add(this.tableLayoutPanel1);
            this.groupPanel1.Controls.Add(this.buttonX3);
            this.groupPanel1.Controls.Add(this.buttonX2);
            this.groupPanel1.Controls.Add(this.buttonX1);
            this.groupPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupPanel1.Location = new System.Drawing.Point(0, 0);
            this.groupPanel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupPanel1.Name = "groupPanel1";
            this.groupPanel1.Size = new System.Drawing.Size(1406, 902);
            // 
            // 
            // 
            this.groupPanel1.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.groupPanel1.Style.BackColorGradientAngle = 90;
            this.groupPanel1.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.groupPanel1.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderBottomWidth = 1;
            this.groupPanel1.Style.BorderColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.groupPanel1.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderLeftWidth = 1;
            this.groupPanel1.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderRightWidth = 1;
            this.groupPanel1.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderTopWidth = 1;
            this.groupPanel1.Style.Class = "";
            this.groupPanel1.Style.CornerDiameter = 4;
            this.groupPanel1.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.groupPanel1.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.groupPanel1.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.groupPanel1.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.groupPanel1.StyleMouseDown.Class = "";
            this.groupPanel1.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.groupPanel1.StyleMouseOver.Class = "";
            this.groupPanel1.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.groupPanel1.TabIndex = 0;
            // 
            // buttonX5
            // 
            this.buttonX5.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX5.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX5.Location = new System.Drawing.Point(632, 6);
            this.buttonX5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.buttonX5.Name = "buttonX5";
            this.buttonX5.Size = new System.Drawing.Size(147, 51);
            this.buttonX5.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX5.TabIndex = 6;
            this.buttonX5.Text = "清空";
            this.buttonX5.Click += new System.EventHandler(this.buttonX5_Click);
            // 
            // buttonX4
            // 
            this.buttonX4.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX4.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX4.Location = new System.Drawing.Point(476, 6);
            this.buttonX4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.buttonX4.Name = "buttonX4";
            this.buttonX4.Size = new System.Drawing.Size(147, 51);
            this.buttonX4.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX4.TabIndex = 5;
            this.buttonX4.Text = "删除";
            this.buttonX4.Click += new System.EventHandler(this.buttonX4_Click);
            // 
            // superTabControl1
            // 
            this.superTabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            // 
            // 
            // 
            // 
            // 
            // 
            this.superTabControl1.ControlBox.CloseBox.Name = "";
            // 
            // 
            // 
            this.superTabControl1.ControlBox.MenuBox.Name = "";
            this.superTabControl1.ControlBox.Name = "";
            this.superTabControl1.ControlBox.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabControl1.ControlBox.MenuBox,
            this.superTabControl1.ControlBox.CloseBox});
            this.superTabControl1.Controls.Add(this.superTabControlPanel1);
            this.superTabControl1.Controls.Add(this.superTabControlPanel2);
            this.superTabControl1.Location = new System.Drawing.Point(8, 586);
            this.superTabControl1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.superTabControl1.Name = "superTabControl1";
            this.superTabControl1.ReorderTabsEnabled = true;
            this.superTabControl1.SelectedTabFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold);
            this.superTabControl1.SelectedTabIndex = 0;
            this.superTabControl1.Size = new System.Drawing.Size(1382, 300);
            this.superTabControl1.TabFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.superTabControl1.TabIndex = 4;
            this.superTabControl1.Tabs.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem1,
            this.superTabItem2});
            this.superTabControl1.Text = "superTabControl1";
            // 
            // superTabControlPanel1
            // 
            this.superTabControlPanel1.Controls.Add(this.pwtDataGridView1);
            this.superTabControlPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel1.Location = new System.Drawing.Point(0, 35);
            this.superTabControlPanel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.superTabControlPanel1.Name = "superTabControlPanel1";
            this.superTabControlPanel1.Size = new System.Drawing.Size(1382, 265);
            this.superTabControlPanel1.TabIndex = 1;
            this.superTabControlPanel1.TabItem = this.superTabItem1;
            // 
            // pwtDataGridView1
            // 
            this.pwtDataGridView1.AllowUserToAddRows = false;
            this.pwtDataGridView1.AllowUserToDeleteRows = false;
            this.pwtDataGridView1.AllowUserToOrderColumns = true;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(229)))), ((int)(((byte)(248)))));
            this.pwtDataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.pwtDataGridView1.BackgroundColor = System.Drawing.SystemColors.Window;
            this.pwtDataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(246)))), ((int)(((byte)(239)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.pwtDataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.pwtDataGridView1.ColumnHeadersHeight = 26;
            this.pwtDataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.Wheat;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.DarkSlateBlue;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.pwtDataGridView1.DefaultCellStyle = dataGridViewCellStyle3;
            this.pwtDataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pwtDataGridView1.EnableHeadersVisualStyles = false;
            this.pwtDataGridView1.GridColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pwtDataGridView1.Location = new System.Drawing.Point(0, 0);
            this.pwtDataGridView1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pwtDataGridView1.MergeColumnHeaderBackColor = System.Drawing.SystemColors.Control;
            this.pwtDataGridView1.MergeColumnNames = ((System.Collections.Generic.List<string>)(resources.GetObject("pwtDataGridView1.MergeColumnNames")));
            this.pwtDataGridView1.Name = "pwtDataGridView1";
            this.pwtDataGridView1.ReadOnly = true;
            this.pwtDataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.pwtDataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.pwtDataGridView1.RowHeadersWidth = 62;
            this.pwtDataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.pwtDataGridView1.RowTemplate.Height = 23;
            this.pwtDataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.pwtDataGridView1.Size = new System.Drawing.Size(1382, 265);
            this.pwtDataGridView1.TabIndex = 0;
            this.pwtDataGridView1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.pwtDataGridView1_MouseDoubleClick);
            // 
            // superTabItem1
            // 
            this.superTabItem1.AttachedControl = this.superTabControlPanel1;
            this.superTabItem1.GlobalItem = false;
            this.superTabItem1.Name = "superTabItem1";
            this.superTabItem1.Text = "异常报告信息";
            // 
            // superTabControlPanel2
            // 
            this.superTabControlPanel2.Controls.Add(this.textBoxX11);
            this.superTabControlPanel2.Controls.Add(this.labelX17);
            this.superTabControlPanel2.Controls.Add(this.textBoxX10);
            this.superTabControlPanel2.Controls.Add(this.labelX16);
            this.superTabControlPanel2.Controls.Add(this.textBoxX9);
            this.superTabControlPanel2.Controls.Add(this.labelX15);
            this.superTabControlPanel2.Controls.Add(this.textBoxX8);
            this.superTabControlPanel2.Controls.Add(this.textBoxX7);
            this.superTabControlPanel2.Controls.Add(this.labelX14);
            this.superTabControlPanel2.Controls.Add(this.labelX13);
            this.superTabControlPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel2.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.superTabControlPanel2.Name = "superTabControlPanel2";
            this.superTabControlPanel2.Size = new System.Drawing.Size(1382, 300);
            this.superTabControlPanel2.TabIndex = 0;
            this.superTabControlPanel2.TabItem = this.superTabItem2;
            // 
            // textBoxX11
            // 
            // 
            // 
            // 
            this.textBoxX11.Border.Class = "TextBoxBorder";
            this.textBoxX11.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX11.Location = new System.Drawing.Point(114, 256);
            this.textBoxX11.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX11.Name = "textBoxX11";
            this.textBoxX11.Size = new System.Drawing.Size(150, 39);
            this.textBoxX11.TabIndex = 9;
            // 
            // labelX17
            // 
            this.labelX17.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX17.BackgroundStyle.Class = "";
            this.labelX17.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX17.Location = new System.Drawing.Point(30, 260);
            this.labelX17.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX17.Name = "labelX17";
            this.labelX17.Size = new System.Drawing.Size(75, 34);
            this.labelX17.TabIndex = 8;
            this.labelX17.Text = "info6";
            // 
            // textBoxX10
            // 
            // 
            // 
            // 
            this.textBoxX10.Border.Class = "TextBoxBorder";
            this.textBoxX10.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX10.Location = new System.Drawing.Point(114, 216);
            this.textBoxX10.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX10.Name = "textBoxX10";
            this.textBoxX10.Size = new System.Drawing.Size(150, 39);
            this.textBoxX10.TabIndex = 7;
            // 
            // labelX16
            // 
            this.labelX16.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX16.BackgroundStyle.Class = "";
            this.labelX16.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX16.Location = new System.Drawing.Point(30, 219);
            this.labelX16.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX16.Name = "labelX16";
            this.labelX16.Size = new System.Drawing.Size(75, 34);
            this.labelX16.TabIndex = 6;
            this.labelX16.Text = "info5";
            // 
            // textBoxX9
            // 
            // 
            // 
            // 
            this.textBoxX9.Border.Class = "TextBoxBorder";
            this.textBoxX9.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX9.Location = new System.Drawing.Point(114, 176);
            this.textBoxX9.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX9.Name = "textBoxX9";
            this.textBoxX9.Size = new System.Drawing.Size(150, 39);
            this.textBoxX9.TabIndex = 5;
            // 
            // labelX15
            // 
            this.labelX15.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX15.BackgroundStyle.Class = "";
            this.labelX15.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX15.Location = new System.Drawing.Point(30, 178);
            this.labelX15.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX15.Name = "labelX15";
            this.labelX15.Size = new System.Drawing.Size(75, 34);
            this.labelX15.TabIndex = 4;
            this.labelX15.Text = "info4";
            // 
            // textBoxX8
            // 
            // 
            // 
            // 
            this.textBoxX8.Border.Class = "TextBoxBorder";
            this.textBoxX8.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX8.Location = new System.Drawing.Point(114, 129);
            this.textBoxX8.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX8.Name = "textBoxX8";
            this.textBoxX8.Size = new System.Drawing.Size(150, 39);
            this.textBoxX8.TabIndex = 3;
            // 
            // textBoxX7
            // 
            // 
            // 
            // 
            this.textBoxX7.Border.Class = "TextBoxBorder";
            this.textBoxX7.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX7.Location = new System.Drawing.Point(114, 88);
            this.textBoxX7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX7.Name = "textBoxX7";
            this.textBoxX7.Size = new System.Drawing.Size(150, 39);
            this.textBoxX7.TabIndex = 3;
            // 
            // labelX14
            // 
            this.labelX14.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX14.BackgroundStyle.Class = "";
            this.labelX14.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX14.Location = new System.Drawing.Point(30, 132);
            this.labelX14.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX14.Name = "labelX14";
            this.labelX14.Size = new System.Drawing.Size(75, 34);
            this.labelX14.TabIndex = 2;
            this.labelX14.Text = "info3";
            // 
            // labelX13
            // 
            this.labelX13.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX13.BackgroundStyle.Class = "";
            this.labelX13.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX13.Location = new System.Drawing.Point(30, 88);
            this.labelX13.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX13.Name = "labelX13";
            this.labelX13.Size = new System.Drawing.Size(75, 34);
            this.labelX13.TabIndex = 1;
            this.labelX13.Text = "info2";
            // 
            // superTabItem2
            // 
            this.superTabItem2.AttachedControl = this.superTabControlPanel2;
            this.superTabItem2.GlobalItem = false;
            this.superTabItem2.Name = "superTabItem2";
            this.superTabItem2.Text = "隐藏";
            this.superTabItem2.Visible = false;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel1.ColumnCount = 8;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.Controls.Add(this.checkBoxX1, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.labelX10, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.dateTimePicker2, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX13, 7, 1);
            this.tableLayoutPanel1.Controls.Add(this.labelX19, 6, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX2, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this.labelX5, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX1, 7, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelX3, 6, 0);
            this.tableLayoutPanel1.Controls.Add(this.pwtSearchBox2, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelX2, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.pwtSearchBox1, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelX1, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelX21, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.pwtSearchBox5, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelX6, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX3, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.labelX18, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.pwtSearchBox4, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.labelX4, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.pwtSearchBox3, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.labelX8, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX5, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.labelX20, 4, 4);
            this.tableLayoutPanel1.Controls.Add(this.comboBoxEx1, 5, 4);
            this.tableLayoutPanel1.Controls.Add(this.labelX9, 6, 4);
            this.tableLayoutPanel1.Controls.Add(this.dateTimePicker1, 7, 4);
            this.tableLayoutPanel1.Controls.Add(this.labelX12, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX6, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.dateTimePicker3, 5, 7);
            this.tableLayoutPanel1.Controls.Add(this.labelX11, 4, 7);
            this.tableLayoutPanel1.Controls.Add(this.groupBox1, 0, 2);
            this.tableLayoutPanel1.Font = new System.Drawing.Font("宋体", 11F);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(8, 66);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 8;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1382, 513);
            this.tableLayoutPanel1.TabIndex = 3;
            // 
            // checkBoxX1
            // 
            // 
            // 
            // 
            this.checkBoxX1.BackgroundStyle.Class = "";
            this.checkBoxX1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.checkBoxX1.Checked = true;
            this.checkBoxX1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxX1.CheckValue = "Y";
            this.tableLayoutPanel1.SetColumnSpan(this.checkBoxX1, 2);
            this.checkBoxX1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBoxX1.Location = new System.Drawing.Point(144, 388);
            this.checkBoxX1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.checkBoxX1.Name = "checkBoxX1";
            this.checkBoxX1.Size = new System.Drawing.Size(337, 56);
            this.checkBoxX1.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.checkBoxX1.TabIndex = 3;
            this.checkBoxX1.Text = "添加时间条件";
            // 
            // labelX10
            // 
            // 
            // 
            // 
            this.labelX10.BackgroundStyle.Class = "";
            this.labelX10.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX10.Location = new System.Drawing.Point(4, 452);
            this.labelX10.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX10.Name = "labelX10";
            this.labelX10.Size = new System.Drawing.Size(128, 40);
            this.labelX10.TabIndex = 4;
            this.labelX10.Text = "开始时间";
            // 
            // dateTimePicker2
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.dateTimePicker2, 3);
            this.dateTimePicker2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dateTimePicker2.Location = new System.Drawing.Point(144, 452);
            this.dateTimePicker2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(542, 33);
            this.dateTimePicker2.TabIndex = 7;
            // 
            // textBoxX13
            // 
            // 
            // 
            // 
            this.textBoxX13.Border.Class = "TextBoxBorder";
            this.textBoxX13.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX13.Location = new System.Drawing.Point(1179, 68);
            this.textBoxX13.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX13.Name = "textBoxX13";
            this.textBoxX13.Size = new System.Drawing.Size(199, 46);
            this.textBoxX13.TabIndex = 16;
            // 
            // labelX19
            // 
            // 
            // 
            // 
            this.labelX19.BackgroundStyle.Class = "";
            this.labelX19.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX19.Location = new System.Drawing.Point(1039, 68);
            this.labelX19.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX19.Name = "labelX19";
            this.labelX19.Size = new System.Drawing.Size(132, 56);
            this.labelX19.TabIndex = 0;
            this.labelX19.Text = "批次良率";
            // 
            // textBoxX2
            // 
            // 
            // 
            // 
            this.textBoxX2.Border.Class = "TextBoxBorder";
            this.textBoxX2.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX2.Location = new System.Drawing.Point(834, 68);
            this.textBoxX2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX2.Name = "textBoxX2";
            this.textBoxX2.Size = new System.Drawing.Size(197, 46);
            this.textBoxX2.TabIndex = 13;
            // 
            // labelX5
            // 
            // 
            // 
            // 
            this.labelX5.BackgroundStyle.Class = "";
            this.labelX5.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX5.Location = new System.Drawing.Point(694, 68);
            this.labelX5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX5.Name = "labelX5";
            this.labelX5.Size = new System.Drawing.Size(132, 56);
            this.labelX5.TabIndex = 0;
            this.labelX5.Text = "批量数";
            // 
            // textBoxX1
            // 
            // 
            // 
            // 
            this.textBoxX1.Border.Class = "TextBoxBorder";
            this.textBoxX1.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX1.Location = new System.Drawing.Point(1179, 4);
            this.textBoxX1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX1.Name = "textBoxX1";
            this.textBoxX1.Size = new System.Drawing.Size(199, 46);
            this.textBoxX1.TabIndex = 11;
            // 
            // labelX3
            // 
            // 
            // 
            // 
            this.labelX3.BackgroundStyle.Class = "";
            this.labelX3.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX3.Location = new System.Drawing.Point(1039, 4);
            this.labelX3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX3.Name = "labelX3";
            this.labelX3.Size = new System.Drawing.Size(132, 56);
            this.labelX3.TabIndex = 2;
            this.labelX3.Text = "客户批号";
            // 
            // pwtSearchBox2
            // 
            this.pwtSearchBox2.BackColor = System.Drawing.Color.White;
            this.pwtSearchBox2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(128)))), ((int)(((byte)(160)))));
            this.pwtSearchBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pwtSearchBox2.EmptyText = null;
            this.pwtSearchBox2.ImageHover = ((System.Drawing.Image)(resources.GetObject("pwtSearchBox2.ImageHover")));
            this.pwtSearchBox2.ImageNormal = ((System.Drawing.Image)(resources.GetObject("pwtSearchBox2.ImageNormal")));
            this.pwtSearchBox2.InputChangeTriggerTime = 600;
            this.pwtSearchBox2.IsSpaceKeyCodeValid = false;
            this.pwtSearchBox2.Location = new System.Drawing.Point(834, 4);
            this.pwtSearchBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pwtSearchBox2.Name = "pwtSearchBox2";
            this.pwtSearchBox2.SearchBtnHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(214)))), ((int)(((byte)(125)))));
            this.pwtSearchBox2.Size = new System.Drawing.Size(197, 56);
            this.pwtSearchBox2.TabIndex = 10;
            this.pwtSearchBox2.SearchBtnClick += new System.EventHandler(this.pwtSearchBox2_SearchBtnClick);
            // 
            // labelX2
            // 
            // 
            // 
            // 
            this.labelX2.BackgroundStyle.Class = "";
            this.labelX2.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX2.Location = new System.Drawing.Point(694, 4);
            this.labelX2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX2.Name = "labelX2";
            this.labelX2.Size = new System.Drawing.Size(132, 56);
            this.labelX2.TabIndex = 1;
            this.labelX2.Text = "产品型号";
            // 
            // pwtSearchBox1
            // 
            this.pwtSearchBox1.BackColor = System.Drawing.Color.White;
            this.pwtSearchBox1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(128)))), ((int)(((byte)(160)))));
            this.pwtSearchBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pwtSearchBox1.EmptyText = null;
            this.pwtSearchBox1.ImageHover = ((System.Drawing.Image)(resources.GetObject("pwtSearchBox1.ImageHover")));
            this.pwtSearchBox1.ImageNormal = ((System.Drawing.Image)(resources.GetObject("pwtSearchBox1.ImageNormal")));
            this.pwtSearchBox1.InputChangeTriggerTime = 600;
            this.pwtSearchBox1.IsSpaceKeyCodeValid = false;
            this.pwtSearchBox1.Location = new System.Drawing.Point(489, 4);
            this.pwtSearchBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pwtSearchBox1.Name = "pwtSearchBox1";
            this.pwtSearchBox1.SearchBtnHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(214)))), ((int)(((byte)(125)))));
            this.pwtSearchBox1.Size = new System.Drawing.Size(197, 56);
            this.pwtSearchBox1.TabIndex = 9;
            this.pwtSearchBox1.SearchBtnClick += new System.EventHandler(this.pwtSearchBox1_SearchBtnClick);
            // 
            // labelX1
            // 
            // 
            // 
            // 
            this.labelX1.BackgroundStyle.Class = "";
            this.labelX1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX1.Location = new System.Drawing.Point(349, 4);
            this.labelX1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX1.Name = "labelX1";
            this.labelX1.Size = new System.Drawing.Size(132, 56);
            this.labelX1.TabIndex = 0;
            this.labelX1.Text = "客户名称";
            // 
            // labelX21
            // 
            // 
            // 
            // 
            this.labelX21.BackgroundStyle.Class = "";
            this.labelX21.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX21.Location = new System.Drawing.Point(4, 4);
            this.labelX21.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX21.Name = "labelX21";
            this.labelX21.Size = new System.Drawing.Size(132, 56);
            this.labelX21.TabIndex = 0;
            this.labelX21.Text = "流程卡号";
            // 
            // pwtSearchBox5
            // 
            this.pwtSearchBox5.BackColor = System.Drawing.Color.White;
            this.pwtSearchBox5.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(128)))), ((int)(((byte)(160)))));
            this.pwtSearchBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pwtSearchBox5.EmptyText = null;
            this.pwtSearchBox5.ImageHover = ((System.Drawing.Image)(resources.GetObject("pwtSearchBox5.ImageHover")));
            this.pwtSearchBox5.ImageNormal = ((System.Drawing.Image)(resources.GetObject("pwtSearchBox5.ImageNormal")));
            this.pwtSearchBox5.InputChangeTriggerTime = 600;
            this.pwtSearchBox5.IsSpaceKeyCodeValid = false;
            this.pwtSearchBox5.Location = new System.Drawing.Point(144, 4);
            this.pwtSearchBox5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pwtSearchBox5.Name = "pwtSearchBox5";
            this.pwtSearchBox5.SearchBtnHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(214)))), ((int)(((byte)(125)))));
            this.pwtSearchBox5.Size = new System.Drawing.Size(197, 56);
            this.pwtSearchBox5.TabIndex = 9;
            this.pwtSearchBox5.SearchBtnClick += new System.EventHandler(this.pwtSearchBox5_SearchBtnClick);
            // 
            // labelX6
            // 
            // 
            // 
            // 
            this.labelX6.BackgroundStyle.Class = "";
            this.labelX6.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX6.Location = new System.Drawing.Point(4, 68);
            this.labelX6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX6.Name = "labelX6";
            this.labelX6.Size = new System.Drawing.Size(132, 56);
            this.labelX6.TabIndex = 0;
            this.labelX6.Text = "不良数";
            // 
            // textBoxX3
            // 
            // 
            // 
            // 
            this.textBoxX3.Border.Class = "TextBoxBorder";
            this.textBoxX3.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX3.Location = new System.Drawing.Point(144, 68);
            this.textBoxX3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX3.Name = "textBoxX3";
            this.textBoxX3.Size = new System.Drawing.Size(197, 46);
            this.textBoxX3.TabIndex = 14;
            // 
            // labelX18
            // 
            // 
            // 
            // 
            this.labelX18.BackgroundStyle.Class = "";
            this.labelX18.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX18.Location = new System.Drawing.Point(349, 68);
            this.labelX18.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX18.Name = "labelX18";
            this.labelX18.Size = new System.Drawing.Size(132, 56);
            this.labelX18.TabIndex = 0;
            this.labelX18.Text = "单片良率";
            // 
            // pwtSearchBox4
            // 
            this.pwtSearchBox4.BackColor = System.Drawing.Color.White;
            this.pwtSearchBox4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(128)))), ((int)(((byte)(160)))));
            this.pwtSearchBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pwtSearchBox4.EmptyText = null;
            this.pwtSearchBox4.ImageHover = ((System.Drawing.Image)(resources.GetObject("pwtSearchBox4.ImageHover")));
            this.pwtSearchBox4.ImageNormal = ((System.Drawing.Image)(resources.GetObject("pwtSearchBox4.ImageNormal")));
            this.pwtSearchBox4.InputChangeTriggerTime = 600;
            this.pwtSearchBox4.IsSpaceKeyCodeValid = false;
            this.pwtSearchBox4.Location = new System.Drawing.Point(489, 68);
            this.pwtSearchBox4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pwtSearchBox4.Name = "pwtSearchBox4";
            this.pwtSearchBox4.SearchBtnHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(214)))), ((int)(((byte)(125)))));
            this.pwtSearchBox4.Size = new System.Drawing.Size(197, 56);
            this.pwtSearchBox4.TabIndex = 10;
            this.pwtSearchBox4.SearchBtnClick += new System.EventHandler(this.pwtSearchBox4_SearchBtnClick);
            // 
            // labelX4
            // 
            // 
            // 
            // 
            this.labelX4.BackgroundStyle.Class = "";
            this.labelX4.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX4.Location = new System.Drawing.Point(4, 260);
            this.labelX4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX4.Name = "labelX4";
            this.labelX4.Size = new System.Drawing.Size(132, 56);
            this.labelX4.TabIndex = 0;
            this.labelX4.Text = "机台编号";
            // 
            // pwtSearchBox3
            // 
            this.pwtSearchBox3.BackColor = System.Drawing.Color.White;
            this.pwtSearchBox3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(128)))), ((int)(((byte)(160)))));
            this.pwtSearchBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pwtSearchBox3.EmptyText = null;
            this.pwtSearchBox3.ImageHover = ((System.Drawing.Image)(resources.GetObject("pwtSearchBox3.ImageHover")));
            this.pwtSearchBox3.ImageNormal = ((System.Drawing.Image)(resources.GetObject("pwtSearchBox3.ImageNormal")));
            this.pwtSearchBox3.InputChangeTriggerTime = 600;
            this.pwtSearchBox3.IsSpaceKeyCodeValid = false;
            this.pwtSearchBox3.Location = new System.Drawing.Point(144, 260);
            this.pwtSearchBox3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pwtSearchBox3.Name = "pwtSearchBox3";
            this.pwtSearchBox3.SearchBtnHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(214)))), ((int)(((byte)(125)))));
            this.pwtSearchBox3.Size = new System.Drawing.Size(197, 56);
            this.pwtSearchBox3.TabIndex = 12;
            // 
            // labelX8
            // 
            // 
            // 
            // 
            this.labelX8.BackgroundStyle.Class = "";
            this.labelX8.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX8.Location = new System.Drawing.Point(349, 260);
            this.labelX8.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX8.Name = "labelX8";
            this.labelX8.Size = new System.Drawing.Size(132, 56);
            this.labelX8.TabIndex = 0;
            this.labelX8.Text = "异常发现人";
            // 
            // textBoxX5
            // 
            // 
            // 
            // 
            this.textBoxX5.Border.Class = "TextBoxBorder";
            this.textBoxX5.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX5.Location = new System.Drawing.Point(489, 260);
            this.textBoxX5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX5.Name = "textBoxX5";
            this.textBoxX5.Size = new System.Drawing.Size(197, 46);
            this.textBoxX5.TabIndex = 16;
            // 
            // labelX20
            // 
            this.labelX20.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX20.BackgroundStyle.Class = "";
            this.labelX20.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX20.Location = new System.Drawing.Point(694, 260);
            this.labelX20.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX20.Name = "labelX20";
            this.labelX20.Size = new System.Drawing.Size(132, 56);
            this.labelX20.TabIndex = 0;
            this.labelX20.Text = "流程";
            // 
            // comboBoxEx1
            // 
            this.comboBoxEx1.DisplayMember = "Text";
            this.comboBoxEx1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxEx1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.comboBoxEx1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxEx1.FormattingEnabled = true;
            this.comboBoxEx1.ItemHeight = 27;
            this.comboBoxEx1.Items.AddRange(new object[] {
            this.comboItem1,
            this.comboItem2,
            this.comboItem3,
            this.comboItem7,
            this.comboItem4,
            this.comboItem5,
            this.comboItem6});
            this.comboBoxEx1.Location = new System.Drawing.Point(834, 260);
            this.comboBoxEx1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.comboBoxEx1.Name = "comboBoxEx1";
            this.comboBoxEx1.Size = new System.Drawing.Size(197, 33);
            this.comboBoxEx1.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.comboBoxEx1.TabIndex = 15;
            // 
            // comboItem1
            // 
            this.comboItem1.Text = "CP1";
            // 
            // comboItem2
            // 
            this.comboItem2.Text = "CP2";
            // 
            // comboItem3
            // 
            this.comboItem3.Text = "CP3";
            // 
            // comboItem7
            // 
            this.comboItem7.Text = "CP4";
            // 
            // comboItem4
            // 
            this.comboItem4.Text = "laser1";
            // 
            // comboItem5
            // 
            this.comboItem5.Text = "laser2";
            // 
            // comboItem6
            // 
            this.comboItem6.Text = "laser3";
            // 
            // labelX9
            // 
            // 
            // 
            // 
            this.labelX9.BackgroundStyle.Class = "";
            this.labelX9.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX9.Location = new System.Drawing.Point(1039, 260);
            this.labelX9.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX9.Name = "labelX9";
            this.labelX9.Size = new System.Drawing.Size(132, 56);
            this.labelX9.TabIndex = 0;
            this.labelX9.Text = "日期";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dateTimePicker1.Location = new System.Drawing.Point(1179, 260);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(199, 33);
            this.dateTimePicker1.TabIndex = 6;
            // 
            // labelX12
            // 
            this.labelX12.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX12.BackgroundStyle.Class = "";
            this.labelX12.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX12.Location = new System.Drawing.Point(4, 324);
            this.labelX12.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX12.Name = "labelX12";
            this.labelX12.Size = new System.Drawing.Size(132, 56);
            this.labelX12.TabIndex = 0;
            this.labelX12.Text = "备注说明";
            // 
            // textBoxX6
            // 
            // 
            // 
            // 
            this.textBoxX6.Border.Class = "TextBoxBorder";
            this.textBoxX6.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.tableLayoutPanel1.SetColumnSpan(this.textBoxX6, 7);
            this.textBoxX6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX6.Location = new System.Drawing.Point(144, 324);
            this.textBoxX6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX6.Name = "textBoxX6";
            this.textBoxX6.Size = new System.Drawing.Size(1234, 46);
            this.textBoxX6.TabIndex = 3;
            // 
            // dateTimePicker3
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.dateTimePicker3, 3);
            this.dateTimePicker3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dateTimePicker3.Location = new System.Drawing.Point(834, 452);
            this.dateTimePicker3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.Size = new System.Drawing.Size(544, 33);
            this.dateTimePicker3.TabIndex = 8;
            // 
            // labelX11
            // 
            // 
            // 
            // 
            this.labelX11.BackgroundStyle.Class = "";
            this.labelX11.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX11.Location = new System.Drawing.Point(694, 452);
            this.labelX11.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX11.Name = "labelX11";
            this.labelX11.Size = new System.Drawing.Size(128, 40);
            this.labelX11.TabIndex = 5;
            this.labelX11.Text = "结束时间";
            // 
            // groupBox1
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.groupBox1, 8);
            this.groupBox1.Controls.Add(this.tableLayoutPanel2);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(2, 130);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tableLayoutPanel1.SetRowSpan(this.groupBox1, 2);
            this.groupBox1.Size = new System.Drawing.Size(1378, 124);
            this.groupBox1.TabIndex = 17;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "异常描述：";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 5;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel2.Controls.Add(this.textBoxX4, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.labelX22, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.textBoxX12, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.labelX24, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.textBoxX15, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.buttonX6, 4, 0);
            this.tableLayoutPanel2.Controls.Add(this.labelX23, 0, 1);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(2, 28);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1374, 94);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // textBoxX4
            // 
            // 
            // 
            // 
            this.textBoxX4.Border.Class = "TextBoxBorder";
            this.textBoxX4.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.tableLayoutPanel2.SetColumnSpan(this.textBoxX4, 4);
            this.textBoxX4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX4.Location = new System.Drawing.Point(144, 51);
            this.textBoxX4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX4.Multiline = true;
            this.textBoxX4.Name = "textBoxX4";
            this.textBoxX4.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxX4.Size = new System.Drawing.Size(1226, 39);
            this.textBoxX4.TabIndex = 15;
            // 
            // labelX22
            // 
            // 
            // 
            // 
            this.labelX22.BackgroundStyle.Class = "";
            this.labelX22.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX22.Location = new System.Drawing.Point(4, 4);
            this.labelX22.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX22.Name = "labelX22";
            this.labelX22.Size = new System.Drawing.Size(132, 39);
            this.labelX22.TabIndex = 0;
            this.labelX22.Text = "片号";
            // 
            // textBoxX12
            // 
            // 
            // 
            // 
            this.textBoxX12.Border.Class = "TextBoxBorder";
            this.textBoxX12.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX12.Location = new System.Drawing.Point(144, 4);
            this.textBoxX12.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX12.Name = "textBoxX12";
            this.textBoxX12.Size = new System.Drawing.Size(469, 46);
            this.textBoxX12.TabIndex = 14;
            // 
            // labelX24
            // 
            // 
            // 
            // 
            this.labelX24.BackgroundStyle.Class = "";
            this.labelX24.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX24.Location = new System.Drawing.Point(621, 4);
            this.labelX24.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX24.Name = "labelX24";
            this.labelX24.Size = new System.Drawing.Size(132, 39);
            this.labelX24.TabIndex = 0;
            this.labelX24.Text = "Bin";
            // 
            // textBoxX15
            // 
            // 
            // 
            // 
            this.textBoxX15.Border.Class = "TextBoxBorder";
            this.textBoxX15.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX15.Location = new System.Drawing.Point(761, 4);
            this.textBoxX15.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxX15.Name = "textBoxX15";
            this.textBoxX15.Size = new System.Drawing.Size(469, 46);
            this.textBoxX15.TabIndex = 14;
            // 
            // buttonX6
            // 
            this.buttonX6.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX6.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonX6.Location = new System.Drawing.Point(1238, 4);
            this.buttonX6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.buttonX6.Name = "buttonX6";
            this.buttonX6.Size = new System.Drawing.Size(132, 39);
            this.buttonX6.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX6.TabIndex = 7;
            this.buttonX6.Text = "添加";
            this.buttonX6.Click += new System.EventHandler(this.buttonX6_Click);
            // 
            // labelX23
            // 
            // 
            // 
            // 
            this.labelX23.BackgroundStyle.Class = "";
            this.labelX23.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX23.Location = new System.Drawing.Point(4, 51);
            this.labelX23.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelX23.Name = "labelX23";
            this.labelX23.Size = new System.Drawing.Size(132, 39);
            this.labelX23.TabIndex = 0;
            this.labelX23.Text = "异常描述：";
            // 
            // buttonX3
            // 
            this.buttonX3.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX3.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX3.Location = new System.Drawing.Point(320, 6);
            this.buttonX3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.buttonX3.Name = "buttonX3";
            this.buttonX3.Size = new System.Drawing.Size(147, 51);
            this.buttonX3.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX3.TabIndex = 2;
            this.buttonX3.Text = "修改";
            this.buttonX3.Click += new System.EventHandler(this.buttonX3_Click);
            // 
            // buttonX2
            // 
            this.buttonX2.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX2.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX2.Location = new System.Drawing.Point(164, 6);
            this.buttonX2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.buttonX2.Name = "buttonX2";
            this.buttonX2.Size = new System.Drawing.Size(147, 51);
            this.buttonX2.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX2.TabIndex = 1;
            this.buttonX2.Text = "登记";
            this.buttonX2.Click += new System.EventHandler(this.buttonX2_Click);
            // 
            // buttonX1
            // 
            this.buttonX1.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX1.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX1.Location = new System.Drawing.Point(8, 6);
            this.buttonX1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.buttonX1.Name = "buttonX1";
            this.buttonX1.Size = new System.Drawing.Size(147, 51);
            this.buttonX1.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX1.TabIndex = 0;
            this.buttonX1.Text = "查询";
            this.buttonX1.Click += new System.EventHandler(this.buttonX1_Click);
            // 
            // 生产异常处理报告
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1406, 902);
            this.Controls.Add(this.groupPanel1);
            this.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "生产异常处理报告";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "生产异常处理报告";
            this.Load += new System.EventHandler(this.生产异常处理报告_Load);
            this.groupPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.superTabControl1)).EndInit();
            this.superTabControl1.ResumeLayout(false);
            this.superTabControlPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pwtDataGridView1)).EndInit();
            this.superTabControlPanel2.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private DevComponents.DotNetBar.Controls.GroupPanel groupPanel1;
        private DevComponents.DotNetBar.ButtonX buttonX1;
        private DevComponents.DotNetBar.ButtonX buttonX3;
        private DevComponents.DotNetBar.ButtonX buttonX2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private DevComponents.DotNetBar.SuperTabControl superTabControl1;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel1;
        private DevComponents.DotNetBar.SuperTabItem superTabItem1;
        private Pawote.UI.Controls.PwtDataGridView pwtDataGridView1;
        private DevComponents.DotNetBar.ButtonX buttonX4;
        private DevComponents.DotNetBar.LabelX labelX1;
        private DevComponents.DotNetBar.LabelX labelX2;
        private DevComponents.DotNetBar.LabelX labelX3;
        private DevComponents.DotNetBar.LabelX labelX4;
        private DevComponents.DotNetBar.LabelX labelX5;
        private DevComponents.DotNetBar.LabelX labelX6;
        private DevComponents.DotNetBar.LabelX labelX8;
        private DevComponents.DotNetBar.LabelX labelX9;
        private DevComponents.DotNetBar.Controls.CheckBoxX checkBoxX1;
        private DevComponents.DotNetBar.LabelX labelX10;
        private DevComponents.DotNetBar.LabelX labelX11;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.DateTimePicker dateTimePicker3;
        private Pawote.UI.Controls.PwtSearchBox pwtSearchBox1;
        private Pawote.UI.Controls.PwtSearchBox pwtSearchBox2;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX1;
        private Pawote.UI.Controls.PwtSearchBox pwtSearchBox3;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX2;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX3;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX4;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX5;
        private DevComponents.DotNetBar.ButtonX buttonX5;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel2;
        private DevComponents.DotNetBar.SuperTabItem superTabItem2;
        private DevComponents.DotNetBar.LabelX labelX14;
        private DevComponents.DotNetBar.LabelX labelX13;
        private DevComponents.DotNetBar.LabelX labelX12;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX8;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX7;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX6;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX10;
        private DevComponents.DotNetBar.LabelX labelX16;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX9;
        private DevComponents.DotNetBar.LabelX labelX15;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX11;
        private DevComponents.DotNetBar.LabelX labelX17;
        private DevComponents.DotNetBar.LabelX labelX18;
        private DevComponents.DotNetBar.LabelX labelX19;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX13;
        private Pawote.UI.Controls.PwtSearchBox pwtSearchBox4;
        private DevComponents.DotNetBar.LabelX labelX20;
        private DevComponents.DotNetBar.Controls.ComboBoxEx comboBoxEx1;
        private DevComponents.Editors.ComboItem comboItem1;
        private DevComponents.Editors.ComboItem comboItem2;
        private DevComponents.Editors.ComboItem comboItem3;
        private DevComponents.Editors.ComboItem comboItem7;
        private DevComponents.Editors.ComboItem comboItem4;
        private DevComponents.Editors.ComboItem comboItem5;
        private DevComponents.Editors.ComboItem comboItem6;
        private DevComponents.DotNetBar.LabelX labelX21;
        private Pawote.UI.Controls.PwtSearchBox pwtSearchBox5;
        private DevComponents.DotNetBar.ButtonX buttonX6;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX15;
        private DevComponents.DotNetBar.LabelX labelX24;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX12;
        private DevComponents.DotNetBar.LabelX labelX22;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private DevComponents.DotNetBar.LabelX labelX23;
    }
}
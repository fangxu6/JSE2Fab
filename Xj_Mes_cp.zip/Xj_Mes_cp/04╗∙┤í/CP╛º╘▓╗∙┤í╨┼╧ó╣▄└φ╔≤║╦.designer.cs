﻿
namespace Xj_Mes_cp
{
    partial class CP晶圆基础信息管理审核
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Pawote.UI.Controls.CheckImageTable checkImageTable1 = new Pawote.UI.Controls.CheckImageTable();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CP晶圆基础信息管理审核));
            Pawote.UI.Controls.CheckImageTable checkImageTable2 = new Pawote.UI.Controls.CheckImageTable();
            Pawote.UI.Controls.CheckImageTable checkImageTable3 = new Pawote.UI.Controls.CheckImageTable();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panelEx1 = new DevComponents.DotNetBar.PanelEx();
            this.pwtRadioButton3 = new Pawote.UI.Controls.PwtRadioButton();
            this.pwtRadioButton2 = new Pawote.UI.Controls.PwtRadioButton();
            this.pwtRadioButton1 = new Pawote.UI.Controls.PwtRadioButton();
            this.buttonX16 = new DevComponents.DotNetBar.ButtonX();
            this.buttonX15 = new DevComponents.DotNetBar.ButtonX();
            this.buttonX5 = new DevComponents.DotNetBar.ButtonX();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.textBoxX4 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX19 = new DevComponents.DotNetBar.LabelX();
            this.labelX13 = new DevComponents.DotNetBar.LabelX();
            this.textBoxX6 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX1 = new DevComponents.DotNetBar.LabelX();
            this.textBoxX1 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX29 = new DevComponents.DotNetBar.LabelX();
            this.pwtSearchBox3 = new Pawote.UI.Controls.PwtSearchBox();
            this.labelX30 = new DevComponents.DotNetBar.LabelX();
            this.pwtSearchBox4 = new Pawote.UI.Controls.PwtSearchBox();
            this.labelX14 = new DevComponents.DotNetBar.LabelX();
            this.pwtSearchBox2 = new Pawote.UI.Controls.PwtSearchBox();
            this.labelX17 = new DevComponents.DotNetBar.LabelX();
            this.textBoxX3 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX2 = new DevComponents.DotNetBar.LabelX();
            this.textBoxX2 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX23 = new DevComponents.DotNetBar.LabelX();
            this.textBoxX9 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX20 = new DevComponents.DotNetBar.LabelX();
            this.textBoxX8 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX15 = new DevComponents.DotNetBar.LabelX();
            this.textBoxX7 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX31 = new DevComponents.DotNetBar.LabelX();
            this.comboBoxEx3 = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.comboItem1 = new DevComponents.Editors.ComboItem();
            this.comboItem2 = new DevComponents.Editors.ComboItem();
            this.labelX28 = new DevComponents.DotNetBar.LabelX();
            this.textBoxX19 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX22 = new DevComponents.DotNetBar.LabelX();
            this.textBoxX16 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.superTabControl1 = new DevComponents.DotNetBar.SuperTabControl();
            this.superTabControlPanel1 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.superTabControl2 = new DevComponents.DotNetBar.SuperTabControl();
            this.superTabControlPanel3 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.superTabControl3 = new DevComponents.DotNetBar.SuperTabControl();
            this.superTabControlPanel6 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.pwtDataGridView2 = new Pawote.UI.Controls.PwtDataGridView();
            this.superTabItem6 = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel7 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.pwtDataGridView5 = new Pawote.UI.Controls.PwtDataGridView();
            this.superTabItem7 = new DevComponents.DotNetBar.SuperTabItem();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonX6 = new DevComponents.DotNetBar.ButtonX();
            this.buttonX8 = new DevComponents.DotNetBar.ButtonX();
            this.buttonX7 = new DevComponents.DotNetBar.ButtonX();
            this.superTabItem3 = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel8 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.pwtDataGridView6 = new Pawote.UI.Controls.PwtDataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.superTabItem8 = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel5 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.pwtDataGridView4 = new Pawote.UI.Controls.PwtDataGridView();
            this.buttonX14 = new DevComponents.DotNetBar.ButtonX();
            this.buttonX12 = new DevComponents.DotNetBar.ButtonX();
            this.buttonX10 = new DevComponents.DotNetBar.ButtonX();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.labelX25 = new DevComponents.DotNetBar.LabelX();
            this.comboBoxEx2 = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.labelX26 = new DevComponents.DotNetBar.LabelX();
            this.textBoxX17 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.superTabItem5 = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel4 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.pwtDataGridView3 = new Pawote.UI.Controls.PwtDataGridView();
            this.labelX34 = new DevComponents.DotNetBar.LabelX();
            this.buttonX13 = new DevComponents.DotNetBar.ButtonX();
            this.buttonX9 = new DevComponents.DotNetBar.ButtonX();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.labelX16 = new DevComponents.DotNetBar.LabelX();
            this.comboBoxEx1 = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.labelX24 = new DevComponents.DotNetBar.LabelX();
            this.textBoxX5 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX33 = new DevComponents.DotNetBar.LabelX();
            this.comboBoxEx4 = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.comboItem3 = new DevComponents.Editors.ComboItem();
            this.comboItem4 = new DevComponents.Editors.ComboItem();
            this.comboItem5 = new DevComponents.Editors.ComboItem();
            this.comboItem6 = new DevComponents.Editors.ComboItem();
            this.comboItem7 = new DevComponents.Editors.ComboItem();
            this.buttonX11 = new DevComponents.DotNetBar.ButtonX();
            this.superTabItem4 = new DevComponents.DotNetBar.SuperTabItem();
            this.groupPanel2 = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.pwtDataGridView1 = new Pawote.UI.Controls.PwtDataGridView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.上传一致表单ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.superTabItem1 = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel2 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.textBoxX22 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX18 = new DevComponents.DotNetBar.LabelX();
            this.buttonX4 = new DevComponents.DotNetBar.ButtonX();
            this.textBoxX14 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.buttonX3 = new DevComponents.DotNetBar.ButtonX();
            this.textBoxX15 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.buttonX2 = new DevComponents.DotNetBar.ButtonX();
            this.labelX11 = new DevComponents.DotNetBar.LabelX();
            this.labelX6 = new DevComponents.DotNetBar.LabelX();
            this.labelX12 = new DevComponents.DotNetBar.LabelX();
            this.labelX7 = new DevComponents.DotNetBar.LabelX();
            this.labelX10 = new DevComponents.DotNetBar.LabelX();
            this.labelX8 = new DevComponents.DotNetBar.LabelX();
            this.textBoxX13 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX3 = new DevComponents.DotNetBar.LabelX();
            this.textBoxX11 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX4 = new DevComponents.DotNetBar.LabelX();
            this.labelX5 = new DevComponents.DotNetBar.LabelX();
            this.labelX9 = new DevComponents.DotNetBar.LabelX();
            this.textBoxX12 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX32 = new DevComponents.DotNetBar.LabelX();
            this.labelX21 = new DevComponents.DotNetBar.LabelX();
            this.textBoxX18 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX27 = new DevComponents.DotNetBar.LabelX();
            this.textBoxX10 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.pwtSearchBox1 = new Pawote.UI.Controls.PwtSearchBox();
            this.superTabItem2 = new DevComponents.DotNetBar.SuperTabItem();
            this.buttonX1 = new DevComponents.DotNetBar.ButtonX();
            this.balloonTip1 = new DevComponents.DotNetBar.BalloonTip();
            this.superTabControlPanel10 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.superTabControl6 = new DevComponents.DotNetBar.SuperTabControl();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonX17 = new DevComponents.DotNetBar.ButtonX();
            this.buttonX18 = new DevComponents.DotNetBar.ButtonX();
            this.buttonX19 = new DevComponents.DotNetBar.ButtonX();
            this.superTabItem10 = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel13 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.buttonX20 = new DevComponents.DotNetBar.ButtonX();
            this.labelX35 = new DevComponents.DotNetBar.LabelX();
            this.buttonX21 = new DevComponents.DotNetBar.ButtonX();
            this.buttonX22 = new DevComponents.DotNetBar.ButtonX();
            this.pwtDataGridView9 = new Pawote.UI.Controls.PwtDataGridView();
            this.buttonX23 = new DevComponents.DotNetBar.ButtonX();
            this.labelX36 = new DevComponents.DotNetBar.LabelX();
            this.comboBoxEx5 = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.labelX37 = new DevComponents.DotNetBar.LabelX();
            this.textBoxX20 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX38 = new DevComponents.DotNetBar.LabelX();
            this.comboBoxEx6 = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.comboItem8 = new DevComponents.Editors.ComboItem();
            this.comboItem9 = new DevComponents.Editors.ComboItem();
            this.comboItem10 = new DevComponents.Editors.ComboItem();
            this.comboItem11 = new DevComponents.Editors.ComboItem();
            this.comboItem12 = new DevComponents.Editors.ComboItem();
            this.superTabControlPanel14 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.pwtDataGridView10 = new Pawote.UI.Controls.PwtDataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.superTabControlPanel15 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.labelX39 = new DevComponents.DotNetBar.LabelX();
            this.buttonX24 = new DevComponents.DotNetBar.ButtonX();
            this.buttonX25 = new DevComponents.DotNetBar.ButtonX();
            this.buttonX26 = new DevComponents.DotNetBar.ButtonX();
            this.pwtDataGridView11 = new Pawote.UI.Controls.PwtDataGridView();
            this.labelX40 = new DevComponents.DotNetBar.LabelX();
            this.comboBoxEx7 = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.labelX41 = new DevComponents.DotNetBar.LabelX();
            this.textBoxX21 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.panelEx1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.superTabControl1)).BeginInit();
            this.superTabControl1.SuspendLayout();
            this.superTabControlPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.superTabControl2)).BeginInit();
            this.superTabControl2.SuspendLayout();
            this.superTabControlPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.superTabControl3)).BeginInit();
            this.superTabControl3.SuspendLayout();
            this.superTabControlPanel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pwtDataGridView2)).BeginInit();
            this.superTabControlPanel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pwtDataGridView5)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            this.superTabControlPanel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pwtDataGridView6)).BeginInit();
            this.superTabControlPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pwtDataGridView4)).BeginInit();
            this.tableLayoutPanel4.SuspendLayout();
            this.superTabControlPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pwtDataGridView3)).BeginInit();
            this.tableLayoutPanel3.SuspendLayout();
            this.groupPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pwtDataGridView1)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.superTabControlPanel2.SuspendLayout();
            this.superTabControlPanel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.superTabControl6)).BeginInit();
            this.tableLayoutPanel5.SuspendLayout();
            this.superTabControlPanel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pwtDataGridView9)).BeginInit();
            this.superTabControlPanel14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pwtDataGridView10)).BeginInit();
            this.superTabControlPanel15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pwtDataGridView11)).BeginInit();
            this.SuspendLayout();
            // 
            // panelEx1
            // 
            this.panelEx1.CanvasColor = System.Drawing.SystemColors.Control;
            this.panelEx1.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.panelEx1.Controls.Add(this.pwtRadioButton3);
            this.panelEx1.Controls.Add(this.pwtRadioButton2);
            this.panelEx1.Controls.Add(this.pwtRadioButton1);
            this.panelEx1.Controls.Add(this.buttonX16);
            this.panelEx1.Controls.Add(this.buttonX15);
            this.panelEx1.Controls.Add(this.buttonX5);
            this.panelEx1.Controls.Add(this.tableLayoutPanel1);
            this.panelEx1.Controls.Add(this.superTabControl1);
            this.panelEx1.Controls.Add(this.buttonX1);
            this.panelEx1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelEx1.Location = new System.Drawing.Point(0, 0);
            this.panelEx1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panelEx1.Name = "panelEx1";
            this.panelEx1.Size = new System.Drawing.Size(2017, 1206);
            this.panelEx1.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.panelEx1.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.panelEx1.Style.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.panelEx1.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.panelEx1.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.panelEx1.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.panelEx1.Style.GradientAngle = 90;
            this.panelEx1.TabIndex = 0;
            // 
            // pwtRadioButton3
            // 
            this.pwtRadioButton3.AutoSize = true;
            this.pwtRadioButton3.BackColor = System.Drawing.Color.Transparent;
            this.pwtRadioButton3.Checked = true;
            checkImageTable1.CheckedImage = ((System.Drawing.Image)(resources.GetObject("checkImageTable1.CheckedImage")));
            checkImageTable1.CheckedImageDisabled = ((System.Drawing.Image)(resources.GetObject("checkImageTable1.CheckedImageDisabled")));
            checkImageTable1.IndeterminateImage = null;
            checkImageTable1.IndeterminateImageDisabled = null;
            checkImageTable1.UnCheckedImage = ((System.Drawing.Image)(resources.GetObject("checkImageTable1.UnCheckedImage")));
            checkImageTable1.UnCheckedImageDisabled = ((System.Drawing.Image)(resources.GetObject("checkImageTable1.UnCheckedImageDisabled")));
            this.pwtRadioButton3.CheckImageTable = checkImageTable1;
            this.pwtRadioButton3.Location = new System.Drawing.Point(760, 24);
            this.pwtRadioButton3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pwtRadioButton3.Name = "pwtRadioButton3";
            this.pwtRadioButton3.Size = new System.Drawing.Size(87, 22);
            this.pwtRadioButton3.TabIndex = 17;
            this.pwtRadioButton3.TabStop = true;
            this.pwtRadioButton3.Text = "待审核";
            this.pwtRadioButton3.UseVisualStyleBackColor = false;
            // 
            // pwtRadioButton2
            // 
            this.pwtRadioButton2.AutoSize = true;
            this.pwtRadioButton2.BackColor = System.Drawing.Color.Transparent;
            checkImageTable2.CheckedImage = ((System.Drawing.Image)(resources.GetObject("checkImageTable2.CheckedImage")));
            checkImageTable2.CheckedImageDisabled = ((System.Drawing.Image)(resources.GetObject("checkImageTable2.CheckedImageDisabled")));
            checkImageTable2.IndeterminateImage = null;
            checkImageTable2.IndeterminateImageDisabled = null;
            checkImageTable2.UnCheckedImage = ((System.Drawing.Image)(resources.GetObject("checkImageTable2.UnCheckedImage")));
            checkImageTable2.UnCheckedImageDisabled = ((System.Drawing.Image)(resources.GetObject("checkImageTable2.UnCheckedImageDisabled")));
            this.pwtRadioButton2.CheckImageTable = checkImageTable2;
            this.pwtRadioButton2.Location = new System.Drawing.Point(663, 24);
            this.pwtRadioButton2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pwtRadioButton2.Name = "pwtRadioButton2";
            this.pwtRadioButton2.Size = new System.Drawing.Size(87, 22);
            this.pwtRadioButton2.TabIndex = 16;
            this.pwtRadioButton2.Text = "已审核";
            this.pwtRadioButton2.UseVisualStyleBackColor = false;
            // 
            // pwtRadioButton1
            // 
            this.pwtRadioButton1.AutoSize = true;
            this.pwtRadioButton1.BackColor = System.Drawing.Color.Transparent;
            checkImageTable3.CheckedImage = ((System.Drawing.Image)(resources.GetObject("checkImageTable3.CheckedImage")));
            checkImageTable3.CheckedImageDisabled = ((System.Drawing.Image)(resources.GetObject("checkImageTable3.CheckedImageDisabled")));
            checkImageTable3.IndeterminateImage = null;
            checkImageTable3.IndeterminateImageDisabled = null;
            checkImageTable3.UnCheckedImage = ((System.Drawing.Image)(resources.GetObject("checkImageTable3.UnCheckedImage")));
            checkImageTable3.UnCheckedImageDisabled = ((System.Drawing.Image)(resources.GetObject("checkImageTable3.UnCheckedImageDisabled")));
            this.pwtRadioButton1.CheckImageTable = checkImageTable3;
            this.pwtRadioButton1.Location = new System.Drawing.Point(584, 24);
            this.pwtRadioButton1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pwtRadioButton1.Name = "pwtRadioButton1";
            this.pwtRadioButton1.Size = new System.Drawing.Size(69, 22);
            this.pwtRadioButton1.TabIndex = 15;
            this.pwtRadioButton1.Text = "全部";
            this.pwtRadioButton1.UseVisualStyleBackColor = false;
            // 
            // buttonX16
            // 
            this.buttonX16.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX16.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX16.Location = new System.Drawing.Point(296, 12);
            this.buttonX16.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonX16.Name = "buttonX16";
            this.buttonX16.Size = new System.Drawing.Size(135, 46);
            this.buttonX16.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX16.TabIndex = 14;
            this.buttonX16.Text = "退审";
            this.buttonX16.Click += new System.EventHandler(this.buttonX16_Click);
            // 
            // buttonX15
            // 
            this.buttonX15.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX15.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX15.Location = new System.Drawing.Point(154, 12);
            this.buttonX15.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonX15.Name = "buttonX15";
            this.buttonX15.Size = new System.Drawing.Size(135, 46);
            this.buttonX15.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX15.TabIndex = 13;
            this.buttonX15.Text = "审核";
            this.buttonX15.Click += new System.EventHandler(this.buttonX15_Click);
            // 
            // buttonX5
            // 
            this.buttonX5.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX5.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX5.Location = new System.Drawing.Point(436, 12);
            this.buttonX5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonX5.Name = "buttonX5";
            this.buttonX5.Size = new System.Drawing.Size(135, 46);
            this.buttonX5.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX5.TabIndex = 4;
            this.buttonX5.Text = "清空";
            this.buttonX5.Click += new System.EventHandler(this.buttonX5_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 6;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 135F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 135F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 135F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33332F));
            this.tableLayoutPanel1.Controls.Add(this.textBoxX4, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.labelX19, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.labelX13, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX6, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.labelX1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX1, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelX29, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.pwtSearchBox3, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelX30, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.pwtSearchBox4, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelX14, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.pwtSearchBox2, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.labelX17, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX3, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.labelX2, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX2, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this.labelX23, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX9, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.labelX20, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX8, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.labelX15, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX7, 5, 2);
            this.tableLayoutPanel1.Controls.Add(this.labelX31, 4, 3);
            this.tableLayoutPanel1.Controls.Add(this.comboBoxEx3, 5, 3);
            this.tableLayoutPanel1.Controls.Add(this.labelX28, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX19, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.labelX22, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX16, 1, 5);
            this.tableLayoutPanel1.Font = new System.Drawing.Font("宋体", 11F);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(14, 62);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 6;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1868, 339);
            this.tableLayoutPanel1.TabIndex = 11;
            // 
            // textBoxX4
            // 
            // 
            // 
            // 
            this.textBoxX4.Border.Class = "TextBoxBorder";
            this.textBoxX4.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX4.Location = new System.Drawing.Point(760, 170);
            this.textBoxX4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxX4.Name = "textBoxX4";
            this.textBoxX4.Size = new System.Drawing.Size(481, 46);
            this.textBoxX4.TabIndex = 9;
            this.textBoxX4.Text = "24000";
            this.textBoxX4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxX4_KeyPress);
            // 
            // labelX19
            // 
            // 
            // 
            // 
            this.labelX19.BackgroundStyle.Class = "";
            this.labelX19.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX19.Location = new System.Drawing.Point(3, 170);
            this.labelX19.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.labelX19.Name = "labelX19";
            this.labelX19.Size = new System.Drawing.Size(129, 52);
            this.labelX19.TabIndex = 0;
            this.labelX19.Text = "针卡名称";
            // 
            // labelX13
            // 
            // 
            // 
            // 
            this.labelX13.BackgroundStyle.Class = "";
            this.labelX13.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX13.Location = new System.Drawing.Point(625, 170);
            this.labelX13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.labelX13.Name = "labelX13";
            this.labelX13.Size = new System.Drawing.Size(129, 52);
            this.labelX13.TabIndex = 0;
            this.labelX13.Text = "单片总数";
            // 
            // textBoxX6
            // 
            // 
            // 
            // 
            this.textBoxX6.Border.Class = "TextBoxBorder";
            this.textBoxX6.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX6.Location = new System.Drawing.Point(138, 170);
            this.textBoxX6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxX6.Name = "textBoxX6";
            this.textBoxX6.Size = new System.Drawing.Size(481, 46);
            this.textBoxX6.TabIndex = 17;
            // 
            // labelX1
            // 
            // 
            // 
            // 
            this.labelX1.BackgroundStyle.Class = "";
            this.labelX1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX1.Location = new System.Drawing.Point(3, 2);
            this.labelX1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.labelX1.Name = "labelX1";
            this.labelX1.Size = new System.Drawing.Size(129, 52);
            this.labelX1.TabIndex = 0;
            this.labelX1.Text = "晶圆型号";
            // 
            // textBoxX1
            // 
            // 
            // 
            // 
            this.textBoxX1.Border.Class = "TextBoxBorder";
            this.textBoxX1.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX1.Location = new System.Drawing.Point(138, 2);
            this.textBoxX1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxX1.Name = "textBoxX1";
            this.textBoxX1.Size = new System.Drawing.Size(481, 46);
            this.textBoxX1.TabIndex = 5;
            // 
            // labelX29
            // 
            // 
            // 
            // 
            this.labelX29.BackgroundStyle.Class = "";
            this.labelX29.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX29.Location = new System.Drawing.Point(626, 5);
            this.labelX29.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.labelX29.Name = "labelX29";
            this.labelX29.Size = new System.Drawing.Size(127, 46);
            this.labelX29.TabIndex = 30;
            this.labelX29.Text = "客户名称";
            // 
            // pwtSearchBox3
            // 
            this.pwtSearchBox3.BackColor = System.Drawing.Color.White;
            this.pwtSearchBox3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(128)))), ((int)(((byte)(160)))));
            this.pwtSearchBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pwtSearchBox3.EmptyText = null;
            this.pwtSearchBox3.ImageHover = ((System.Drawing.Image)(resources.GetObject("pwtSearchBox3.ImageHover")));
            this.pwtSearchBox3.ImageNormal = ((System.Drawing.Image)(resources.GetObject("pwtSearchBox3.ImageNormal")));
            this.pwtSearchBox3.InputChangeTriggerTime = 600;
            this.pwtSearchBox3.IsSpaceKeyCodeValid = false;
            this.pwtSearchBox3.Location = new System.Drawing.Point(761, 5);
            this.pwtSearchBox3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pwtSearchBox3.Name = "pwtSearchBox3";
            this.pwtSearchBox3.SearchBtnHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(214)))), ((int)(((byte)(125)))));
            this.pwtSearchBox3.Size = new System.Drawing.Size(479, 46);
            this.pwtSearchBox3.TabIndex = 36;
            this.pwtSearchBox3.SearchBtnClick += new System.EventHandler(this.pwtSearchBox3_SearchBtnClick);
            // 
            // labelX30
            // 
            // 
            // 
            // 
            this.labelX30.BackgroundStyle.Class = "";
            this.labelX30.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX30.Location = new System.Drawing.Point(1248, 5);
            this.labelX30.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.labelX30.Name = "labelX30";
            this.labelX30.Size = new System.Drawing.Size(127, 46);
            this.labelX30.TabIndex = 31;
            this.labelX30.Text = "客户代码";
            // 
            // pwtSearchBox4
            // 
            this.pwtSearchBox4.BackColor = System.Drawing.Color.White;
            this.pwtSearchBox4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(128)))), ((int)(((byte)(160)))));
            this.pwtSearchBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pwtSearchBox4.EmptyText = null;
            this.pwtSearchBox4.ImageHover = ((System.Drawing.Image)(resources.GetObject("pwtSearchBox4.ImageHover")));
            this.pwtSearchBox4.ImageNormal = ((System.Drawing.Image)(resources.GetObject("pwtSearchBox4.ImageNormal")));
            this.pwtSearchBox4.InputChangeTriggerTime = 600;
            this.pwtSearchBox4.IsSpaceKeyCodeValid = false;
            this.pwtSearchBox4.Location = new System.Drawing.Point(1383, 5);
            this.pwtSearchBox4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pwtSearchBox4.Name = "pwtSearchBox4";
            this.pwtSearchBox4.SearchBtnHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(214)))), ((int)(((byte)(125)))));
            this.pwtSearchBox4.Size = new System.Drawing.Size(481, 46);
            this.pwtSearchBox4.TabIndex = 37;
            this.pwtSearchBox4.SearchBtnClick += new System.EventHandler(this.pwtSearchBox3_SearchBtnClick);
            // 
            // labelX14
            // 
            // 
            // 
            // 
            this.labelX14.BackgroundStyle.Class = "";
            this.labelX14.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX14.Location = new System.Drawing.Point(3, 58);
            this.labelX14.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.labelX14.Name = "labelX14";
            this.labelX14.Size = new System.Drawing.Size(129, 52);
            this.labelX14.TabIndex = 0;
            this.labelX14.Text = "电压版本";
            // 
            // pwtSearchBox2
            // 
            this.pwtSearchBox2.BackColor = System.Drawing.Color.White;
            this.pwtSearchBox2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(128)))), ((int)(((byte)(160)))));
            this.pwtSearchBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pwtSearchBox2.EmptyText = null;
            this.pwtSearchBox2.ImageHover = ((System.Drawing.Image)(resources.GetObject("pwtSearchBox2.ImageHover")));
            this.pwtSearchBox2.ImageNormal = ((System.Drawing.Image)(resources.GetObject("pwtSearchBox2.ImageNormal")));
            this.pwtSearchBox2.InputChangeTriggerTime = 600;
            this.pwtSearchBox2.IsSpaceKeyCodeValid = false;
            this.pwtSearchBox2.Location = new System.Drawing.Point(138, 58);
            this.pwtSearchBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pwtSearchBox2.Name = "pwtSearchBox2";
            this.pwtSearchBox2.SearchBtnHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(214)))), ((int)(((byte)(125)))));
            this.pwtSearchBox2.Size = new System.Drawing.Size(481, 52);
            this.pwtSearchBox2.TabIndex = 15;
            this.pwtSearchBox2.SearchBtnClick += new System.EventHandler(this.pwtSearchBox2_SearchBtnClick);
            // 
            // labelX17
            // 
            // 
            // 
            // 
            this.labelX17.BackgroundStyle.Class = "";
            this.labelX17.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX17.Location = new System.Drawing.Point(625, 58);
            this.labelX17.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.labelX17.Name = "labelX17";
            this.labelX17.Size = new System.Drawing.Size(129, 52);
            this.labelX17.TabIndex = 0;
            this.labelX17.Text = "规格描述";
            // 
            // textBoxX3
            // 
            // 
            // 
            // 
            this.textBoxX3.Border.Class = "TextBoxBorder";
            this.textBoxX3.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX3.Location = new System.Drawing.Point(760, 58);
            this.textBoxX3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxX3.Name = "textBoxX3";
            this.textBoxX3.Size = new System.Drawing.Size(481, 46);
            this.textBoxX3.TabIndex = 8;
            // 
            // labelX2
            // 
            // 
            // 
            // 
            this.labelX2.BackgroundStyle.Class = "";
            this.labelX2.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX2.Location = new System.Drawing.Point(1247, 58);
            this.labelX2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.labelX2.Name = "labelX2";
            this.labelX2.Size = new System.Drawing.Size(129, 52);
            this.labelX2.TabIndex = 0;
            this.labelX2.Text = "物料尺寸";
            // 
            // textBoxX2
            // 
            // 
            // 
            // 
            this.textBoxX2.Border.Class = "TextBoxBorder";
            this.textBoxX2.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX2.Location = new System.Drawing.Point(1382, 58);
            this.textBoxX2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxX2.Name = "textBoxX2";
            this.textBoxX2.Size = new System.Drawing.Size(483, 46);
            this.textBoxX2.TabIndex = 6;
            // 
            // labelX23
            // 
            // 
            // 
            // 
            this.labelX23.BackgroundStyle.Class = "";
            this.labelX23.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX23.Location = new System.Drawing.Point(3, 114);
            this.labelX23.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.labelX23.Name = "labelX23";
            this.labelX23.Size = new System.Drawing.Size(129, 52);
            this.labelX23.TabIndex = 25;
            this.labelX23.Text = "测试机型";
            // 
            // textBoxX9
            // 
            // 
            // 
            // 
            this.textBoxX9.Border.Class = "TextBoxBorder";
            this.textBoxX9.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX9.Location = new System.Drawing.Point(138, 114);
            this.textBoxX9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxX9.Name = "textBoxX9";
            this.textBoxX9.Size = new System.Drawing.Size(481, 46);
            this.textBoxX9.TabIndex = 21;
            // 
            // labelX20
            // 
            // 
            // 
            // 
            this.labelX20.BackgroundStyle.Class = "";
            this.labelX20.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX20.Location = new System.Drawing.Point(625, 114);
            this.labelX20.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.labelX20.Name = "labelX20";
            this.labelX20.Size = new System.Drawing.Size(129, 52);
            this.labelX20.TabIndex = 0;
            this.labelX20.Text = "测试版";
            // 
            // textBoxX8
            // 
            // 
            // 
            // 
            this.textBoxX8.Border.Class = "TextBoxBorder";
            this.textBoxX8.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX8.Location = new System.Drawing.Point(760, 114);
            this.textBoxX8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxX8.Name = "textBoxX8";
            this.textBoxX8.Size = new System.Drawing.Size(481, 46);
            this.textBoxX8.TabIndex = 20;
            // 
            // labelX15
            // 
            // 
            // 
            // 
            this.labelX15.BackgroundStyle.Class = "";
            this.labelX15.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX15.Location = new System.Drawing.Point(1247, 114);
            this.labelX15.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.labelX15.Name = "labelX15";
            this.labelX15.Size = new System.Drawing.Size(129, 52);
            this.labelX15.TabIndex = 0;
            this.labelX15.Text = "中测台程序";
            // 
            // textBoxX7
            // 
            // 
            // 
            // 
            this.textBoxX7.Border.Class = "TextBoxBorder";
            this.textBoxX7.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX7.Location = new System.Drawing.Point(1382, 114);
            this.textBoxX7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxX7.Name = "textBoxX7";
            this.textBoxX7.Size = new System.Drawing.Size(483, 46);
            this.textBoxX7.TabIndex = 18;
            // 
            // labelX31
            // 
            // 
            // 
            // 
            this.labelX31.BackgroundStyle.Class = "";
            this.labelX31.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX31.Location = new System.Drawing.Point(1247, 170);
            this.labelX31.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.labelX31.Name = "labelX31";
            this.labelX31.Size = new System.Drawing.Size(129, 52);
            this.labelX31.TabIndex = 0;
            this.labelX31.Text = "是否打点";
            // 
            // comboBoxEx3
            // 
            this.comboBoxEx3.DisplayMember = "Text";
            this.comboBoxEx3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxEx3.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.comboBoxEx3.FormattingEnabled = true;
            this.comboBoxEx3.ItemHeight = 27;
            this.comboBoxEx3.Items.AddRange(new object[] {
            this.comboItem1,
            this.comboItem2});
            this.comboBoxEx3.Location = new System.Drawing.Point(1383, 173);
            this.comboBoxEx3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comboBoxEx3.Name = "comboBoxEx3";
            this.comboBoxEx3.Size = new System.Drawing.Size(481, 33);
            this.comboBoxEx3.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.comboBoxEx3.TabIndex = 34;
            // 
            // comboItem1
            // 
            this.comboItem1.Text = "进行打点";
            // 
            // comboItem2
            // 
            this.comboItem2.Text = "不进行打点";
            // 
            // labelX28
            // 
            // 
            // 
            // 
            this.labelX28.BackgroundStyle.Class = "";
            this.labelX28.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX28.Location = new System.Drawing.Point(3, 226);
            this.labelX28.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.labelX28.Name = "labelX28";
            this.labelX28.Size = new System.Drawing.Size(129, 52);
            this.labelX28.TabIndex = 27;
            this.labelX28.Text = "工艺事项";
            // 
            // textBoxX19
            // 
            // 
            // 
            // 
            this.textBoxX19.Border.Class = "TextBoxBorder";
            this.textBoxX19.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.tableLayoutPanel1.SetColumnSpan(this.textBoxX19, 3);
            this.textBoxX19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX19.Location = new System.Drawing.Point(138, 226);
            this.textBoxX19.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxX19.Name = "textBoxX19";
            this.textBoxX19.Size = new System.Drawing.Size(1103, 46);
            this.textBoxX19.TabIndex = 29;
            // 
            // labelX22
            // 
            // 
            // 
            // 
            this.labelX22.BackgroundStyle.Class = "";
            this.labelX22.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX22.Location = new System.Drawing.Point(3, 282);
            this.labelX22.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.labelX22.Name = "labelX22";
            this.labelX22.Size = new System.Drawing.Size(129, 55);
            this.labelX22.TabIndex = 0;
            this.labelX22.Text = "备注";
            // 
            // textBoxX16
            // 
            // 
            // 
            // 
            this.textBoxX16.Border.Class = "TextBoxBorder";
            this.textBoxX16.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.tableLayoutPanel1.SetColumnSpan(this.textBoxX16, 5);
            this.textBoxX16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX16.Location = new System.Drawing.Point(138, 282);
            this.textBoxX16.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxX16.Name = "textBoxX16";
            this.textBoxX16.Size = new System.Drawing.Size(1727, 46);
            this.textBoxX16.TabIndex = 24;
            // 
            // superTabControl1
            // 
            this.superTabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            // 
            // 
            // 
            // 
            // 
            // 
            this.superTabControl1.ControlBox.CloseBox.Name = "";
            // 
            // 
            // 
            this.superTabControl1.ControlBox.MenuBox.Name = "";
            this.superTabControl1.ControlBox.Name = "";
            this.superTabControl1.ControlBox.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabControl1.ControlBox.MenuBox,
            this.superTabControl1.ControlBox.CloseBox});
            this.superTabControl1.Controls.Add(this.superTabControlPanel1);
            this.superTabControl1.Controls.Add(this.superTabControlPanel2);
            this.superTabControl1.Location = new System.Drawing.Point(12, 415);
            this.superTabControl1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.superTabControl1.Name = "superTabControl1";
            this.superTabControl1.ReorderTabsEnabled = true;
            this.superTabControl1.SelectedTabFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold);
            this.superTabControl1.SelectedTabIndex = 0;
            this.superTabControl1.Size = new System.Drawing.Size(1993, 780);
            this.superTabControl1.TabFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.superTabControl1.TabIndex = 10;
            this.superTabControl1.Tabs.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem1,
            this.superTabItem2});
            this.superTabControl1.Text = "superTabControl1";
            // 
            // superTabControlPanel1
            // 
            this.superTabControlPanel1.Controls.Add(this.superTabControl2);
            this.superTabControlPanel1.Controls.Add(this.groupPanel2);
            this.superTabControlPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel1.Location = new System.Drawing.Point(0, 35);
            this.superTabControlPanel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.superTabControlPanel1.Name = "superTabControlPanel1";
            this.superTabControlPanel1.Size = new System.Drawing.Size(1993, 745);
            this.superTabControlPanel1.TabIndex = 1;
            this.superTabControlPanel1.TabItem = this.superTabItem1;
            // 
            // superTabControl2
            // 
            this.superTabControl2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            // 
            // 
            // 
            // 
            // 
            // 
            this.superTabControl2.ControlBox.CloseBox.Name = "";
            // 
            // 
            // 
            this.superTabControl2.ControlBox.MenuBox.Name = "";
            this.superTabControl2.ControlBox.Name = "";
            this.superTabControl2.ControlBox.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabControl2.ControlBox.MenuBox,
            this.superTabControl2.ControlBox.CloseBox});
            this.superTabControl2.Controls.Add(this.superTabControlPanel3);
            this.superTabControl2.Controls.Add(this.superTabControlPanel5);
            this.superTabControl2.Controls.Add(this.superTabControlPanel4);
            this.superTabControl2.Controls.Add(this.superTabControlPanel8);
            this.superTabControl2.Location = new System.Drawing.Point(943, 2);
            this.superTabControl2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.superTabControl2.Name = "superTabControl2";
            this.superTabControl2.ReorderTabsEnabled = true;
            this.superTabControl2.SelectedTabFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold);
            this.superTabControl2.SelectedTabIndex = 0;
            this.superTabControl2.Size = new System.Drawing.Size(1047, 743);
            this.superTabControl2.TabFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.superTabControl2.TabIndex = 12;
            this.superTabControl2.Tabs.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem3,
            this.superTabItem8,
            this.superTabItem4,
            this.superTabItem5});
            this.superTabControl2.Text = "superTabControl2";
            // 
            // superTabControlPanel3
            // 
            this.superTabControlPanel3.Controls.Add(this.superTabControl3);
            this.superTabControlPanel3.Controls.Add(this.tableLayoutPanel2);
            this.superTabControlPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel3.Location = new System.Drawing.Point(0, 35);
            this.superTabControlPanel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.superTabControlPanel3.Name = "superTabControlPanel3";
            this.superTabControlPanel3.Size = new System.Drawing.Size(1047, 708);
            this.superTabControlPanel3.TabIndex = 1;
            this.superTabControlPanel3.TabItem = this.superTabItem3;
            // 
            // superTabControl3
            // 
            // 
            // 
            // 
            // 
            // 
            // 
            this.superTabControl3.ControlBox.CloseBox.Name = "";
            // 
            // 
            // 
            this.superTabControl3.ControlBox.MenuBox.Name = "";
            this.superTabControl3.ControlBox.Name = "";
            this.superTabControl3.ControlBox.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabControl3.ControlBox.MenuBox,
            this.superTabControl3.ControlBox.CloseBox});
            this.superTabControl3.Controls.Add(this.superTabControlPanel6);
            this.superTabControl3.Controls.Add(this.superTabControlPanel7);
            this.superTabControl3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControl3.Location = new System.Drawing.Point(0, 0);
            this.superTabControl3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.superTabControl3.Name = "superTabControl3";
            this.superTabControl3.ReorderTabsEnabled = true;
            this.superTabControl3.SelectedTabFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold);
            this.superTabControl3.SelectedTabIndex = 0;
            this.superTabControl3.Size = new System.Drawing.Size(1047, 708);
            this.superTabControl3.TabFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.superTabControl3.TabIndex = 24;
            this.superTabControl3.Tabs.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem6,
            this.superTabItem7});
            this.superTabControl3.Text = "superTabControl3";
            // 
            // superTabControlPanel6
            // 
            this.superTabControlPanel6.Controls.Add(this.pwtDataGridView2);
            this.superTabControlPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel6.Location = new System.Drawing.Point(0, 35);
            this.superTabControlPanel6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.superTabControlPanel6.Name = "superTabControlPanel6";
            this.superTabControlPanel6.Size = new System.Drawing.Size(1047, 673);
            this.superTabControlPanel6.TabIndex = 1;
            this.superTabControlPanel6.TabItem = this.superTabItem6;
            // 
            // pwtDataGridView2
            // 
            this.pwtDataGridView2.AllowUserToAddRows = false;
            this.pwtDataGridView2.AllowUserToDeleteRows = false;
            this.pwtDataGridView2.AllowUserToOrderColumns = true;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(229)))), ((int)(((byte)(248)))));
            this.pwtDataGridView2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.pwtDataGridView2.BackgroundColor = System.Drawing.SystemColors.Window;
            this.pwtDataGridView2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(246)))), ((int)(((byte)(239)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.pwtDataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.pwtDataGridView2.ColumnHeadersHeight = 26;
            this.pwtDataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.Wheat;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.DarkSlateBlue;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.pwtDataGridView2.DefaultCellStyle = dataGridViewCellStyle3;
            this.pwtDataGridView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pwtDataGridView2.EnableHeadersVisualStyles = false;
            this.pwtDataGridView2.GridColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pwtDataGridView2.Location = new System.Drawing.Point(0, 0);
            this.pwtDataGridView2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pwtDataGridView2.MergeColumnHeaderBackColor = System.Drawing.SystemColors.Control;
            this.pwtDataGridView2.MergeColumnNames = ((System.Collections.Generic.List<string>)(resources.GetObject("pwtDataGridView2.MergeColumnNames")));
            this.pwtDataGridView2.Name = "pwtDataGridView2";
            this.pwtDataGridView2.ReadOnly = true;
            this.pwtDataGridView2.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.pwtDataGridView2.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.pwtDataGridView2.RowHeadersWidth = 51;
            this.pwtDataGridView2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.pwtDataGridView2.RowTemplate.Height = 27;
            this.pwtDataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.pwtDataGridView2.Size = new System.Drawing.Size(1047, 673);
            this.pwtDataGridView2.TabIndex = 0;
            this.pwtDataGridView2.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.pwtDataGridView2_MouseDoubleClick);
            // 
            // superTabItem6
            // 
            this.superTabItem6.AttachedControl = this.superTabControlPanel6;
            this.superTabItem6.GlobalItem = false;
            this.superTabItem6.Name = "superTabItem6";
            this.superTabItem6.Text = "信息";
            // 
            // superTabControlPanel7
            // 
            this.superTabControlPanel7.Controls.Add(this.pwtDataGridView5);
            this.superTabControlPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel7.Location = new System.Drawing.Point(0, 35);
            this.superTabControlPanel7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.superTabControlPanel7.Name = "superTabControlPanel7";
            this.superTabControlPanel7.Size = new System.Drawing.Size(803, 654);
            this.superTabControlPanel7.TabIndex = 0;
            this.superTabControlPanel7.TabItem = this.superTabItem7;
            // 
            // pwtDataGridView5
            // 
            this.pwtDataGridView5.AllowUserToAddRows = false;
            this.pwtDataGridView5.AllowUserToDeleteRows = false;
            this.pwtDataGridView5.AllowUserToOrderColumns = true;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(229)))), ((int)(((byte)(248)))));
            this.pwtDataGridView5.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            this.pwtDataGridView5.BackgroundColor = System.Drawing.SystemColors.Window;
            this.pwtDataGridView5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(246)))), ((int)(((byte)(239)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.pwtDataGridView5.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.pwtDataGridView5.ColumnHeadersHeight = 26;
            this.pwtDataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.Wheat;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.DarkSlateBlue;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.pwtDataGridView5.DefaultCellStyle = dataGridViewCellStyle7;
            this.pwtDataGridView5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pwtDataGridView5.EnableHeadersVisualStyles = false;
            this.pwtDataGridView5.GridColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pwtDataGridView5.Location = new System.Drawing.Point(0, 0);
            this.pwtDataGridView5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pwtDataGridView5.MergeColumnHeaderBackColor = System.Drawing.SystemColors.Control;
            this.pwtDataGridView5.MergeColumnNames = ((System.Collections.Generic.List<string>)(resources.GetObject("pwtDataGridView5.MergeColumnNames")));
            this.pwtDataGridView5.Name = "pwtDataGridView5";
            this.pwtDataGridView5.ReadOnly = true;
            this.pwtDataGridView5.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.pwtDataGridView5.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.pwtDataGridView5.RowHeadersWidth = 51;
            this.pwtDataGridView5.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.pwtDataGridView5.RowTemplate.Height = 27;
            this.pwtDataGridView5.Size = new System.Drawing.Size(803, 654);
            this.pwtDataGridView5.TabIndex = 0;
            // 
            // superTabItem7
            // 
            this.superTabItem7.AttachedControl = this.superTabControlPanel7;
            this.superTabItem7.GlobalItem = false;
            this.superTabItem7.Name = "superTabItem7";
            this.superTabItem7.Text = "操作记录";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.Controls.Add(this.buttonX6, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.buttonX8, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.buttonX7, 1, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(91, 2);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(522, 65);
            this.tableLayoutPanel2.TabIndex = 23;
            this.tableLayoutPanel2.Visible = false;
            // 
            // buttonX6
            // 
            this.buttonX6.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX6.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonX6.Location = new System.Drawing.Point(3, 2);
            this.buttonX6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonX6.Name = "buttonX6";
            this.buttonX6.Size = new System.Drawing.Size(168, 61);
            this.buttonX6.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX6.TabIndex = 16;
            this.buttonX6.Text = "组选择";
            this.buttonX6.Click += new System.EventHandler(this.buttonX6_Click);
            // 
            // buttonX8
            // 
            this.buttonX8.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX8.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonX8.Location = new System.Drawing.Point(351, 2);
            this.buttonX8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonX8.Name = "buttonX8";
            this.buttonX8.Size = new System.Drawing.Size(168, 61);
            this.buttonX8.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX8.TabIndex = 18;
            this.buttonX8.Text = "工序删除";
            this.buttonX8.Click += new System.EventHandler(this.buttonX8_Click);
            // 
            // buttonX7
            // 
            this.buttonX7.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX7.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonX7.Location = new System.Drawing.Point(177, 2);
            this.buttonX7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonX7.Name = "buttonX7";
            this.buttonX7.Size = new System.Drawing.Size(168, 61);
            this.buttonX7.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX7.TabIndex = 17;
            this.buttonX7.Text = "组删除";
            this.buttonX7.Click += new System.EventHandler(this.buttonX7_Click);
            // 
            // superTabItem3
            // 
            this.superTabItem3.AttachedControl = this.superTabControlPanel3;
            this.superTabItem3.GlobalItem = false;
            this.superTabItem3.Name = "superTabItem3";
            this.superTabItem3.Text = "工序信息";
            // 
            // superTabControlPanel8
            // 
            this.superTabControlPanel8.Controls.Add(this.pwtDataGridView6);
            this.superTabControlPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel8.Location = new System.Drawing.Point(0, 35);
            this.superTabControlPanel8.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.superTabControlPanel8.Name = "superTabControlPanel8";
            this.superTabControlPanel8.Size = new System.Drawing.Size(1047, 708);
            this.superTabControlPanel8.TabIndex = 0;
            this.superTabControlPanel8.TabItem = this.superTabItem8;
            // 
            // pwtDataGridView6
            // 
            this.pwtDataGridView6.AllowUserToAddRows = false;
            this.pwtDataGridView6.AllowUserToDeleteRows = false;
            this.pwtDataGridView6.AllowUserToOrderColumns = true;
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(229)))), ((int)(((byte)(248)))));
            this.pwtDataGridView6.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle17;
            this.pwtDataGridView6.BackgroundColor = System.Drawing.SystemColors.Window;
            this.pwtDataGridView6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(246)))), ((int)(((byte)(239)))));
            dataGridViewCellStyle18.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.pwtDataGridView6.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle18;
            this.pwtDataGridView6.ColumnHeadersHeight = 26;
            this.pwtDataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.pwtDataGridView6.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2});
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle19.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle19.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle19.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.Color.Wheat;
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.Color.DarkSlateBlue;
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.pwtDataGridView6.DefaultCellStyle = dataGridViewCellStyle19;
            this.pwtDataGridView6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pwtDataGridView6.EnableHeadersVisualStyles = false;
            this.pwtDataGridView6.GridColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pwtDataGridView6.Location = new System.Drawing.Point(0, 0);
            this.pwtDataGridView6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pwtDataGridView6.MergeColumnHeaderBackColor = System.Drawing.SystemColors.Control;
            this.pwtDataGridView6.MergeColumnNames = ((System.Collections.Generic.List<string>)(resources.GetObject("pwtDataGridView6.MergeColumnNames")));
            this.pwtDataGridView6.Name = "pwtDataGridView6";
            this.pwtDataGridView6.ReadOnly = true;
            this.pwtDataGridView6.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle20.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle20.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle20.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.pwtDataGridView6.RowHeadersDefaultCellStyle = dataGridViewCellStyle20;
            this.pwtDataGridView6.RowHeadersWidth = 51;
            this.pwtDataGridView6.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.pwtDataGridView6.RowTemplate.Height = 27;
            this.pwtDataGridView6.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.pwtDataGridView6.Size = new System.Drawing.Size(1047, 708);
            this.pwtDataGridView6.TabIndex = 5;
            this.pwtDataGridView6.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.pwtDataGridView6_MouseDoubleClick);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "BIN名称";
            this.Column1.MinimumWidth = 6;
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 125;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "BIN定义";
            this.Column2.MinimumWidth = 6;
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 150;
            // 
            // superTabItem8
            // 
            this.superTabItem8.AttachedControl = this.superTabControlPanel8;
            this.superTabItem8.GlobalItem = false;
            this.superTabItem8.Name = "superTabItem8";
            this.superTabItem8.Text = "Bin定义";
            // 
            // superTabControlPanel5
            // 
            this.superTabControlPanel5.Controls.Add(this.pwtDataGridView4);
            this.superTabControlPanel5.Controls.Add(this.buttonX14);
            this.superTabControlPanel5.Controls.Add(this.buttonX12);
            this.superTabControlPanel5.Controls.Add(this.buttonX10);
            this.superTabControlPanel5.Controls.Add(this.tableLayoutPanel4);
            this.superTabControlPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel5.Location = new System.Drawing.Point(0, 35);
            this.superTabControlPanel5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.superTabControlPanel5.Name = "superTabControlPanel5";
            this.superTabControlPanel5.Size = new System.Drawing.Size(1047, 708);
            this.superTabControlPanel5.TabIndex = 0;
            this.superTabControlPanel5.TabItem = this.superTabItem5;
            this.superTabControlPanel5.Click += new System.EventHandler(this.superTabControlPanel5_Click);
            // 
            // pwtDataGridView4
            // 
            this.pwtDataGridView4.AllowUserToAddRows = false;
            this.pwtDataGridView4.AllowUserToDeleteRows = false;
            this.pwtDataGridView4.AllowUserToOrderColumns = true;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(229)))), ((int)(((byte)(248)))));
            this.pwtDataGridView4.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle9;
            this.pwtDataGridView4.BackgroundColor = System.Drawing.SystemColors.Window;
            this.pwtDataGridView4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(246)))), ((int)(((byte)(239)))));
            dataGridViewCellStyle10.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.pwtDataGridView4.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.pwtDataGridView4.ColumnHeadersHeight = 26;
            this.pwtDataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.Wheat;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.Color.DarkSlateBlue;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.pwtDataGridView4.DefaultCellStyle = dataGridViewCellStyle11;
            this.pwtDataGridView4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pwtDataGridView4.EnableHeadersVisualStyles = false;
            this.pwtDataGridView4.GridColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pwtDataGridView4.Location = new System.Drawing.Point(0, 0);
            this.pwtDataGridView4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pwtDataGridView4.MergeColumnHeaderBackColor = System.Drawing.SystemColors.Control;
            this.pwtDataGridView4.MergeColumnNames = ((System.Collections.Generic.List<string>)(resources.GetObject("pwtDataGridView4.MergeColumnNames")));
            this.pwtDataGridView4.Name = "pwtDataGridView4";
            this.pwtDataGridView4.ReadOnly = true;
            this.pwtDataGridView4.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.pwtDataGridView4.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.pwtDataGridView4.RowHeadersWidth = 51;
            this.pwtDataGridView4.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.pwtDataGridView4.RowTemplate.Height = 27;
            this.pwtDataGridView4.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.pwtDataGridView4.Size = new System.Drawing.Size(1047, 708);
            this.pwtDataGridView4.TabIndex = 6;
            this.pwtDataGridView4.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pwtDataGridView4_MouseClick);
            // 
            // buttonX14
            // 
            this.buttonX14.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX14.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX14.Location = new System.Drawing.Point(282, 2);
            this.buttonX14.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonX14.Name = "buttonX14";
            this.buttonX14.Size = new System.Drawing.Size(135, 46);
            this.buttonX14.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX14.TabIndex = 10;
            this.buttonX14.Text = "删除";
            this.buttonX14.Click += new System.EventHandler(this.buttonX14_Click);
            // 
            // buttonX12
            // 
            this.buttonX12.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX12.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX12.Location = new System.Drawing.Point(0, 2);
            this.buttonX12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonX12.Name = "buttonX12";
            this.buttonX12.Size = new System.Drawing.Size(135, 46);
            this.buttonX12.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX12.TabIndex = 9;
            this.buttonX12.Text = "查询";
            this.buttonX12.Click += new System.EventHandler(this.buttonX12_Click);
            // 
            // buttonX10
            // 
            this.buttonX10.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX10.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX10.Location = new System.Drawing.Point(141, 2);
            this.buttonX10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonX10.Name = "buttonX10";
            this.buttonX10.Size = new System.Drawing.Size(135, 46);
            this.buttonX10.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX10.TabIndex = 8;
            this.buttonX10.Text = "添加";
            this.buttonX10.Click += new System.EventHandler(this.buttonX10_Click);
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.14124F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 74.85876F));
            this.tableLayoutPanel4.Controls.Add(this.labelX25, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.comboBoxEx2, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.labelX26, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.textBoxX17, 1, 1);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 54);
            this.tableLayoutPanel4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(414, 82);
            this.tableLayoutPanel4.TabIndex = 7;
            // 
            // labelX25
            // 
            // 
            // 
            // 
            this.labelX25.BackgroundStyle.Class = "";
            this.labelX25.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX25.Location = new System.Drawing.Point(3, 2);
            this.labelX25.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.labelX25.Name = "labelX25";
            this.labelX25.Size = new System.Drawing.Size(98, 37);
            this.labelX25.TabIndex = 1;
            this.labelX25.Text = "Site名称";
            // 
            // comboBoxEx2
            // 
            this.comboBoxEx2.DisplayMember = "Text";
            this.comboBoxEx2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxEx2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.comboBoxEx2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxEx2.FormattingEnabled = true;
            this.comboBoxEx2.ItemHeight = 19;
            this.comboBoxEx2.Location = new System.Drawing.Point(107, 2);
            this.comboBoxEx2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBoxEx2.Name = "comboBoxEx2";
            this.comboBoxEx2.Size = new System.Drawing.Size(304, 25);
            this.comboBoxEx2.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.comboBoxEx2.TabIndex = 0;
            // 
            // labelX26
            // 
            // 
            // 
            // 
            this.labelX26.BackgroundStyle.Class = "";
            this.labelX26.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX26.Location = new System.Drawing.Point(3, 43);
            this.labelX26.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.labelX26.Name = "labelX26";
            this.labelX26.Size = new System.Drawing.Size(98, 37);
            this.labelX26.TabIndex = 2;
            this.labelX26.Text = "指    标";
            // 
            // textBoxX17
            // 
            // 
            // 
            // 
            this.textBoxX17.Border.Class = "TextBoxBorder";
            this.textBoxX17.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX17.Location = new System.Drawing.Point(107, 43);
            this.textBoxX17.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxX17.Name = "textBoxX17";
            this.textBoxX17.Size = new System.Drawing.Size(304, 39);
            this.textBoxX17.TabIndex = 3;
            // 
            // superTabItem5
            // 
            this.superTabItem5.AttachedControl = this.superTabControlPanel5;
            this.superTabItem5.GlobalItem = false;
            this.superTabItem5.Name = "superTabItem5";
            this.superTabItem5.Text = "Site指标管理";
            // 
            // superTabControlPanel4
            // 
            this.superTabControlPanel4.Controls.Add(this.pwtDataGridView3);
            this.superTabControlPanel4.Controls.Add(this.labelX34);
            this.superTabControlPanel4.Controls.Add(this.buttonX13);
            this.superTabControlPanel4.Controls.Add(this.buttonX9);
            this.superTabControlPanel4.Controls.Add(this.tableLayoutPanel3);
            this.superTabControlPanel4.Controls.Add(this.buttonX11);
            this.superTabControlPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel4.Location = new System.Drawing.Point(0, 35);
            this.superTabControlPanel4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.superTabControlPanel4.Name = "superTabControlPanel4";
            this.superTabControlPanel4.Size = new System.Drawing.Size(1047, 708);
            this.superTabControlPanel4.TabIndex = 0;
            this.superTabControlPanel4.TabItem = this.superTabItem4;
            // 
            // pwtDataGridView3
            // 
            this.pwtDataGridView3.AllowUserToAddRows = false;
            this.pwtDataGridView3.AllowUserToDeleteRows = false;
            this.pwtDataGridView3.AllowUserToOrderColumns = true;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(229)))), ((int)(((byte)(248)))));
            this.pwtDataGridView3.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle13;
            this.pwtDataGridView3.BackgroundColor = System.Drawing.SystemColors.Window;
            this.pwtDataGridView3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(246)))), ((int)(((byte)(239)))));
            dataGridViewCellStyle14.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.pwtDataGridView3.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle14;
            this.pwtDataGridView3.ColumnHeadersHeight = 26;
            this.pwtDataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle15.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.Color.Wheat;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.Color.DarkSlateBlue;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.pwtDataGridView3.DefaultCellStyle = dataGridViewCellStyle15;
            this.pwtDataGridView3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pwtDataGridView3.EnableHeadersVisualStyles = false;
            this.pwtDataGridView3.GridColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pwtDataGridView3.Location = new System.Drawing.Point(0, 0);
            this.pwtDataGridView3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pwtDataGridView3.MergeColumnHeaderBackColor = System.Drawing.SystemColors.Control;
            this.pwtDataGridView3.MergeColumnNames = ((System.Collections.Generic.List<string>)(resources.GetObject("pwtDataGridView3.MergeColumnNames")));
            this.pwtDataGridView3.Name = "pwtDataGridView3";
            this.pwtDataGridView3.ReadOnly = true;
            this.pwtDataGridView3.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.pwtDataGridView3.RowHeadersDefaultCellStyle = dataGridViewCellStyle16;
            this.pwtDataGridView3.RowHeadersWidth = 51;
            this.pwtDataGridView3.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.pwtDataGridView3.RowTemplate.Height = 27;
            this.pwtDataGridView3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.pwtDataGridView3.Size = new System.Drawing.Size(1047, 708);
            this.pwtDataGridView3.TabIndex = 4;
            this.pwtDataGridView3.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.pwtDataGridView3_CellContentClick);
            this.pwtDataGridView3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pwtDataGridView3_MouseClick);
            // 
            // labelX34
            // 
            this.labelX34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            // 
            // 
            // 
            this.labelX34.BackgroundStyle.Class = "";
            this.labelX34.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX34.ForeColor = System.Drawing.Color.Red;
            this.labelX34.Location = new System.Drawing.Point(428, 58);
            this.labelX34.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.labelX34.Name = "labelX34";
            this.labelX34.Size = new System.Drawing.Size(107, 130);
            this.labelX34.TabIndex = 8;
            this.labelX34.Text = "\r\n不在选择\r\n范围系统\r\n进行预警";
            this.labelX34.TextLineAlignment = System.Drawing.StringAlignment.Near;
            // 
            // buttonX13
            // 
            this.buttonX13.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX13.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX13.Location = new System.Drawing.Point(285, 5);
            this.buttonX13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonX13.Name = "buttonX13";
            this.buttonX13.Size = new System.Drawing.Size(135, 46);
            this.buttonX13.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX13.TabIndex = 7;
            this.buttonX13.Text = "删除";
            this.buttonX13.Click += new System.EventHandler(this.buttonX13_Click);
            // 
            // buttonX9
            // 
            this.buttonX9.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX9.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX9.Location = new System.Drawing.Point(144, 7);
            this.buttonX9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonX9.Name = "buttonX9";
            this.buttonX9.Size = new System.Drawing.Size(135, 46);
            this.buttonX9.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX9.TabIndex = 6;
            this.buttonX9.Text = "添加";
            this.buttonX9.Click += new System.EventHandler(this.buttonX9_Click);
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 135F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Controls.Add(this.labelX16, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.comboBoxEx1, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.labelX24, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.textBoxX5, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.labelX33, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.comboBoxEx4, 1, 2);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 58);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 3;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(417, 130);
            this.tableLayoutPanel3.TabIndex = 5;
            // 
            // labelX16
            // 
            // 
            // 
            // 
            this.labelX16.BackgroundStyle.Class = "";
            this.labelX16.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX16.Location = new System.Drawing.Point(3, 2);
            this.labelX16.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.labelX16.Name = "labelX16";
            this.labelX16.Size = new System.Drawing.Size(129, 39);
            this.labelX16.TabIndex = 1;
            this.labelX16.Text = "Bin名称";
            // 
            // comboBoxEx1
            // 
            this.comboBoxEx1.DisplayMember = "Text";
            this.comboBoxEx1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxEx1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.comboBoxEx1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxEx1.FormattingEnabled = true;
            this.comboBoxEx1.ItemHeight = 19;
            this.comboBoxEx1.Location = new System.Drawing.Point(138, 2);
            this.comboBoxEx1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBoxEx1.Name = "comboBoxEx1";
            this.comboBoxEx1.Size = new System.Drawing.Size(276, 25);
            this.comboBoxEx1.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.comboBoxEx1.TabIndex = 0;
            // 
            // labelX24
            // 
            // 
            // 
            // 
            this.labelX24.BackgroundStyle.Class = "";
            this.labelX24.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX24.Location = new System.Drawing.Point(3, 45);
            this.labelX24.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.labelX24.Name = "labelX24";
            this.labelX24.Size = new System.Drawing.Size(129, 39);
            this.labelX24.TabIndex = 2;
            this.labelX24.Text = "指   标";
            // 
            // textBoxX5
            // 
            // 
            // 
            // 
            this.textBoxX5.Border.Class = "TextBoxBorder";
            this.textBoxX5.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX5.Location = new System.Drawing.Point(138, 45);
            this.textBoxX5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxX5.Name = "textBoxX5";
            this.textBoxX5.Size = new System.Drawing.Size(276, 39);
            this.textBoxX5.TabIndex = 3;
            // 
            // labelX33
            // 
            // 
            // 
            // 
            this.labelX33.BackgroundStyle.Class = "";
            this.labelX33.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX33.Location = new System.Drawing.Point(4, 91);
            this.labelX33.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.labelX33.Name = "labelX33";
            this.labelX33.Size = new System.Drawing.Size(127, 34);
            this.labelX33.TabIndex = 4;
            this.labelX33.Text = "类型";
            // 
            // comboBoxEx4
            // 
            this.comboBoxEx4.DisplayMember = "Text";
            this.comboBoxEx4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxEx4.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.comboBoxEx4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxEx4.FormattingEnabled = true;
            this.comboBoxEx4.ItemHeight = 15;
            this.comboBoxEx4.Items.AddRange(new object[] {
            this.comboItem3,
            this.comboItem4,
            this.comboItem5,
            this.comboItem6,
            this.comboItem7});
            this.comboBoxEx4.Location = new System.Drawing.Point(139, 91);
            this.comboBoxEx4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comboBoxEx4.Name = "comboBoxEx4";
            this.comboBoxEx4.Size = new System.Drawing.Size(274, 21);
            this.comboBoxEx4.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.comboBoxEx4.TabIndex = 5;
            // 
            // comboItem3
            // 
            this.comboItem3.Text = "大于";
            // 
            // comboItem4
            // 
            this.comboItem4.Text = "大于等于";
            // 
            // comboItem5
            // 
            this.comboItem5.Text = "等于";
            // 
            // comboItem6
            // 
            this.comboItem6.Text = "小于";
            // 
            // comboItem7
            // 
            this.comboItem7.Text = "小于等于";
            // 
            // buttonX11
            // 
            this.buttonX11.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX11.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX11.Location = new System.Drawing.Point(3, 7);
            this.buttonX11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonX11.Name = "buttonX11";
            this.buttonX11.Size = new System.Drawing.Size(135, 46);
            this.buttonX11.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX11.TabIndex = 0;
            this.buttonX11.Text = "查询";
            this.buttonX11.Click += new System.EventHandler(this.buttonX11_Click);
            // 
            // superTabItem4
            // 
            this.superTabItem4.AttachedControl = this.superTabControlPanel4;
            this.superTabItem4.GlobalItem = false;
            this.superTabItem4.Name = "superTabItem4";
            this.superTabItem4.Text = "BIN指标管理";
            this.superTabItem4.Click += new System.EventHandler(this.superTabItem4_Click);
            // 
            // groupPanel2
            // 
            this.groupPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupPanel2.CanvasColor = System.Drawing.SystemColors.Control;
            this.groupPanel2.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.groupPanel2.Controls.Add(this.pwtDataGridView1);
            this.groupPanel2.Location = new System.Drawing.Point(2, 4);
            this.groupPanel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupPanel2.Name = "groupPanel2";
            this.groupPanel2.Size = new System.Drawing.Size(938, 739);
            // 
            // 
            // 
            this.groupPanel2.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.groupPanel2.Style.BackColorGradientAngle = 90;
            this.groupPanel2.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.groupPanel2.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel2.Style.BorderBottomWidth = 1;
            this.groupPanel2.Style.BorderColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.groupPanel2.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel2.Style.BorderLeftWidth = 1;
            this.groupPanel2.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel2.Style.BorderRightWidth = 1;
            this.groupPanel2.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel2.Style.BorderTopWidth = 1;
            this.groupPanel2.Style.Class = "";
            this.groupPanel2.Style.CornerDiameter = 4;
            this.groupPanel2.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.groupPanel2.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.groupPanel2.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.groupPanel2.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.groupPanel2.StyleMouseDown.Class = "";
            this.groupPanel2.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.groupPanel2.StyleMouseOver.Class = "";
            this.groupPanel2.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.groupPanel2.TabIndex = 1;
            this.groupPanel2.Text = "晶圆物料信息";
            // 
            // pwtDataGridView1
            // 
            this.pwtDataGridView1.AllowUserToAddRows = false;
            this.pwtDataGridView1.AllowUserToDeleteRows = false;
            this.pwtDataGridView1.AllowUserToOrderColumns = true;
            dataGridViewCellStyle21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(229)))), ((int)(((byte)(248)))));
            this.pwtDataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle21;
            this.pwtDataGridView1.BackgroundColor = System.Drawing.SystemColors.Window;
            this.balloonTip1.SetBalloonCaption(this.pwtDataGridView1, "系统提示");
            this.balloonTip1.SetBalloonText(this.pwtDataGridView1, "右击维护一致表单");
            this.pwtDataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(246)))), ((int)(((byte)(239)))));
            dataGridViewCellStyle22.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle22.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.pwtDataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle22;
            this.pwtDataGridView1.ColumnHeadersHeight = 26;
            this.pwtDataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.pwtDataGridView1.ContextMenuStrip = this.contextMenuStrip1;
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle23.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle23.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle23.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle23.SelectionBackColor = System.Drawing.Color.Wheat;
            dataGridViewCellStyle23.SelectionForeColor = System.Drawing.Color.DarkSlateBlue;
            dataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.pwtDataGridView1.DefaultCellStyle = dataGridViewCellStyle23;
            this.pwtDataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pwtDataGridView1.EnableHeadersVisualStyles = false;
            this.pwtDataGridView1.GridColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pwtDataGridView1.Location = new System.Drawing.Point(0, 0);
            this.pwtDataGridView1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pwtDataGridView1.MergeColumnHeaderBackColor = System.Drawing.SystemColors.Control;
            this.pwtDataGridView1.MergeColumnNames = ((System.Collections.Generic.List<string>)(resources.GetObject("pwtDataGridView1.MergeColumnNames")));
            this.pwtDataGridView1.Name = "pwtDataGridView1";
            this.pwtDataGridView1.ReadOnly = true;
            this.pwtDataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle24.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle24.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle24.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle24.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.pwtDataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle24;
            this.pwtDataGridView1.RowHeadersWidth = 51;
            this.pwtDataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.pwtDataGridView1.RowTemplate.Height = 27;
            this.pwtDataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.pwtDataGridView1.Size = new System.Drawing.Size(932, 708);
            this.pwtDataGridView1.TabIndex = 2;
            this.pwtDataGridView1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.pwtDataGridView1_MouseDoubleClick);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.上传一致表单ToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(189, 34);
            // 
            // 上传一致表单ToolStripMenuItem
            // 
            this.上传一致表单ToolStripMenuItem.Name = "上传一致表单ToolStripMenuItem";
            this.上传一致表单ToolStripMenuItem.Size = new System.Drawing.Size(188, 30);
            this.上传一致表单ToolStripMenuItem.Text = "一致表单管理";
            this.上传一致表单ToolStripMenuItem.Click += new System.EventHandler(this.上传一致表单ToolStripMenuItem_Click);
            // 
            // superTabItem1
            // 
            this.superTabItem1.AttachedControl = this.superTabControlPanel1;
            this.superTabItem1.GlobalItem = false;
            this.superTabItem1.Name = "superTabItem1";
            this.superTabItem1.Text = "信息列表";
            // 
            // superTabControlPanel2
            // 
            this.superTabControlPanel2.Controls.Add(this.textBoxX22);
            this.superTabControlPanel2.Controls.Add(this.labelX18);
            this.superTabControlPanel2.Controls.Add(this.buttonX4);
            this.superTabControlPanel2.Controls.Add(this.textBoxX14);
            this.superTabControlPanel2.Controls.Add(this.buttonX3);
            this.superTabControlPanel2.Controls.Add(this.textBoxX15);
            this.superTabControlPanel2.Controls.Add(this.buttonX2);
            this.superTabControlPanel2.Controls.Add(this.labelX11);
            this.superTabControlPanel2.Controls.Add(this.labelX6);
            this.superTabControlPanel2.Controls.Add(this.labelX12);
            this.superTabControlPanel2.Controls.Add(this.labelX7);
            this.superTabControlPanel2.Controls.Add(this.labelX10);
            this.superTabControlPanel2.Controls.Add(this.labelX8);
            this.superTabControlPanel2.Controls.Add(this.textBoxX13);
            this.superTabControlPanel2.Controls.Add(this.labelX3);
            this.superTabControlPanel2.Controls.Add(this.textBoxX11);
            this.superTabControlPanel2.Controls.Add(this.labelX4);
            this.superTabControlPanel2.Controls.Add(this.labelX5);
            this.superTabControlPanel2.Controls.Add(this.labelX9);
            this.superTabControlPanel2.Controls.Add(this.textBoxX12);
            this.superTabControlPanel2.Controls.Add(this.labelX32);
            this.superTabControlPanel2.Controls.Add(this.labelX21);
            this.superTabControlPanel2.Controls.Add(this.textBoxX18);
            this.superTabControlPanel2.Controls.Add(this.labelX27);
            this.superTabControlPanel2.Controls.Add(this.textBoxX10);
            this.superTabControlPanel2.Controls.Add(this.pwtSearchBox1);
            this.superTabControlPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel2.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.superTabControlPanel2.Name = "superTabControlPanel2";
            this.superTabControlPanel2.Size = new System.Drawing.Size(1993, 780);
            this.superTabControlPanel2.TabIndex = 0;
            this.superTabControlPanel2.TabItem = this.superTabItem2;
            // 
            // textBoxX22
            // 
            // 
            // 
            // 
            this.textBoxX22.Border.Class = "TextBoxBorder";
            this.textBoxX22.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX22.Location = new System.Drawing.Point(130, 298);
            this.textBoxX22.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxX22.Name = "textBoxX22";
            this.textBoxX22.Size = new System.Drawing.Size(284, 39);
            this.textBoxX22.TabIndex = 12;
            // 
            // labelX18
            // 
            // 
            // 
            // 
            this.labelX18.BackgroundStyle.Class = "";
            this.labelX18.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX18.Location = new System.Drawing.Point(21, 35);
            this.labelX18.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.labelX18.Name = "labelX18";
            this.labelX18.Size = new System.Drawing.Size(129, 36);
            this.labelX18.TabIndex = 0;
            this.labelX18.Text = "流程组";
            // 
            // buttonX4
            // 
            this.buttonX4.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX4.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX4.Location = new System.Drawing.Point(649, 298);
            this.buttonX4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonX4.Name = "buttonX4";
            this.buttonX4.Size = new System.Drawing.Size(135, 46);
            this.buttonX4.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX4.TabIndex = 3;
            this.buttonX4.Text = "修改";
            this.buttonX4.Click += new System.EventHandler(this.buttonX4_Click);
            // 
            // textBoxX14
            // 
            // 
            // 
            // 
            this.textBoxX14.Border.Class = "TextBoxBorder";
            this.textBoxX14.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX14.Location = new System.Drawing.Point(201, 121);
            this.textBoxX14.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxX14.Name = "textBoxX14";
            this.textBoxX14.Size = new System.Drawing.Size(284, 39);
            this.textBoxX14.TabIndex = 19;
            this.textBoxX14.TextChanged += new System.EventHandler(this.textBoxX14_TextChanged);
            this.textBoxX14.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxX14_KeyPress);
            // 
            // buttonX3
            // 
            this.buttonX3.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX3.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX3.Location = new System.Drawing.Point(791, 298);
            this.buttonX3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonX3.Name = "buttonX3";
            this.buttonX3.Size = new System.Drawing.Size(135, 46);
            this.buttonX3.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX3.TabIndex = 2;
            this.buttonX3.Text = "删除";
            this.buttonX3.Click += new System.EventHandler(this.buttonX3_Click);
            // 
            // textBoxX15
            // 
            // 
            // 
            // 
            this.textBoxX15.Border.Class = "TextBoxBorder";
            this.textBoxX15.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX15.Location = new System.Drawing.Point(201, 162);
            this.textBoxX15.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxX15.Name = "textBoxX15";
            this.textBoxX15.Size = new System.Drawing.Size(284, 39);
            this.textBoxX15.TabIndex = 22;
            this.textBoxX15.TextChanged += new System.EventHandler(this.textBoxX15_TextChanged);
            this.textBoxX15.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxX15_KeyPress);
            // 
            // buttonX2
            // 
            this.buttonX2.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX2.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX2.Location = new System.Drawing.Point(508, 298);
            this.buttonX2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonX2.Name = "buttonX2";
            this.buttonX2.Size = new System.Drawing.Size(135, 46);
            this.buttonX2.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX2.TabIndex = 1;
            this.buttonX2.Text = "添加";
            this.buttonX2.Click += new System.EventHandler(this.buttonX2_Click);
            // 
            // labelX11
            // 
            // 
            // 
            // 
            this.labelX11.BackgroundStyle.Class = "";
            this.labelX11.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX11.Location = new System.Drawing.Point(21, 79);
            this.labelX11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.labelX11.Name = "labelX11";
            this.labelX11.Size = new System.Drawing.Size(129, 34);
            this.labelX11.TabIndex = 0;
            this.labelX11.Text = "B in 指 标 %";
            // 
            // labelX6
            // 
            // 
            // 
            // 
            this.labelX6.BackgroundStyle.Class = "";
            this.labelX6.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX6.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labelX6.ForeColor = System.Drawing.Color.Red;
            this.labelX6.Location = new System.Drawing.Point(482, 199);
            this.labelX6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.labelX6.Name = "labelX6";
            this.labelX6.Size = new System.Drawing.Size(138, 37);
            this.labelX6.TabIndex = 0;
            this.labelX6.Text = "0";
            this.labelX6.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // labelX12
            // 
            // 
            // 
            // 
            this.labelX12.BackgroundStyle.Class = "";
            this.labelX12.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX12.Location = new System.Drawing.Point(21, 120);
            this.labelX12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.labelX12.Name = "labelX12";
            this.labelX12.Size = new System.Drawing.Size(129, 34);
            this.labelX12.TabIndex = 0;
            this.labelX12.Text = "Site 指 标 %";
            // 
            // labelX7
            // 
            // 
            // 
            // 
            this.labelX7.BackgroundStyle.Class = "";
            this.labelX7.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX7.Location = new System.Drawing.Point(490, 122);
            this.labelX7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.labelX7.Name = "labelX7";
            this.labelX7.Size = new System.Drawing.Size(130, 34);
            this.labelX7.TabIndex = 0;
            this.labelX7.Text = "0";
            this.labelX7.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // labelX10
            // 
            // 
            // 
            // 
            this.labelX10.BackgroundStyle.Class = "";
            this.labelX10.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX10.Location = new System.Drawing.Point(21, 155);
            this.labelX10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.labelX10.Name = "labelX10";
            this.labelX10.Size = new System.Drawing.Size(159, 37);
            this.labelX10.TabIndex = 0;
            this.labelX10.Text = "特殊管控%";
            // 
            // labelX8
            // 
            // 
            // 
            // 
            this.labelX8.BackgroundStyle.Class = "";
            this.labelX8.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX8.Location = new System.Drawing.Point(490, 163);
            this.labelX8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.labelX8.Name = "labelX8";
            this.labelX8.Size = new System.Drawing.Size(130, 34);
            this.labelX8.TabIndex = 0;
            this.labelX8.Text = "0";
            this.labelX8.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // textBoxX13
            // 
            // 
            // 
            // 
            this.textBoxX13.Border.Class = "TextBoxBorder";
            this.textBoxX13.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX13.Location = new System.Drawing.Point(201, 199);
            this.textBoxX13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxX13.Name = "textBoxX13";
            this.textBoxX13.Size = new System.Drawing.Size(274, 39);
            this.textBoxX13.TabIndex = 16;
            this.textBoxX13.Text = "0";
            this.textBoxX13.TextChanged += new System.EventHandler(this.textBoxX13_TextChanged);
            this.textBoxX13.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxX13_KeyPress);
            // 
            // labelX3
            // 
            // 
            // 
            // 
            this.labelX3.BackgroundStyle.Class = "";
            this.labelX3.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX3.Location = new System.Drawing.Point(864, 34);
            this.labelX3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.labelX3.Name = "labelX3";
            this.labelX3.Size = new System.Drawing.Size(159, 37);
            this.labelX3.TabIndex = 0;
            this.labelX3.Text = "良率指标(片)%";
            // 
            // textBoxX11
            // 
            // 
            // 
            // 
            this.textBoxX11.Border.Class = "TextBoxBorder";
            this.textBoxX11.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX11.Location = new System.Drawing.Point(1029, 34);
            this.textBoxX11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxX11.Name = "textBoxX11";
            this.textBoxX11.Size = new System.Drawing.Size(285, 39);
            this.textBoxX11.TabIndex = 7;
            this.textBoxX11.TextChanged += new System.EventHandler(this.textBoxX11_TextChanged);
            // 
            // labelX4
            // 
            // 
            // 
            // 
            this.labelX4.BackgroundStyle.Class = "";
            this.labelX4.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX4.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labelX4.ForeColor = System.Drawing.Color.Red;
            this.labelX4.Location = new System.Drawing.Point(1320, 34);
            this.labelX4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.labelX4.Name = "labelX4";
            this.labelX4.Size = new System.Drawing.Size(152, 37);
            this.labelX4.TabIndex = 0;
            this.labelX4.Text = "0";
            this.labelX4.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // labelX5
            // 
            // 
            // 
            // 
            this.labelX5.BackgroundStyle.Class = "";
            this.labelX5.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX5.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labelX5.ForeColor = System.Drawing.Color.Red;
            this.labelX5.Location = new System.Drawing.Point(1320, 77);
            this.labelX5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.labelX5.Name = "labelX5";
            this.labelX5.Size = new System.Drawing.Size(152, 37);
            this.labelX5.TabIndex = 0;
            this.labelX5.Text = "0";
            this.labelX5.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // labelX9
            // 
            // 
            // 
            // 
            this.labelX9.BackgroundStyle.Class = "";
            this.labelX9.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX9.Location = new System.Drawing.Point(864, 77);
            this.labelX9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.labelX9.Name = "labelX9";
            this.labelX9.Size = new System.Drawing.Size(159, 37);
            this.labelX9.TabIndex = 0;
            this.labelX9.Text = "良率指标(批)%";
            // 
            // textBoxX12
            // 
            // 
            // 
            // 
            this.textBoxX12.Border.Class = "TextBoxBorder";
            this.textBoxX12.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX12.Location = new System.Drawing.Point(1029, 77);
            this.textBoxX12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxX12.Name = "textBoxX12";
            this.textBoxX12.Size = new System.Drawing.Size(285, 39);
            this.textBoxX12.TabIndex = 10;
            this.textBoxX12.TextChanged += new System.EventHandler(this.textBoxX12_TextChanged);
            // 
            // labelX32
            // 
            // 
            // 
            // 
            this.labelX32.BackgroundStyle.Class = "";
            this.labelX32.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX32.Location = new System.Drawing.Point(18, 298);
            this.labelX32.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.labelX32.Name = "labelX32";
            this.labelX32.Size = new System.Drawing.Size(104, 35);
            this.labelX32.TabIndex = 35;
            this.labelX32.Text = "墨水型号";
            // 
            // labelX21
            // 
            // 
            // 
            // 
            this.labelX21.BackgroundStyle.Class = "";
            this.labelX21.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX21.Location = new System.Drawing.Point(21, 341);
            this.labelX21.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.labelX21.Name = "labelX21";
            this.labelX21.Size = new System.Drawing.Size(104, 37);
            this.labelX21.TabIndex = 27;
            this.labelX21.Text = "烘烤温度";
            // 
            // textBoxX18
            // 
            // 
            // 
            // 
            this.textBoxX18.Border.Class = "TextBoxBorder";
            this.textBoxX18.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX18.Location = new System.Drawing.Point(130, 341);
            this.textBoxX18.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxX18.Name = "textBoxX18";
            this.textBoxX18.Size = new System.Drawing.Size(287, 39);
            this.textBoxX18.TabIndex = 24;
            // 
            // labelX27
            // 
            // 
            // 
            // 
            this.labelX27.BackgroundStyle.Class = "";
            this.labelX27.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX27.Location = new System.Drawing.Point(21, 384);
            this.labelX27.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.labelX27.Name = "labelX27";
            this.labelX27.Size = new System.Drawing.Size(104, 37);
            this.labelX27.TabIndex = 26;
            this.labelX27.Text = "烘烤时长";
            // 
            // textBoxX10
            // 
            // 
            // 
            // 
            this.textBoxX10.Border.Class = "TextBoxBorder";
            this.textBoxX10.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX10.Location = new System.Drawing.Point(130, 384);
            this.textBoxX10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxX10.Name = "textBoxX10";
            this.textBoxX10.Size = new System.Drawing.Size(285, 39);
            this.textBoxX10.TabIndex = 23;
            // 
            // pwtSearchBox1
            // 
            this.pwtSearchBox1.BackColor = System.Drawing.Color.White;
            this.pwtSearchBox1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(128)))), ((int)(((byte)(160)))));
            this.pwtSearchBox1.EmptyText = null;
            this.pwtSearchBox1.ImageHover = ((System.Drawing.Image)(resources.GetObject("pwtSearchBox1.ImageHover")));
            this.pwtSearchBox1.ImageNormal = ((System.Drawing.Image)(resources.GetObject("pwtSearchBox1.ImageNormal")));
            this.pwtSearchBox1.InputChangeTriggerTime = 600;
            this.pwtSearchBox1.IsSpaceKeyCodeValid = false;
            this.pwtSearchBox1.Location = new System.Drawing.Point(201, 79);
            this.pwtSearchBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pwtSearchBox1.Name = "pwtSearchBox1";
            this.pwtSearchBox1.SearchBtnHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(214)))), ((int)(((byte)(125)))));
            this.pwtSearchBox1.Size = new System.Drawing.Size(284, 36);
            this.pwtSearchBox1.TabIndex = 11;
            this.pwtSearchBox1.SearchBtnClick += new System.EventHandler(this.pwtSearchBox1_SearchBtnClick);
            // 
            // superTabItem2
            // 
            this.superTabItem2.AttachedControl = this.superTabControlPanel2;
            this.superTabItem2.GlobalItem = false;
            this.superTabItem2.Name = "superTabItem2";
            this.superTabItem2.Text = "隐藏";
            this.superTabItem2.Visible = false;
            // 
            // buttonX1
            // 
            this.buttonX1.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX1.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX1.Location = new System.Drawing.Point(14, 12);
            this.buttonX1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonX1.Name = "buttonX1";
            this.buttonX1.Size = new System.Drawing.Size(135, 46);
            this.buttonX1.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX1.TabIndex = 0;
            this.buttonX1.Text = "查询";
            this.buttonX1.Click += new System.EventHandler(this.buttonX1_Click);
            // 
            // superTabControlPanel10
            // 
            this.superTabControlPanel10.Controls.Add(this.superTabControl6);
            this.superTabControlPanel10.Controls.Add(this.tableLayoutPanel5);
            this.superTabControlPanel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel10.Location = new System.Drawing.Point(0, 35);
            this.superTabControlPanel10.Name = "superTabControlPanel10";
            this.superTabControlPanel10.Size = new System.Drawing.Size(538, 588);
            this.superTabControlPanel10.TabIndex = 1;
            // 
            // superTabControl6
            // 
            this.superTabControl6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            // 
            // 
            // 
            // 
            // 
            // 
            this.superTabControl6.ControlBox.CloseBox.Name = "";
            // 
            // 
            // 
            this.superTabControl6.ControlBox.MenuBox.Name = "";
            this.superTabControl6.ControlBox.Name = "";
            this.superTabControl6.ControlBox.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabControl6.ControlBox.MenuBox,
            this.superTabControl6.ControlBox.CloseBox});
            this.superTabControl6.Location = new System.Drawing.Point(3, 72);
            this.superTabControl6.Name = "superTabControl6";
            this.superTabControl6.ReorderTabsEnabled = true;
            this.superTabControl6.SelectedTabFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold);
            this.superTabControl6.SelectedTabIndex = 0;
            this.superTabControl6.Size = new System.Drawing.Size(536, 511);
            this.superTabControl6.TabFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.superTabControl6.TabIndex = 24;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel5.ColumnCount = 3;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel5.Controls.Add(this.buttonX17, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.buttonX18, 2, 0);
            this.tableLayoutPanel5.Controls.Add(this.buttonX19, 1, 0);
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(522, 62);
            this.tableLayoutPanel5.TabIndex = 23;
            // 
            // buttonX17
            // 
            this.buttonX17.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX17.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonX17.Location = new System.Drawing.Point(3, 3);
            this.buttonX17.Name = "buttonX17";
            this.buttonX17.Size = new System.Drawing.Size(168, 56);
            this.buttonX17.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX17.TabIndex = 16;
            // 
            // buttonX18
            // 
            this.buttonX18.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX18.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonX18.Location = new System.Drawing.Point(351, 3);
            this.buttonX18.Name = "buttonX18";
            this.buttonX18.Size = new System.Drawing.Size(168, 56);
            this.buttonX18.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX18.TabIndex = 18;
            // 
            // buttonX19
            // 
            this.buttonX19.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX19.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonX19.Location = new System.Drawing.Point(177, 3);
            this.buttonX19.Name = "buttonX19";
            this.buttonX19.Size = new System.Drawing.Size(168, 56);
            this.buttonX19.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX19.TabIndex = 17;
            // 
            // superTabItem10
            // 
            this.superTabItem10.GlobalItem = false;
            this.superTabItem10.Name = "superTabItem10";
            this.superTabItem10.Text = "操作记录";
            // 
            // superTabControlPanel13
            // 
            this.superTabControlPanel13.Controls.Add(this.buttonX20);
            this.superTabControlPanel13.Controls.Add(this.labelX35);
            this.superTabControlPanel13.Controls.Add(this.buttonX21);
            this.superTabControlPanel13.Controls.Add(this.buttonX22);
            this.superTabControlPanel13.Controls.Add(this.pwtDataGridView9);
            this.superTabControlPanel13.Controls.Add(this.buttonX23);
            this.superTabControlPanel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel13.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel13.Name = "superTabControlPanel13";
            this.superTabControlPanel13.Size = new System.Drawing.Size(538, 623);
            this.superTabControlPanel13.TabIndex = 0;
            // 
            // buttonX20
            // 
            this.buttonX20.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX20.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX20.Location = new System.Drawing.Point(345, 8);
            this.buttonX20.Name = "buttonX20";
            this.buttonX20.Size = new System.Drawing.Size(108, 45);
            this.buttonX20.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX20.TabIndex = 9;
            // 
            // labelX35
            // 
            this.labelX35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            // 
            // 
            // 
            this.labelX35.BackgroundStyle.Class = "";
            this.labelX35.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX35.ForeColor = System.Drawing.Color.Red;
            this.labelX35.Location = new System.Drawing.Point(428, 57);
            this.labelX35.Margin = new System.Windows.Forms.Padding(4);
            this.labelX35.Name = "labelX35";
            this.labelX35.Size = new System.Drawing.Size(106, 129);
            this.labelX35.TabIndex = 8;
            this.labelX35.TextLineAlignment = System.Drawing.StringAlignment.Near;
            this.labelX35.Visible = false;
            // 
            // buttonX21
            // 
            this.buttonX21.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX21.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX21.Location = new System.Drawing.Point(231, 8);
            this.buttonX21.Name = "buttonX21";
            this.buttonX21.Size = new System.Drawing.Size(108, 45);
            this.buttonX21.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX21.TabIndex = 7;
            // 
            // buttonX22
            // 
            this.buttonX22.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX22.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX22.Location = new System.Drawing.Point(117, 8);
            this.buttonX22.Name = "buttonX22";
            this.buttonX22.Size = new System.Drawing.Size(108, 45);
            this.buttonX22.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX22.TabIndex = 6;
            // 
            // pwtDataGridView9
            // 
            this.pwtDataGridView9.AllowUserToAddRows = false;
            this.pwtDataGridView9.AllowUserToDeleteRows = false;
            this.pwtDataGridView9.AllowUserToOrderColumns = true;
            dataGridViewCellStyle25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(229)))), ((int)(((byte)(248)))));
            this.pwtDataGridView9.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle25;
            this.pwtDataGridView9.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pwtDataGridView9.BackgroundColor = System.Drawing.SystemColors.Window;
            this.pwtDataGridView9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(246)))), ((int)(((byte)(239)))));
            dataGridViewCellStyle26.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle26.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle26.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle26.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle26.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.pwtDataGridView9.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle26;
            this.pwtDataGridView9.ColumnHeadersHeight = 26;
            this.pwtDataGridView9.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle27.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle27.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle27.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle27.SelectionBackColor = System.Drawing.Color.Wheat;
            dataGridViewCellStyle27.SelectionForeColor = System.Drawing.Color.DarkSlateBlue;
            dataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.pwtDataGridView9.DefaultCellStyle = dataGridViewCellStyle27;
            this.pwtDataGridView9.EnableHeadersVisualStyles = false;
            this.pwtDataGridView9.GridColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pwtDataGridView9.Location = new System.Drawing.Point(4, 190);
            this.pwtDataGridView9.MergeColumnHeaderBackColor = System.Drawing.SystemColors.Control;
            this.pwtDataGridView9.MergeColumnNames = ((System.Collections.Generic.List<string>)(resources.GetObject("pwtDataGridView9.MergeColumnNames")));
            this.pwtDataGridView9.Name = "pwtDataGridView9";
            this.pwtDataGridView9.ReadOnly = true;
            this.pwtDataGridView9.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle28.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle28.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle28.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle28.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle28.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle28.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.pwtDataGridView9.RowHeadersDefaultCellStyle = dataGridViewCellStyle28;
            this.pwtDataGridView9.RowHeadersWidth = 51;
            this.pwtDataGridView9.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.pwtDataGridView9.RowTemplate.Height = 27;
            this.pwtDataGridView9.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.pwtDataGridView9.Size = new System.Drawing.Size(531, 427);
            this.pwtDataGridView9.TabIndex = 4;
            // 
            // buttonX23
            // 
            this.buttonX23.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX23.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX23.Location = new System.Drawing.Point(3, 8);
            this.buttonX23.Name = "buttonX23";
            this.buttonX23.Size = new System.Drawing.Size(108, 45);
            this.buttonX23.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX23.TabIndex = 0;
            // 
            // labelX36
            // 
            // 
            // 
            // 
            this.labelX36.BackgroundStyle.Class = "";
            this.labelX36.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX36.Location = new System.Drawing.Point(3, 3);
            this.labelX36.Name = "labelX36";
            this.labelX36.Size = new System.Drawing.Size(129, 201);
            this.labelX36.TabIndex = 1;
            // 
            // comboBoxEx5
            // 
            this.comboBoxEx5.DisplayMember = "Text";
            this.comboBoxEx5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxEx5.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.comboBoxEx5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxEx5.FormattingEnabled = true;
            this.comboBoxEx5.ItemHeight = 19;
            this.comboBoxEx5.Location = new System.Drawing.Point(138, 3);
            this.comboBoxEx5.Name = "comboBoxEx5";
            this.comboBoxEx5.Size = new System.Drawing.Size(397, 25);
            this.comboBoxEx5.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.comboBoxEx5.TabIndex = 0;
            // 
            // labelX37
            // 
            // 
            // 
            // 
            this.labelX37.BackgroundStyle.Class = "";
            this.labelX37.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX37.Location = new System.Drawing.Point(3, 210);
            this.labelX37.Name = "labelX37";
            this.labelX37.Size = new System.Drawing.Size(129, 201);
            this.labelX37.TabIndex = 2;
            // 
            // textBoxX20
            // 
            // 
            // 
            // 
            this.textBoxX20.Border.Class = "TextBoxBorder";
            this.textBoxX20.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX20.Location = new System.Drawing.Point(138, 210);
            this.textBoxX20.Name = "textBoxX20";
            this.textBoxX20.Size = new System.Drawing.Size(397, 39);
            this.textBoxX20.TabIndex = 3;
            // 
            // labelX38
            // 
            // 
            // 
            // 
            this.labelX38.BackgroundStyle.Class = "";
            this.labelX38.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX38.Location = new System.Drawing.Point(4, 418);
            this.labelX38.Margin = new System.Windows.Forms.Padding(4);
            this.labelX38.Name = "labelX38";
            this.labelX38.Size = new System.Drawing.Size(127, 201);
            this.labelX38.TabIndex = 4;
            // 
            // comboBoxEx6
            // 
            this.comboBoxEx6.DisplayMember = "Text";
            this.comboBoxEx6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxEx6.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.comboBoxEx6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxEx6.FormattingEnabled = true;
            this.comboBoxEx6.ItemHeight = 15;
            this.comboBoxEx6.Items.AddRange(new object[] {
            this.comboItem8,
            this.comboItem9,
            this.comboItem10,
            this.comboItem11,
            this.comboItem12});
            this.comboBoxEx6.Location = new System.Drawing.Point(139, 418);
            this.comboBoxEx6.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxEx6.Name = "comboBoxEx6";
            this.comboBoxEx6.Size = new System.Drawing.Size(395, 21);
            this.comboBoxEx6.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.comboBoxEx6.TabIndex = 5;
            // 
            // comboItem8
            // 
            this.comboItem8.Text = "大于";
            // 
            // comboItem9
            // 
            this.comboItem9.Text = "大于等于";
            // 
            // comboItem10
            // 
            this.comboItem10.Text = "等于";
            // 
            // comboItem11
            // 
            this.comboItem11.Text = "小于";
            // 
            // comboItem12
            // 
            this.comboItem12.Text = "小于等于";
            // 
            // superTabControlPanel14
            // 
            this.superTabControlPanel14.Controls.Add(this.pwtDataGridView10);
            this.superTabControlPanel14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel14.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel14.Margin = new System.Windows.Forms.Padding(4);
            this.superTabControlPanel14.Name = "superTabControlPanel14";
            this.superTabControlPanel14.Size = new System.Drawing.Size(538, 623);
            this.superTabControlPanel14.TabIndex = 0;
            // 
            // pwtDataGridView10
            // 
            this.pwtDataGridView10.AllowUserToAddRows = false;
            this.pwtDataGridView10.AllowUserToDeleteRows = false;
            this.pwtDataGridView10.AllowUserToOrderColumns = true;
            dataGridViewCellStyle29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(229)))), ((int)(((byte)(248)))));
            this.pwtDataGridView10.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle29;
            this.pwtDataGridView10.BackgroundColor = System.Drawing.SystemColors.Window;
            this.pwtDataGridView10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(246)))), ((int)(((byte)(239)))));
            dataGridViewCellStyle30.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle30.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle30.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle30.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle30.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.pwtDataGridView10.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle30;
            this.pwtDataGridView10.ColumnHeadersHeight = 26;
            this.pwtDataGridView10.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.pwtDataGridView10.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            dataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle31.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle31.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle31.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle31.SelectionBackColor = System.Drawing.Color.Wheat;
            dataGridViewCellStyle31.SelectionForeColor = System.Drawing.Color.DarkSlateBlue;
            dataGridViewCellStyle31.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.pwtDataGridView10.DefaultCellStyle = dataGridViewCellStyle31;
            this.pwtDataGridView10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pwtDataGridView10.EnableHeadersVisualStyles = false;
            this.pwtDataGridView10.GridColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pwtDataGridView10.Location = new System.Drawing.Point(0, 0);
            this.pwtDataGridView10.MergeColumnHeaderBackColor = System.Drawing.SystemColors.Control;
            this.pwtDataGridView10.MergeColumnNames = ((System.Collections.Generic.List<string>)(resources.GetObject("pwtDataGridView10.MergeColumnNames")));
            this.pwtDataGridView10.Name = "pwtDataGridView10";
            this.pwtDataGridView10.ReadOnly = true;
            this.pwtDataGridView10.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle32.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle32.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle32.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle32.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle32.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle32.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.pwtDataGridView10.RowHeadersDefaultCellStyle = dataGridViewCellStyle32;
            this.pwtDataGridView10.RowHeadersWidth = 51;
            this.pwtDataGridView10.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.pwtDataGridView10.RowTemplate.Height = 27;
            this.pwtDataGridView10.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.pwtDataGridView10.Size = new System.Drawing.Size(538, 623);
            this.pwtDataGridView10.TabIndex = 5;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "BIN名称";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 150;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "BIN定义";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 150;
            // 
            // superTabControlPanel15
            // 
            this.superTabControlPanel15.Controls.Add(this.labelX39);
            this.superTabControlPanel15.Controls.Add(this.buttonX24);
            this.superTabControlPanel15.Controls.Add(this.buttonX25);
            this.superTabControlPanel15.Controls.Add(this.buttonX26);
            this.superTabControlPanel15.Controls.Add(this.pwtDataGridView11);
            this.superTabControlPanel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel15.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel15.Name = "superTabControlPanel15";
            this.superTabControlPanel15.Size = new System.Drawing.Size(538, 623);
            this.superTabControlPanel15.TabIndex = 0;
            // 
            // labelX39
            // 
            this.labelX39.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            // 
            // 
            // 
            this.labelX39.BackgroundStyle.Class = "";
            this.labelX39.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX39.ForeColor = System.Drawing.Color.Red;
            this.labelX39.Location = new System.Drawing.Point(424, 6);
            this.labelX39.Margin = new System.Windows.Forms.Padding(4);
            this.labelX39.Name = "labelX39";
            this.labelX39.Size = new System.Drawing.Size(106, 129);
            this.labelX39.TabIndex = 11;
            // 
            // buttonX24
            // 
            this.buttonX24.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX24.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX24.Location = new System.Drawing.Point(282, 3);
            this.buttonX24.Name = "buttonX24";
            this.buttonX24.Size = new System.Drawing.Size(135, 45);
            this.buttonX24.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX24.TabIndex = 10;
            // 
            // buttonX25
            // 
            this.buttonX25.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX25.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX25.Location = new System.Drawing.Point(0, 3);
            this.buttonX25.Name = "buttonX25";
            this.buttonX25.Size = new System.Drawing.Size(135, 45);
            this.buttonX25.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX25.TabIndex = 9;
            // 
            // buttonX26
            // 
            this.buttonX26.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX26.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX26.Location = new System.Drawing.Point(141, 3);
            this.buttonX26.Name = "buttonX26";
            this.buttonX26.Size = new System.Drawing.Size(135, 45);
            this.buttonX26.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX26.TabIndex = 8;
            // 
            // pwtDataGridView11
            // 
            this.pwtDataGridView11.AllowUserToAddRows = false;
            this.pwtDataGridView11.AllowUserToDeleteRows = false;
            this.pwtDataGridView11.AllowUserToOrderColumns = true;
            dataGridViewCellStyle33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(229)))), ((int)(((byte)(248)))));
            this.pwtDataGridView11.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle33;
            this.pwtDataGridView11.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pwtDataGridView11.BackgroundColor = System.Drawing.SystemColors.Window;
            this.pwtDataGridView11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(246)))), ((int)(((byte)(239)))));
            dataGridViewCellStyle34.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle34.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle34.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle34.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle34.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.pwtDataGridView11.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle34;
            this.pwtDataGridView11.ColumnHeadersHeight = 26;
            this.pwtDataGridView11.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle35.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle35.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle35.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle35.SelectionBackColor = System.Drawing.Color.Wheat;
            dataGridViewCellStyle35.SelectionForeColor = System.Drawing.Color.DarkSlateBlue;
            dataGridViewCellStyle35.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.pwtDataGridView11.DefaultCellStyle = dataGridViewCellStyle35;
            this.pwtDataGridView11.EnableHeadersVisualStyles = false;
            this.pwtDataGridView11.GridColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pwtDataGridView11.Location = new System.Drawing.Point(4, 138);
            this.pwtDataGridView11.MergeColumnHeaderBackColor = System.Drawing.SystemColors.Control;
            this.pwtDataGridView11.MergeColumnNames = ((System.Collections.Generic.List<string>)(resources.GetObject("pwtDataGridView11.MergeColumnNames")));
            this.pwtDataGridView11.Name = "pwtDataGridView11";
            this.pwtDataGridView11.ReadOnly = true;
            this.pwtDataGridView11.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle36.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle36.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle36.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle36.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle36.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle36.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.pwtDataGridView11.RowHeadersDefaultCellStyle = dataGridViewCellStyle36;
            this.pwtDataGridView11.RowHeadersWidth = 51;
            this.pwtDataGridView11.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.pwtDataGridView11.RowTemplate.Height = 27;
            this.pwtDataGridView11.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.pwtDataGridView11.Size = new System.Drawing.Size(531, 481);
            this.pwtDataGridView11.TabIndex = 6;
            // 
            // labelX40
            // 
            // 
            // 
            // 
            this.labelX40.BackgroundStyle.Class = "";
            this.labelX40.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX40.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX40.Location = new System.Drawing.Point(3, 3);
            this.labelX40.Name = "labelX40";
            this.labelX40.Size = new System.Drawing.Size(98, 34);
            this.labelX40.TabIndex = 1;
            // 
            // comboBoxEx7
            // 
            this.comboBoxEx7.DisplayMember = "Text";
            this.comboBoxEx7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxEx7.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.comboBoxEx7.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxEx7.FormattingEnabled = true;
            this.comboBoxEx7.ItemHeight = 19;
            this.comboBoxEx7.Location = new System.Drawing.Point(107, 3);
            this.comboBoxEx7.Name = "comboBoxEx7";
            this.comboBoxEx7.Size = new System.Drawing.Size(304, 25);
            this.comboBoxEx7.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.comboBoxEx7.TabIndex = 0;
            // 
            // labelX41
            // 
            // 
            // 
            // 
            this.labelX41.BackgroundStyle.Class = "";
            this.labelX41.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX41.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX41.Location = new System.Drawing.Point(3, 43);
            this.labelX41.Name = "labelX41";
            this.labelX41.Size = new System.Drawing.Size(98, 35);
            this.labelX41.TabIndex = 2;
            // 
            // textBoxX21
            // 
            // 
            // 
            // 
            this.textBoxX21.Border.Class = "TextBoxBorder";
            this.textBoxX21.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX21.Location = new System.Drawing.Point(107, 43);
            this.textBoxX21.Name = "textBoxX21";
            this.textBoxX21.Size = new System.Drawing.Size(304, 39);
            this.textBoxX21.TabIndex = 3;
            // 
            // CP晶圆基础信息管理审核
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2017, 1206);
            this.Controls.Add(this.panelEx1);
            this.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "CP晶圆基础信息管理审核";
            this.ShowIcon = false;
            this.Text = "晶圆基础信息管理";
            this.Load += new System.EventHandler(this.晶圆基础信息管理_Load);
            this.panelEx1.ResumeLayout(false);
            this.panelEx1.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.superTabControl1)).EndInit();
            this.superTabControl1.ResumeLayout(false);
            this.superTabControlPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.superTabControl2)).EndInit();
            this.superTabControl2.ResumeLayout(false);
            this.superTabControlPanel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.superTabControl3)).EndInit();
            this.superTabControl3.ResumeLayout(false);
            this.superTabControlPanel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pwtDataGridView2)).EndInit();
            this.superTabControlPanel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pwtDataGridView5)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.superTabControlPanel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pwtDataGridView6)).EndInit();
            this.superTabControlPanel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pwtDataGridView4)).EndInit();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.superTabControlPanel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pwtDataGridView3)).EndInit();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.groupPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pwtDataGridView1)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.superTabControlPanel2.ResumeLayout(false);
            this.superTabControlPanel10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.superTabControl6)).EndInit();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.superTabControlPanel13.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pwtDataGridView9)).EndInit();
            this.superTabControlPanel14.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pwtDataGridView10)).EndInit();
            this.superTabControlPanel15.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pwtDataGridView11)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevComponents.DotNetBar.PanelEx panelEx1;
        private DevComponents.DotNetBar.ButtonX buttonX5;
        private DevComponents.DotNetBar.ButtonX buttonX4;
        private DevComponents.DotNetBar.ButtonX buttonX3;
        private DevComponents.DotNetBar.ButtonX buttonX2;
        private DevComponents.DotNetBar.ButtonX buttonX1;
        private DevComponents.DotNetBar.SuperTabControl superTabControl1;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel1;
        private DevComponents.DotNetBar.SuperTabItem superTabItem1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private DevComponents.DotNetBar.LabelX labelX1;
        private DevComponents.DotNetBar.LabelX labelX2;
        private DevComponents.DotNetBar.LabelX labelX3;
        private DevComponents.DotNetBar.LabelX labelX4;
        private DevComponents.DotNetBar.LabelX labelX5;
        private DevComponents.DotNetBar.LabelX labelX6;
        private DevComponents.DotNetBar.LabelX labelX7;
        private DevComponents.DotNetBar.LabelX labelX8;
        private DevComponents.DotNetBar.LabelX labelX9;
        private DevComponents.DotNetBar.LabelX labelX10;
        private DevComponents.DotNetBar.LabelX labelX11;
        private DevComponents.DotNetBar.LabelX labelX12;
        private DevComponents.DotNetBar.LabelX labelX13;
        private DevComponents.DotNetBar.LabelX labelX14;
        private DevComponents.DotNetBar.LabelX labelX15;
        private DevComponents.DotNetBar.LabelX labelX17;
        private DevComponents.DotNetBar.LabelX labelX18;
        private DevComponents.DotNetBar.LabelX labelX19;
        private DevComponents.DotNetBar.LabelX labelX20;
        private DevComponents.DotNetBar.LabelX labelX22;
        private Pawote.UI.Controls.PwtSearchBox pwtSearchBox1;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX1;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX2;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX3;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX4;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX6;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX7;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX8;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX9;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX10;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX11;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX12;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX13;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX14;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX15;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX16;
        private Pawote.UI.Controls.PwtSearchBox pwtSearchBox2;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel2;
        private DevComponents.DotNetBar.SuperTabItem superTabItem2;
        private DevComponents.DotNetBar.Controls.GroupPanel groupPanel2;
        private Pawote.UI.Controls.PwtDataGridView pwtDataGridView1;
        private DevComponents.DotNetBar.LabelX labelX23;
        private DevComponents.DotNetBar.SuperTabControl superTabControl2;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel3;
        private DevComponents.DotNetBar.SuperTabItem superTabItem3;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel5;
        private DevComponents.DotNetBar.SuperTabItem superTabItem5;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel4;
        private DevComponents.DotNetBar.SuperTabItem superTabItem4;
        private DevComponents.DotNetBar.LabelX labelX16;
        private DevComponents.DotNetBar.Controls.ComboBoxEx comboBoxEx1;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX5;
        private DevComponents.DotNetBar.LabelX labelX24;
        private DevComponents.DotNetBar.SuperTabControl superTabControl3;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel6;
        private Pawote.UI.Controls.PwtDataGridView pwtDataGridView2;
        private DevComponents.DotNetBar.SuperTabItem superTabItem6;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel7;
        private DevComponents.DotNetBar.SuperTabItem superTabItem7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private DevComponents.DotNetBar.ButtonX buttonX6;
        private DevComponents.DotNetBar.ButtonX buttonX8;
        private DevComponents.DotNetBar.ButtonX buttonX7;
        private Pawote.UI.Controls.PwtDataGridView pwtDataGridView3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private DevComponents.DotNetBar.LabelX labelX25;
        private DevComponents.DotNetBar.Controls.ComboBoxEx comboBoxEx2;
        private DevComponents.DotNetBar.LabelX labelX26;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX17;
        private Pawote.UI.Controls.PwtDataGridView pwtDataGridView4;
        private DevComponents.DotNetBar.ButtonX buttonX9;
        private DevComponents.DotNetBar.ButtonX buttonX10;
        private Pawote.UI.Controls.PwtDataGridView pwtDataGridView5;
        private DevComponents.DotNetBar.LabelX labelX27;
        private DevComponents.DotNetBar.LabelX labelX28;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX19;
        private DevComponents.DotNetBar.ButtonX buttonX11;
        private DevComponents.DotNetBar.ButtonX buttonX12;
        private DevComponents.DotNetBar.ButtonX buttonX13;
        private DevComponents.DotNetBar.ButtonX buttonX14;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX18;
        private DevComponents.DotNetBar.LabelX labelX21;
        private DevComponents.DotNetBar.LabelX labelX29;
        private DevComponents.DotNetBar.LabelX labelX30;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 上传一致表单ToolStripMenuItem;
        private DevComponents.DotNetBar.LabelX labelX31;
        private DevComponents.DotNetBar.Controls.ComboBoxEx comboBoxEx3;
        private DevComponents.Editors.ComboItem comboItem1;
        private DevComponents.Editors.ComboItem comboItem2;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX22;
        private DevComponents.DotNetBar.LabelX labelX32;
        private Pawote.UI.Controls.PwtSearchBox pwtSearchBox3;
        private Pawote.UI.Controls.PwtSearchBox pwtSearchBox4;
        private DevComponents.DotNetBar.LabelX labelX33;
        private DevComponents.DotNetBar.BalloonTip balloonTip1;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel8;
        private DevComponents.DotNetBar.SuperTabItem superTabItem8;
        private Pawote.UI.Controls.PwtDataGridView pwtDataGridView6;
        private DevComponents.DotNetBar.Controls.ComboBoxEx comboBoxEx4;
        private DevComponents.Editors.ComboItem comboItem3;
        private DevComponents.Editors.ComboItem comboItem4;
        private DevComponents.Editors.ComboItem comboItem5;
        private DevComponents.Editors.ComboItem comboItem6;
        private DevComponents.Editors.ComboItem comboItem7;
        private DevComponents.DotNetBar.LabelX labelX34;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private DevComponents.DotNetBar.ButtonX buttonX16;
        private DevComponents.DotNetBar.ButtonX buttonX15;
        private Pawote.UI.Controls.PwtRadioButton pwtRadioButton1;
        private Pawote.UI.Controls.PwtRadioButton pwtRadioButton3;
        private Pawote.UI.Controls.PwtRadioButton pwtRadioButton2;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel10;
        private DevComponents.DotNetBar.SuperTabControl superTabControl6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private DevComponents.DotNetBar.ButtonX buttonX17;
        private DevComponents.DotNetBar.ButtonX buttonX18;
        private DevComponents.DotNetBar.ButtonX buttonX19;
        private DevComponents.DotNetBar.SuperTabItem superTabItem10;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel13;
        private DevComponents.DotNetBar.ButtonX buttonX20;
        private DevComponents.DotNetBar.LabelX labelX35;
        private DevComponents.DotNetBar.ButtonX buttonX21;
        private DevComponents.DotNetBar.ButtonX buttonX22;
        //private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private DevComponents.DotNetBar.LabelX labelX36;
        private DevComponents.DotNetBar.Controls.ComboBoxEx comboBoxEx5;
        private DevComponents.DotNetBar.LabelX labelX37;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX20;
        private DevComponents.DotNetBar.LabelX labelX38;
        private DevComponents.DotNetBar.Controls.ComboBoxEx comboBoxEx6;
        private DevComponents.Editors.ComboItem comboItem8;
        private DevComponents.Editors.ComboItem comboItem9;
        private DevComponents.Editors.ComboItem comboItem10;
        private DevComponents.Editors.ComboItem comboItem11;
        private DevComponents.Editors.ComboItem comboItem12;
        private Pawote.UI.Controls.PwtDataGridView pwtDataGridView9;
        private DevComponents.DotNetBar.ButtonX buttonX23;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel14;
        private Pawote.UI.Controls.PwtDataGridView pwtDataGridView10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel15;
        private DevComponents.DotNetBar.LabelX labelX39;
        private DevComponents.DotNetBar.ButtonX buttonX24;
        private DevComponents.DotNetBar.ButtonX buttonX25;
        private DevComponents.DotNetBar.ButtonX buttonX26;
        //private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private DevComponents.DotNetBar.LabelX labelX40;
        private DevComponents.DotNetBar.Controls.ComboBoxEx comboBoxEx7;
        private DevComponents.DotNetBar.LabelX labelX41;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX21;
        private Pawote.UI.Controls.PwtDataGridView pwtDataGridView11;
    }
}
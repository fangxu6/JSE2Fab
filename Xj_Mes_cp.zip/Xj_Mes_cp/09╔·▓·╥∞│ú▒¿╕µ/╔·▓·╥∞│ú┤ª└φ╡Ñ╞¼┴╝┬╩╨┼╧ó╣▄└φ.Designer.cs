﻿
namespace Xj_Mes_cp
{
    partial class 生产异常处理单片良率信息管理
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupPanel1 = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.buttonX2 = new DevComponents.DotNetBar.ButtonX();
            this.buttonX1 = new DevComponents.DotNetBar.ButtonX();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.labelX1 = new DevComponents.DotNetBar.LabelX();
            this.textBoxX1 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX2 = new DevComponents.DotNetBar.LabelX();
            this.labelX3 = new DevComponents.DotNetBar.LabelX();
            this.labelX4 = new DevComponents.DotNetBar.LabelX();
            this.labelX5 = new DevComponents.DotNetBar.LabelX();
            this.labelX6 = new DevComponents.DotNetBar.LabelX();
            this.labelX7 = new DevComponents.DotNetBar.LabelX();
            this.labelX8 = new DevComponents.DotNetBar.LabelX();
            this.labelX9 = new DevComponents.DotNetBar.LabelX();
            this.labelX10 = new DevComponents.DotNetBar.LabelX();
            this.labelX11 = new DevComponents.DotNetBar.LabelX();
            this.labelX12 = new DevComponents.DotNetBar.LabelX();
            this.labelX13 = new DevComponents.DotNetBar.LabelX();
            this.labelX14 = new DevComponents.DotNetBar.LabelX();
            this.labelX15 = new DevComponents.DotNetBar.LabelX();
            this.labelX16 = new DevComponents.DotNetBar.LabelX();
            this.labelX17 = new DevComponents.DotNetBar.LabelX();
            this.labelX18 = new DevComponents.DotNetBar.LabelX();
            this.labelX19 = new DevComponents.DotNetBar.LabelX();
            this.labelX20 = new DevComponents.DotNetBar.LabelX();
            this.labelX21 = new DevComponents.DotNetBar.LabelX();
            this.labelX22 = new DevComponents.DotNetBar.LabelX();
            this.labelX23 = new DevComponents.DotNetBar.LabelX();
            this.labelX24 = new DevComponents.DotNetBar.LabelX();
            this.labelX25 = new DevComponents.DotNetBar.LabelX();
            this.textBoxX2 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX3 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX4 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX5 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX6 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX7 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX8 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX9 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX10 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX11 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX12 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX13 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX14 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX15 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX16 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX17 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX18 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX19 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX20 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX21 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX22 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX23 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX24 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX25 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.groupPanel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupPanel1
            // 
            this.groupPanel1.CanvasColor = System.Drawing.SystemColors.Control;
            this.groupPanel1.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.groupPanel1.Controls.Add(this.buttonX2);
            this.groupPanel1.Controls.Add(this.buttonX1);
            this.groupPanel1.Controls.Add(this.tableLayoutPanel1);
            this.groupPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupPanel1.Location = new System.Drawing.Point(0, 0);
            this.groupPanel1.Margin = new System.Windows.Forms.Padding(4);
            this.groupPanel1.Name = "groupPanel1";
            this.groupPanel1.Size = new System.Drawing.Size(1203, 522);
            // 
            // 
            // 
            this.groupPanel1.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.groupPanel1.Style.BackColorGradientAngle = 90;
            this.groupPanel1.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.groupPanel1.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderBottomWidth = 1;
            this.groupPanel1.Style.BorderColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.groupPanel1.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderLeftWidth = 1;
            this.groupPanel1.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderRightWidth = 1;
            this.groupPanel1.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderTopWidth = 1;
            this.groupPanel1.Style.Class = "";
            this.groupPanel1.Style.CornerDiameter = 4;
            this.groupPanel1.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.groupPanel1.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.groupPanel1.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.groupPanel1.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.groupPanel1.StyleMouseDown.Class = "";
            this.groupPanel1.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.groupPanel1.StyleMouseOver.Class = "";
            this.groupPanel1.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.groupPanel1.TabIndex = 1;
            // 
            // buttonX2
            // 
            this.buttonX2.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX2.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX2.Location = new System.Drawing.Point(655, 397);
            this.buttonX2.Margin = new System.Windows.Forms.Padding(4);
            this.buttonX2.Name = "buttonX2";
            this.buttonX2.Size = new System.Drawing.Size(190, 66);
            this.buttonX2.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX2.TabIndex = 4;
            this.buttonX2.Text = "关闭";
            this.buttonX2.Click += new System.EventHandler(this.buttonX2_Click);
            // 
            // buttonX1
            // 
            this.buttonX1.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX1.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX1.Location = new System.Drawing.Point(351, 397);
            this.buttonX1.Margin = new System.Windows.Forms.Padding(4);
            this.buttonX1.Name = "buttonX1";
            this.buttonX1.Size = new System.Drawing.Size(190, 66);
            this.buttonX1.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX1.TabIndex = 3;
            this.buttonX1.Text = "维护";
            this.buttonX1.Click += new System.EventHandler(this.buttonX1_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel1.ColumnCount = 10;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.Controls.Add(this.labelX1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX1, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelX2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.labelX3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.labelX4, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.labelX5, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.labelX6, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.labelX7, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.labelX8, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.labelX9, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.labelX10, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelX11, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelX12, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.labelX13, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.labelX14, 4, 3);
            this.tableLayoutPanel1.Controls.Add(this.labelX15, 4, 4);
            this.tableLayoutPanel1.Controls.Add(this.labelX16, 6, 4);
            this.tableLayoutPanel1.Controls.Add(this.labelX17, 6, 3);
            this.tableLayoutPanel1.Controls.Add(this.labelX18, 6, 2);
            this.tableLayoutPanel1.Controls.Add(this.labelX19, 6, 1);
            this.tableLayoutPanel1.Controls.Add(this.labelX20, 6, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelX21, 8, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelX22, 8, 1);
            this.tableLayoutPanel1.Controls.Add(this.labelX23, 8, 2);
            this.tableLayoutPanel1.Controls.Add(this.labelX24, 8, 3);
            this.tableLayoutPanel1.Controls.Add(this.labelX25, 8, 4);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX2, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX3, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX4, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX5, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX6, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX7, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX8, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX9, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX10, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX11, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX12, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX13, 5, 2);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX14, 5, 3);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX15, 5, 4);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX16, 7, 0);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX17, 7, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX18, 7, 2);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX19, 7, 3);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX20, 7, 4);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX21, 9, 4);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX22, 9, 3);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX23, 9, 2);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX24, 9, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBoxX25, 9, 0);
            this.tableLayoutPanel1.Font = new System.Drawing.Font("宋体", 12F);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(4, 6);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1183, 334);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // labelX1
            // 
            // 
            // 
            // 
            this.labelX1.BackgroundStyle.Class = "";
            this.labelX1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX1.Font = new System.Drawing.Font("宋体", 12F);
            this.labelX1.Location = new System.Drawing.Point(4, 4);
            this.labelX1.Margin = new System.Windows.Forms.Padding(4);
            this.labelX1.Name = "labelX1";
            this.labelX1.Size = new System.Drawing.Size(92, 58);
            this.labelX1.TabIndex = 0;
            this.labelX1.Text = "#1";
            this.labelX1.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // textBoxX1
            // 
            // 
            // 
            // 
            this.textBoxX1.Border.Class = "TextBoxBorder";
            this.textBoxX1.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX1.Location = new System.Drawing.Point(104, 4);
            this.textBoxX1.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxX1.Multiline = true;
            this.textBoxX1.Name = "textBoxX1";
            this.textBoxX1.Size = new System.Drawing.Size(128, 58);
            this.textBoxX1.TabIndex = 1;
            // 
            // labelX2
            // 
            // 
            // 
            // 
            this.labelX2.BackgroundStyle.Class = "";
            this.labelX2.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX2.Font = new System.Drawing.Font("宋体", 12F);
            this.labelX2.Location = new System.Drawing.Point(4, 70);
            this.labelX2.Margin = new System.Windows.Forms.Padding(4);
            this.labelX2.Name = "labelX2";
            this.labelX2.Size = new System.Drawing.Size(92, 58);
            this.labelX2.TabIndex = 0;
            this.labelX2.Text = "#6";
            this.labelX2.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // labelX3
            // 
            // 
            // 
            // 
            this.labelX3.BackgroundStyle.Class = "";
            this.labelX3.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX3.Font = new System.Drawing.Font("宋体", 12F);
            this.labelX3.Location = new System.Drawing.Point(4, 136);
            this.labelX3.Margin = new System.Windows.Forms.Padding(4);
            this.labelX3.Name = "labelX3";
            this.labelX3.Size = new System.Drawing.Size(92, 58);
            this.labelX3.TabIndex = 0;
            this.labelX3.Text = "#11";
            this.labelX3.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // labelX4
            // 
            // 
            // 
            // 
            this.labelX4.BackgroundStyle.Class = "";
            this.labelX4.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX4.Font = new System.Drawing.Font("宋体", 12F);
            this.labelX4.Location = new System.Drawing.Point(4, 202);
            this.labelX4.Margin = new System.Windows.Forms.Padding(4);
            this.labelX4.Name = "labelX4";
            this.labelX4.Size = new System.Drawing.Size(92, 58);
            this.labelX4.TabIndex = 0;
            this.labelX4.Text = "#16";
            this.labelX4.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // labelX5
            // 
            // 
            // 
            // 
            this.labelX5.BackgroundStyle.Class = "";
            this.labelX5.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX5.Font = new System.Drawing.Font("宋体", 12F);
            this.labelX5.Location = new System.Drawing.Point(4, 268);
            this.labelX5.Margin = new System.Windows.Forms.Padding(4);
            this.labelX5.Name = "labelX5";
            this.labelX5.Size = new System.Drawing.Size(92, 62);
            this.labelX5.TabIndex = 0;
            this.labelX5.Text = "#21";
            this.labelX5.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // labelX6
            // 
            // 
            // 
            // 
            this.labelX6.BackgroundStyle.Class = "";
            this.labelX6.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX6.Font = new System.Drawing.Font("宋体", 12F);
            this.labelX6.Location = new System.Drawing.Point(240, 268);
            this.labelX6.Margin = new System.Windows.Forms.Padding(4);
            this.labelX6.Name = "labelX6";
            this.labelX6.Size = new System.Drawing.Size(92, 62);
            this.labelX6.TabIndex = 0;
            this.labelX6.Text = "#22";
            this.labelX6.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // labelX7
            // 
            // 
            // 
            // 
            this.labelX7.BackgroundStyle.Class = "";
            this.labelX7.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX7.Font = new System.Drawing.Font("宋体", 12F);
            this.labelX7.Location = new System.Drawing.Point(240, 202);
            this.labelX7.Margin = new System.Windows.Forms.Padding(4);
            this.labelX7.Name = "labelX7";
            this.labelX7.Size = new System.Drawing.Size(92, 58);
            this.labelX7.TabIndex = 0;
            this.labelX7.Text = "#17";
            this.labelX7.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // labelX8
            // 
            // 
            // 
            // 
            this.labelX8.BackgroundStyle.Class = "";
            this.labelX8.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX8.Font = new System.Drawing.Font("宋体", 12F);
            this.labelX8.Location = new System.Drawing.Point(240, 136);
            this.labelX8.Margin = new System.Windows.Forms.Padding(4);
            this.labelX8.Name = "labelX8";
            this.labelX8.Size = new System.Drawing.Size(92, 58);
            this.labelX8.TabIndex = 0;
            this.labelX8.Text = "#12";
            this.labelX8.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // labelX9
            // 
            // 
            // 
            // 
            this.labelX9.BackgroundStyle.Class = "";
            this.labelX9.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX9.Font = new System.Drawing.Font("宋体", 12F);
            this.labelX9.Location = new System.Drawing.Point(240, 70);
            this.labelX9.Margin = new System.Windows.Forms.Padding(4);
            this.labelX9.Name = "labelX9";
            this.labelX9.Size = new System.Drawing.Size(92, 58);
            this.labelX9.TabIndex = 0;
            this.labelX9.Text = "#7";
            this.labelX9.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // labelX10
            // 
            // 
            // 
            // 
            this.labelX10.BackgroundStyle.Class = "";
            this.labelX10.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX10.Font = new System.Drawing.Font("宋体", 12F);
            this.labelX10.Location = new System.Drawing.Point(240, 4);
            this.labelX10.Margin = new System.Windows.Forms.Padding(4);
            this.labelX10.Name = "labelX10";
            this.labelX10.Size = new System.Drawing.Size(92, 58);
            this.labelX10.TabIndex = 0;
            this.labelX10.Text = "#2";
            this.labelX10.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // labelX11
            // 
            // 
            // 
            // 
            this.labelX11.BackgroundStyle.Class = "";
            this.labelX11.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX11.Font = new System.Drawing.Font("宋体", 12F);
            this.labelX11.Location = new System.Drawing.Point(476, 4);
            this.labelX11.Margin = new System.Windows.Forms.Padding(4);
            this.labelX11.Name = "labelX11";
            this.labelX11.Size = new System.Drawing.Size(92, 58);
            this.labelX11.TabIndex = 0;
            this.labelX11.Text = "#3";
            this.labelX11.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // labelX12
            // 
            // 
            // 
            // 
            this.labelX12.BackgroundStyle.Class = "";
            this.labelX12.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX12.Font = new System.Drawing.Font("宋体", 12F);
            this.labelX12.Location = new System.Drawing.Point(476, 70);
            this.labelX12.Margin = new System.Windows.Forms.Padding(4);
            this.labelX12.Name = "labelX12";
            this.labelX12.Size = new System.Drawing.Size(92, 58);
            this.labelX12.TabIndex = 0;
            this.labelX12.Text = "#8";
            this.labelX12.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // labelX13
            // 
            // 
            // 
            // 
            this.labelX13.BackgroundStyle.Class = "";
            this.labelX13.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX13.Font = new System.Drawing.Font("宋体", 12F);
            this.labelX13.Location = new System.Drawing.Point(476, 136);
            this.labelX13.Margin = new System.Windows.Forms.Padding(4);
            this.labelX13.Name = "labelX13";
            this.labelX13.Size = new System.Drawing.Size(92, 58);
            this.labelX13.TabIndex = 0;
            this.labelX13.Text = "#13";
            this.labelX13.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // labelX14
            // 
            // 
            // 
            // 
            this.labelX14.BackgroundStyle.Class = "";
            this.labelX14.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX14.Font = new System.Drawing.Font("宋体", 12F);
            this.labelX14.Location = new System.Drawing.Point(476, 202);
            this.labelX14.Margin = new System.Windows.Forms.Padding(4);
            this.labelX14.Name = "labelX14";
            this.labelX14.Size = new System.Drawing.Size(92, 58);
            this.labelX14.TabIndex = 0;
            this.labelX14.Text = "#18";
            this.labelX14.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // labelX15
            // 
            // 
            // 
            // 
            this.labelX15.BackgroundStyle.Class = "";
            this.labelX15.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX15.Font = new System.Drawing.Font("宋体", 12F);
            this.labelX15.Location = new System.Drawing.Point(476, 268);
            this.labelX15.Margin = new System.Windows.Forms.Padding(4);
            this.labelX15.Name = "labelX15";
            this.labelX15.Size = new System.Drawing.Size(92, 62);
            this.labelX15.TabIndex = 0;
            this.labelX15.Text = "#23";
            this.labelX15.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // labelX16
            // 
            // 
            // 
            // 
            this.labelX16.BackgroundStyle.Class = "";
            this.labelX16.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX16.Font = new System.Drawing.Font("宋体", 12F);
            this.labelX16.Location = new System.Drawing.Point(712, 268);
            this.labelX16.Margin = new System.Windows.Forms.Padding(4);
            this.labelX16.Name = "labelX16";
            this.labelX16.Size = new System.Drawing.Size(92, 62);
            this.labelX16.TabIndex = 0;
            this.labelX16.Text = "#24";
            this.labelX16.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // labelX17
            // 
            // 
            // 
            // 
            this.labelX17.BackgroundStyle.Class = "";
            this.labelX17.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX17.Font = new System.Drawing.Font("宋体", 12F);
            this.labelX17.Location = new System.Drawing.Point(712, 202);
            this.labelX17.Margin = new System.Windows.Forms.Padding(4);
            this.labelX17.Name = "labelX17";
            this.labelX17.Size = new System.Drawing.Size(92, 58);
            this.labelX17.TabIndex = 0;
            this.labelX17.Text = "#19";
            this.labelX17.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // labelX18
            // 
            // 
            // 
            // 
            this.labelX18.BackgroundStyle.Class = "";
            this.labelX18.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX18.Font = new System.Drawing.Font("宋体", 12F);
            this.labelX18.Location = new System.Drawing.Point(712, 136);
            this.labelX18.Margin = new System.Windows.Forms.Padding(4);
            this.labelX18.Name = "labelX18";
            this.labelX18.Size = new System.Drawing.Size(92, 58);
            this.labelX18.TabIndex = 0;
            this.labelX18.Text = "#14";
            this.labelX18.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // labelX19
            // 
            // 
            // 
            // 
            this.labelX19.BackgroundStyle.Class = "";
            this.labelX19.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX19.Font = new System.Drawing.Font("宋体", 12F);
            this.labelX19.Location = new System.Drawing.Point(712, 70);
            this.labelX19.Margin = new System.Windows.Forms.Padding(4);
            this.labelX19.Name = "labelX19";
            this.labelX19.Size = new System.Drawing.Size(92, 58);
            this.labelX19.TabIndex = 0;
            this.labelX19.Text = "#9";
            this.labelX19.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // labelX20
            // 
            // 
            // 
            // 
            this.labelX20.BackgroundStyle.Class = "";
            this.labelX20.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX20.Font = new System.Drawing.Font("宋体", 12F);
            this.labelX20.Location = new System.Drawing.Point(712, 4);
            this.labelX20.Margin = new System.Windows.Forms.Padding(4);
            this.labelX20.Name = "labelX20";
            this.labelX20.Size = new System.Drawing.Size(92, 58);
            this.labelX20.TabIndex = 0;
            this.labelX20.Text = "#4";
            this.labelX20.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // labelX21
            // 
            // 
            // 
            // 
            this.labelX21.BackgroundStyle.Class = "";
            this.labelX21.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX21.Font = new System.Drawing.Font("宋体", 12F);
            this.labelX21.Location = new System.Drawing.Point(948, 4);
            this.labelX21.Margin = new System.Windows.Forms.Padding(4);
            this.labelX21.Name = "labelX21";
            this.labelX21.Size = new System.Drawing.Size(92, 58);
            this.labelX21.TabIndex = 0;
            this.labelX21.Text = "#5";
            this.labelX21.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // labelX22
            // 
            // 
            // 
            // 
            this.labelX22.BackgroundStyle.Class = "";
            this.labelX22.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX22.Font = new System.Drawing.Font("宋体", 12F);
            this.labelX22.Location = new System.Drawing.Point(948, 70);
            this.labelX22.Margin = new System.Windows.Forms.Padding(4);
            this.labelX22.Name = "labelX22";
            this.labelX22.Size = new System.Drawing.Size(92, 58);
            this.labelX22.TabIndex = 0;
            this.labelX22.Text = "#10";
            this.labelX22.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // labelX23
            // 
            // 
            // 
            // 
            this.labelX23.BackgroundStyle.Class = "";
            this.labelX23.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX23.Font = new System.Drawing.Font("宋体", 12F);
            this.labelX23.Location = new System.Drawing.Point(948, 136);
            this.labelX23.Margin = new System.Windows.Forms.Padding(4);
            this.labelX23.Name = "labelX23";
            this.labelX23.Size = new System.Drawing.Size(92, 58);
            this.labelX23.TabIndex = 0;
            this.labelX23.Text = "#15";
            this.labelX23.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // labelX24
            // 
            // 
            // 
            // 
            this.labelX24.BackgroundStyle.Class = "";
            this.labelX24.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX24.Font = new System.Drawing.Font("宋体", 12F);
            this.labelX24.Location = new System.Drawing.Point(948, 202);
            this.labelX24.Margin = new System.Windows.Forms.Padding(4);
            this.labelX24.Name = "labelX24";
            this.labelX24.Size = new System.Drawing.Size(92, 58);
            this.labelX24.TabIndex = 0;
            this.labelX24.Text = "#20";
            this.labelX24.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // labelX25
            // 
            // 
            // 
            // 
            this.labelX25.BackgroundStyle.Class = "";
            this.labelX25.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX25.Font = new System.Drawing.Font("宋体", 12F);
            this.labelX25.Location = new System.Drawing.Point(948, 268);
            this.labelX25.Margin = new System.Windows.Forms.Padding(4);
            this.labelX25.Name = "labelX25";
            this.labelX25.Size = new System.Drawing.Size(92, 62);
            this.labelX25.TabIndex = 0;
            this.labelX25.Text = "#25";
            this.labelX25.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // textBoxX2
            // 
            // 
            // 
            // 
            this.textBoxX2.Border.Class = "TextBoxBorder";
            this.textBoxX2.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX2.Location = new System.Drawing.Point(104, 70);
            this.textBoxX2.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxX2.Multiline = true;
            this.textBoxX2.Name = "textBoxX2";
            this.textBoxX2.Size = new System.Drawing.Size(128, 58);
            this.textBoxX2.TabIndex = 1;
            // 
            // textBoxX3
            // 
            // 
            // 
            // 
            this.textBoxX3.Border.Class = "TextBoxBorder";
            this.textBoxX3.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX3.Location = new System.Drawing.Point(104, 136);
            this.textBoxX3.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxX3.Multiline = true;
            this.textBoxX3.Name = "textBoxX3";
            this.textBoxX3.Size = new System.Drawing.Size(128, 58);
            this.textBoxX3.TabIndex = 1;
            // 
            // textBoxX4
            // 
            // 
            // 
            // 
            this.textBoxX4.Border.Class = "TextBoxBorder";
            this.textBoxX4.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX4.Location = new System.Drawing.Point(104, 202);
            this.textBoxX4.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxX4.Multiline = true;
            this.textBoxX4.Name = "textBoxX4";
            this.textBoxX4.Size = new System.Drawing.Size(128, 58);
            this.textBoxX4.TabIndex = 1;
            // 
            // textBoxX5
            // 
            // 
            // 
            // 
            this.textBoxX5.Border.Class = "TextBoxBorder";
            this.textBoxX5.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX5.Location = new System.Drawing.Point(104, 268);
            this.textBoxX5.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxX5.Multiline = true;
            this.textBoxX5.Name = "textBoxX5";
            this.textBoxX5.Size = new System.Drawing.Size(128, 62);
            this.textBoxX5.TabIndex = 1;
            // 
            // textBoxX6
            // 
            // 
            // 
            // 
            this.textBoxX6.Border.Class = "TextBoxBorder";
            this.textBoxX6.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX6.Location = new System.Drawing.Point(340, 4);
            this.textBoxX6.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxX6.Multiline = true;
            this.textBoxX6.Name = "textBoxX6";
            this.textBoxX6.Size = new System.Drawing.Size(128, 58);
            this.textBoxX6.TabIndex = 1;
            // 
            // textBoxX7
            // 
            // 
            // 
            // 
            this.textBoxX7.Border.Class = "TextBoxBorder";
            this.textBoxX7.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX7.Location = new System.Drawing.Point(340, 70);
            this.textBoxX7.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxX7.Multiline = true;
            this.textBoxX7.Name = "textBoxX7";
            this.textBoxX7.Size = new System.Drawing.Size(128, 58);
            this.textBoxX7.TabIndex = 1;
            // 
            // textBoxX8
            // 
            // 
            // 
            // 
            this.textBoxX8.Border.Class = "TextBoxBorder";
            this.textBoxX8.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX8.Location = new System.Drawing.Point(340, 136);
            this.textBoxX8.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxX8.Multiline = true;
            this.textBoxX8.Name = "textBoxX8";
            this.textBoxX8.Size = new System.Drawing.Size(128, 58);
            this.textBoxX8.TabIndex = 1;
            // 
            // textBoxX9
            // 
            // 
            // 
            // 
            this.textBoxX9.Border.Class = "TextBoxBorder";
            this.textBoxX9.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX9.Location = new System.Drawing.Point(340, 202);
            this.textBoxX9.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxX9.Multiline = true;
            this.textBoxX9.Name = "textBoxX9";
            this.textBoxX9.Size = new System.Drawing.Size(128, 58);
            this.textBoxX9.TabIndex = 1;
            // 
            // textBoxX10
            // 
            // 
            // 
            // 
            this.textBoxX10.Border.Class = "TextBoxBorder";
            this.textBoxX10.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX10.Location = new System.Drawing.Point(340, 268);
            this.textBoxX10.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxX10.Multiline = true;
            this.textBoxX10.Name = "textBoxX10";
            this.textBoxX10.Size = new System.Drawing.Size(128, 62);
            this.textBoxX10.TabIndex = 1;
            // 
            // textBoxX11
            // 
            // 
            // 
            // 
            this.textBoxX11.Border.Class = "TextBoxBorder";
            this.textBoxX11.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX11.Location = new System.Drawing.Point(576, 4);
            this.textBoxX11.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxX11.Multiline = true;
            this.textBoxX11.Name = "textBoxX11";
            this.textBoxX11.Size = new System.Drawing.Size(128, 58);
            this.textBoxX11.TabIndex = 1;
            // 
            // textBoxX12
            // 
            // 
            // 
            // 
            this.textBoxX12.Border.Class = "TextBoxBorder";
            this.textBoxX12.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX12.Location = new System.Drawing.Point(576, 70);
            this.textBoxX12.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxX12.Multiline = true;
            this.textBoxX12.Name = "textBoxX12";
            this.textBoxX12.Size = new System.Drawing.Size(128, 58);
            this.textBoxX12.TabIndex = 1;
            // 
            // textBoxX13
            // 
            // 
            // 
            // 
            this.textBoxX13.Border.Class = "TextBoxBorder";
            this.textBoxX13.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX13.Location = new System.Drawing.Point(576, 136);
            this.textBoxX13.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxX13.Multiline = true;
            this.textBoxX13.Name = "textBoxX13";
            this.textBoxX13.Size = new System.Drawing.Size(128, 58);
            this.textBoxX13.TabIndex = 1;
            // 
            // textBoxX14
            // 
            // 
            // 
            // 
            this.textBoxX14.Border.Class = "TextBoxBorder";
            this.textBoxX14.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX14.Location = new System.Drawing.Point(576, 202);
            this.textBoxX14.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxX14.Multiline = true;
            this.textBoxX14.Name = "textBoxX14";
            this.textBoxX14.Size = new System.Drawing.Size(128, 58);
            this.textBoxX14.TabIndex = 1;
            // 
            // textBoxX15
            // 
            // 
            // 
            // 
            this.textBoxX15.Border.Class = "TextBoxBorder";
            this.textBoxX15.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX15.Location = new System.Drawing.Point(576, 268);
            this.textBoxX15.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxX15.Multiline = true;
            this.textBoxX15.Name = "textBoxX15";
            this.textBoxX15.Size = new System.Drawing.Size(128, 62);
            this.textBoxX15.TabIndex = 1;
            // 
            // textBoxX16
            // 
            // 
            // 
            // 
            this.textBoxX16.Border.Class = "TextBoxBorder";
            this.textBoxX16.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX16.Location = new System.Drawing.Point(812, 4);
            this.textBoxX16.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxX16.Multiline = true;
            this.textBoxX16.Name = "textBoxX16";
            this.textBoxX16.Size = new System.Drawing.Size(128, 58);
            this.textBoxX16.TabIndex = 1;
            // 
            // textBoxX17
            // 
            // 
            // 
            // 
            this.textBoxX17.Border.Class = "TextBoxBorder";
            this.textBoxX17.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX17.Location = new System.Drawing.Point(812, 70);
            this.textBoxX17.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxX17.Multiline = true;
            this.textBoxX17.Name = "textBoxX17";
            this.textBoxX17.Size = new System.Drawing.Size(128, 58);
            this.textBoxX17.TabIndex = 1;
            // 
            // textBoxX18
            // 
            // 
            // 
            // 
            this.textBoxX18.Border.Class = "TextBoxBorder";
            this.textBoxX18.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX18.Location = new System.Drawing.Point(812, 136);
            this.textBoxX18.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxX18.Multiline = true;
            this.textBoxX18.Name = "textBoxX18";
            this.textBoxX18.Size = new System.Drawing.Size(128, 58);
            this.textBoxX18.TabIndex = 1;
            // 
            // textBoxX19
            // 
            // 
            // 
            // 
            this.textBoxX19.Border.Class = "TextBoxBorder";
            this.textBoxX19.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX19.Location = new System.Drawing.Point(812, 202);
            this.textBoxX19.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxX19.Multiline = true;
            this.textBoxX19.Name = "textBoxX19";
            this.textBoxX19.Size = new System.Drawing.Size(128, 58);
            this.textBoxX19.TabIndex = 1;
            // 
            // textBoxX20
            // 
            // 
            // 
            // 
            this.textBoxX20.Border.Class = "TextBoxBorder";
            this.textBoxX20.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX20.Location = new System.Drawing.Point(812, 268);
            this.textBoxX20.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxX20.Multiline = true;
            this.textBoxX20.Name = "textBoxX20";
            this.textBoxX20.Size = new System.Drawing.Size(128, 62);
            this.textBoxX20.TabIndex = 1;
            // 
            // textBoxX21
            // 
            // 
            // 
            // 
            this.textBoxX21.Border.Class = "TextBoxBorder";
            this.textBoxX21.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX21.Location = new System.Drawing.Point(1048, 268);
            this.textBoxX21.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxX21.Multiline = true;
            this.textBoxX21.Name = "textBoxX21";
            this.textBoxX21.Size = new System.Drawing.Size(131, 62);
            this.textBoxX21.TabIndex = 1;
            // 
            // textBoxX22
            // 
            // 
            // 
            // 
            this.textBoxX22.Border.Class = "TextBoxBorder";
            this.textBoxX22.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX22.Location = new System.Drawing.Point(1048, 202);
            this.textBoxX22.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxX22.Multiline = true;
            this.textBoxX22.Name = "textBoxX22";
            this.textBoxX22.Size = new System.Drawing.Size(131, 58);
            this.textBoxX22.TabIndex = 1;
            // 
            // textBoxX23
            // 
            // 
            // 
            // 
            this.textBoxX23.Border.Class = "TextBoxBorder";
            this.textBoxX23.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX23.Location = new System.Drawing.Point(1048, 136);
            this.textBoxX23.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxX23.Multiline = true;
            this.textBoxX23.Name = "textBoxX23";
            this.textBoxX23.Size = new System.Drawing.Size(131, 58);
            this.textBoxX23.TabIndex = 1;
            // 
            // textBoxX24
            // 
            // 
            // 
            // 
            this.textBoxX24.Border.Class = "TextBoxBorder";
            this.textBoxX24.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX24.Location = new System.Drawing.Point(1048, 70);
            this.textBoxX24.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxX24.Multiline = true;
            this.textBoxX24.Name = "textBoxX24";
            this.textBoxX24.Size = new System.Drawing.Size(131, 58);
            this.textBoxX24.TabIndex = 1;
            // 
            // textBoxX25
            // 
            // 
            // 
            // 
            this.textBoxX25.Border.Class = "TextBoxBorder";
            this.textBoxX25.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxX25.Location = new System.Drawing.Point(1048, 4);
            this.textBoxX25.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxX25.Multiline = true;
            this.textBoxX25.Name = "textBoxX25";
            this.textBoxX25.Size = new System.Drawing.Size(131, 58);
            this.textBoxX25.TabIndex = 1;
            // 
            // 生产异常处理单片良率信息管理
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1203, 522);
            this.Controls.Add(this.groupPanel1);
            this.Name = "生产异常处理单片良率信息管理";
            this.Text = "生产异常处理单片良率信息管理";
            this.groupPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private DevComponents.DotNetBar.Controls.GroupPanel groupPanel1;
        private DevComponents.DotNetBar.ButtonX buttonX2;
        private DevComponents.DotNetBar.ButtonX buttonX1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private DevComponents.DotNetBar.LabelX labelX1;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX1;
        private DevComponents.DotNetBar.LabelX labelX2;
        private DevComponents.DotNetBar.LabelX labelX3;
        private DevComponents.DotNetBar.LabelX labelX4;
        private DevComponents.DotNetBar.LabelX labelX5;
        private DevComponents.DotNetBar.LabelX labelX6;
        private DevComponents.DotNetBar.LabelX labelX7;
        private DevComponents.DotNetBar.LabelX labelX8;
        private DevComponents.DotNetBar.LabelX labelX9;
        private DevComponents.DotNetBar.LabelX labelX10;
        private DevComponents.DotNetBar.LabelX labelX11;
        private DevComponents.DotNetBar.LabelX labelX12;
        private DevComponents.DotNetBar.LabelX labelX13;
        private DevComponents.DotNetBar.LabelX labelX14;
        private DevComponents.DotNetBar.LabelX labelX15;
        private DevComponents.DotNetBar.LabelX labelX16;
        private DevComponents.DotNetBar.LabelX labelX17;
        private DevComponents.DotNetBar.LabelX labelX18;
        private DevComponents.DotNetBar.LabelX labelX19;
        private DevComponents.DotNetBar.LabelX labelX20;
        private DevComponents.DotNetBar.LabelX labelX21;
        private DevComponents.DotNetBar.LabelX labelX22;
        private DevComponents.DotNetBar.LabelX labelX23;
        private DevComponents.DotNetBar.LabelX labelX24;
        private DevComponents.DotNetBar.LabelX labelX25;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX2;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX3;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX4;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX5;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX6;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX7;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX8;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX9;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX10;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX11;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX12;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX13;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX14;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX15;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX16;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX17;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX18;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX19;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX20;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX21;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX22;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX23;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX24;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX25;
    }
}